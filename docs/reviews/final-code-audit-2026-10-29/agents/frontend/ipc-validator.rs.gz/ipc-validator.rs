use serde_json::Value;
const MAX_REQUEST:usize=32768;
mod workspace_windows { pub fn surface_role(label:&str)->&str { label } }
pub fn validate_surface(label: &str, request: &Value) -> Result<(), String> {
    let label = crate::workspace_windows::surface_role(label);
    validate_request(request)?;
    if request["method"].as_str().is_some_and(|method| method.starts_with("cw_decode_")) {
        return if matches!(label, "main" | "cw-decode") { Ok(()) }
        else { Err("CW Decode requests belong to the main or CW Decode window.".into()) };
    }
    if label == "cw-decode" { return Err("CW Decode can only use its receive-only decoder service.".into()); }
    if request["method"].as_str().is_some_and(|method| method.starts_with("contest_multi_")) {
        return Err("Use the native group-authority or replica-sync owner for multi-operator requests.".into());
    }
    if request["method"] == "station_tune" || request["method"] == "hamlib_control" && request["params"]["device"] == "radio" && request["params"]["action"] == "tune_simplex" {
        return Err("Only the shared native tune owner can dispatch simplex tuning.".into());
    }
    if matches!(request["method"].as_str(), Some("sync_run" | "sync_configure" | "sync_resolve" | "sync_retry")) {
        return Err("Use the shared generation-bound Sync mutation owner.".into());
    }
    if request["method"] == "connection_doctor_project" {
        return Err("Use the typed retained Connection Doctor projection.".into());
    }
    if request["method"].as_str().is_some_and(|method| method.starts_with("contest_")) {
        return if label == "contest-setup" { Ok(()) }
        else { Err("Contest methods are available only in the detached Contest Setup owner window.".into()) };
    }
    if label == "contest-setup" {
        return if matches!(request["method"].as_str(), Some("health" | "workspace_status" | "settings_load" | "station_snapshot" | "cluster_snapshot" | "cluster_contest_radio_spots_publish" | "lookup_call")) {
            Ok(())
        } else if matches!(request["method"].as_str(), Some("wsjtx_snapshot" | "wsjtx_select" | "wsjtx_configure" | "wsjtx_start" | "wsjtx_stop"
            | "fldigi_snapshot" | "fldigi_rx_text" | "fldigi_select" | "fldigi_accept_completed" | "fldigi_configure" | "fldigi_start" | "fldigi_stop" | "fldigi_send")) {
            Ok(())
        } else { Err("Contest Setup can only read shared station context and own contest sessions.".into()) };
    }
    if label == "cw" { return Err("CW can only use the typed shared CW session.".into()); }
    if label == "rotor" { return Err("Rotor can only read retained native rotor telemetry.".into()); }
    if label == "station-status" { return Err("Station Status can only read retained native station observations.".into()); }
    if label == "propagation" { return Err("Propagation can only use the typed shared public-conditions session.".into()); }
    if matches!(label, "station-identity" | "alerts" | "antenna") { return Err("This display can only read its retained non-secret projection.".into()); }
    if request["method"].as_str().is_some_and(|method| method.starts_with("spot_draft_") || matches!(method, "logbook_operator_draft_qsy_clear" | "logbook_operator_draft_radio_read" | "logbook_operator_draft_radio_follow")) {
        return Err("Only the native transaction owner can use this method.".into());
    }
    if request["method"] == "workspace_layout_load" {
        return if matches!(label, "main" | "monitor" | "world-map" | "band-maps" | "dx-cluster" | "log-qso" | "spot-history" | "logbook" | "awards" | "callsign-intelligence" | "settings" | "chaser-dx" | "station-control") {
            Ok(())
        } else { Err("This window cannot read the shared workspace layout.".into()) };
    }
    // Passive station windows use retained native context only. They must not
    // reach worker reads (which can start sessions) or any special dispatcher.
    if label == "station-control" { return Err("Station Control can only read retained native observations and workspace placement.".into()); }
    if request["method"] == "cluster_resume" {
        return Err("Only the native session owner can resume a cluster.".into());
    }
    if request["method"] == "station_power_selection" {
        return Err("Only the native radio owner can publish power selection.".into());
    }
    if label == "settings" {
        return if matches!(request["method"].as_str(), Some(
            "settings_load" | "settings_receipt" | "settings_save"
            | "workspace_rotor_configuration_load" | "workspace_rotor_configuration_receipt" | "workspace_rotor_configuration_save"
            | "secret_status" | "secret_save" | "online_log_status" | "online_log_configure"
            | "sync_status" | "sync_summary" | "sync_mutation" | "sync_receipt"
            | "reference_status" | "reference_resolve" | "reference_refresh" | "reference_schedule" | "reference_configure"
            | "backup_create" | "backup_list" | "backup_inspect" | "backup_import" | "backup_restore"
            | "remote_backup_request"
            | "wsjtx_snapshot" | "wsjtx_configure" | "wsjtx_start" | "wsjtx_stop"
             | "spot_bridge_snapshot" | "spot_bridge_configure"
            | "cluster_snapshot" | "cluster_radio_spots_configure"
            | "workspace_layout_load" | "workspace_layout_apply"
        )) { Ok(()) } else { Err("Settings can only manage scoped configuration, synchronization, reference data, layouts and backups.".into()) };
    }
    if request["method"] == "workspace_band_map_apply" {
        return if label == "main" || label == "band-maps" && request["params"]["scope"] == "detached" { Ok(()) }
        else { Err("This window cannot change band-map preferences.".into()) };
    }
    if request["method"] == "workspace_logbook_filters_apply" {
        return if matches!(label, "main" | "logbook") { Ok(()) }
        else { Err("This window cannot change saved Logbook filters.".into()) };
    }
    if label == "previous-qsos" {
        return if matches!(request["method"].as_str(), Some("logbook_operator_draft" | "cluster_history")) { Ok(()) }
        else { Err("Previous QSOs can only read the shared draft and local contact history.".into()) };
    }
    if label == "operating-goals" {
        return if request["method"] == "operating_goals_evaluate" { Ok(()) }
        else { Err("Operating Goals can only evaluate explicit targets against retained local evidence.".into()) };
    }
    if label == "callsign-intelligence" {
        return if matches!(request["method"].as_str(), Some("logbook_operator_draft" | "lookup_call"
            | "logbook_previous" | "logbook_matrix" | "cluster_history" | "workspace_preferences_load")) { Ok(()) }
        else { Err("Callsign Intelligence can only read the shared draft and its lookup evidence.".into()) };
    }
    if label == "log-qso" {
        return if matches!(request["method"].as_str(), Some("logbook_operator_draft"
            | "logbook_operator_draft_apply" | "logbook_operator_draft_receipt"
            | "lookup_call" | "logbook_previous" | "logbook_matrix" | "cluster_history" | "reference_resolve")) {
            Ok(())
        } else { Err("Log QSO can only edit the shared new-contact draft and read its lookup evidence.".into()) };
    }
    if label == "awards" {
        return if matches!(request["method"].as_str(), Some("logbook_stats" | "logbook_catalog")) {
            Ok(())
        } else { Err("Awards can only read local statistics and the awards catalogue.".into()) };
    }
    if label == "chaser-dx" {
        return if matches!(request["method"].as_str(), Some("opportunities_snapshot" | "opportunities_refresh")) {
            Ok(())
        } else { Err("Chaser & DX can only read and refresh public opportunity feeds.".into()) };
    }
    if label == "dxpedition-map" {
        return if matches!(request["method"].as_str(), Some("opportunities_dxpedition_snapshot" | "opportunities_dxpedition_refresh")) {
            Ok(())
        } else { Err("DXpedition Map can only read and refresh its bounded public catalogue.".into()) };
    }
    if label == "spot-history" {
        return if matches!(request["method"].as_str(), Some("spot_history_status" | "spot_history_query"
            | "spot_history_detail" | "spot_history_stats")) {
            Ok(())
        } else { Err("Spot History can only read the local report archive.".into()) };
    }
    if label == "logbook" {
        return if matches!(request["method"].as_str(), Some("logbook_list" | "logbook_contact"
            | "logbook_contact_apply" | "logbook_contact_receipt" | "logbook_matrix" | "logbook_previous"
            | "logbook_import_adif" | "logbook_export_adif" | "logbook_cty_preview" | "logbook_follow_up" | "logbook_data_quality" | "lookup_call" | "cluster_history")) {
            Ok(())
        } else { Err("This window can only read and edit the local logbook.".into()) };
    }
    // Cluster has a separate scoped session dispatcher. The explicit Settings
    // role above is the only child with credential/configuration authority; no
    // new window label inherits logbook or station authority.
    if !matches!(label, "main" | "monitor" | "world-map" | "band-maps") {
        return Err("This window cannot access the workspace service.".into());
    }
    // The narrow Logbook contact capability was handled above. No other
    // detached surface inherits contact editing or the active new-QSO draft.
    if label == "monitor" && matches!(request["method"].as_str(), Some("logbook_operator_draft" | "lookup_call")) { return Ok(()); }
    if request["method"].as_str().is_some_and(|method| method.starts_with("logbook_operator_draft") || method.starts_with("logbook_contact")) && label != "main" {
        return Err("This window cannot access the logbook editing service.".into());
    }
    if matches!(label, "world-map" | "band-maps") {
        if !matches!(request["method"].as_str(), Some("cluster_snapshot" | "logbook_stats" | "health")) {
            return Err("Detached maps are read-only.".into());
        }
        return Ok(());
    }
    if label == "monitor" {
        let allowed = match request["method"].as_str() {
            Some(
                "station_snapshot" | "cluster_snapshot" | "health" | "station_rotor_snapshot"
                | "station_rotor_goto" | "station_rotor_stop" | "rotor_snapshot"
                | "rotor_goto" | "rotor_stop",
            ) => true,
            _ => false,
        };
        if !allowed {
            return Err("This control is unavailable in the detached monitor.".into());
        }
    }
    Ok(())
}

pub fn validate_request(request: &Value) -> Result<(), String> {
    let object = request.as_object().ok_or("Request must be an object")?;
    let method = request["method"].as_str().ok_or("Method is required")?;
    let trusted_contest_digital_scope = request["operatingModule"] == "contesting"
        && matches!(method,
            "wsjtx_snapshot" | "wsjtx_select" | "wsjtx_configure" | "wsjtx_start" | "wsjtx_stop" |
            "fldigi_snapshot" | "fldigi_rx_text" | "fldigi_select" | "fldigi_accept_completed" | "fldigi_configure" | "fldigi_start" | "fldigi_stop" | "fldigi_send");
    if object
        .keys()
        .any(|key| !["id", "method", "params"].contains(&key.as_str())
            && !(key == "operatingModule" && trusted_contest_digital_scope))
    {
        return Err("Unknown request property".into());
    }
    let id = request["id"].as_str().ok_or("Request ID is required")?;
    if id.is_empty() || id.len() > 128 {
        return Err("Invalid request ID".into());
    }
    if ![
        "health",
        "cw_decode_snapshot",
        "cw_decode_configuration_save",
        "cw_decode_start",
        "cw_decode_stop",
        "cw_decode_listener_start",
        "cw_decode_listener_stop",
        "cw_decode_flex_handoff",
        "parse_adif",
        "self_test",
        "integration_self_test",
        "cluster_classify",
        "contest_catalog",
        "contest_sessions",
        "contest_create",
        "contest_session_create",
        "contest_open",
        "contest_draft_get",
        "contest_draft_apply",
        "contest_lanes_configure",
        "contest_lane_select",
        "contest_lane_context",
        "contest_focus",
        "contest_run_state",
        "contest_cw_context",
        "contest_esm",
        "contest_function_key",
        "contest_output_claim",
        "contest_serial_reserve",
        "contest_qso_commit",
        "contest_qso_get",
        "contest_qso_correct",
        "contest_qso_delete",
        "contest_operation_receipt",
        "contest_log_page",
        "contest_notes",
        "contest_note_save",
        "contest_strategy",
        "contest_strategy_apply",
        "contest_opportunities",
        "contest_operating_info",
        "contest_n1mm_delivery",
        "contest_n1mm_retry",
        "contest_operating_plan_save",
        "contest_message_import",
        "contest_message_preview",
        "contest_message_banks",
        "contest_message_bank_save",
        "contest_message_bank_activate",
        "contest_submission_preflight",
        "contest_assistance_reverse",
        "contest_assistance_dupesheet",
        "contest_legacy_preview",
        "contest_legacy_import",
        "contest_log_transfer_prepare",
        "contest_log_transfer_commit",
        "contest_log_transfer_status",
        "contest_score",
        "contest_spot_points_preview",
        "contest_rates",
        "contest_analytics",
        "contest_recorder_changes",
        "contest_check_partial",
        "contest_setup_get",
        "contest_setup_save",
        "contest_rover_location",
        "contest_statistics",
        "contest_recalculate",
        "contest_multi_serial_reserve",
        "contest_multi_dupe_inquiry",
        "contest_multi_contact_apply",
        "contest_multi_changes",
        "contest_multi_coordination",
        "contest_network_pending",
        "contest_digital_select",
        "contest_multi_replica_apply",
        "contest_export_prepare",
        "contest_export_read",
        "contest_export_release",
        "contest_scp_status",
        "contest_scp_download",
        "contest_scp_import_private",
        "contest_scp_query",
        "contest_scp_cancel",
        "contest_scp_select",
        "contest_history_status",
        "contest_history_preview_private",
        "contest_history_preview_page",
        "contest_history_preview_cancel",
        "contest_history_preview_commit",
        "contest_history_query",
        "contest_history_query_cancel",
        "contest_history_select",
        "contest_history_apply",
        "contest_history_activate",
        "workspace_status",
        "workspace_create",
        "workspace_preferences_load",
        "workspace_preferences_save",
        "workspace_band_map_apply",
        "workspace_logbook_filters_apply",
        "workspace_map_context",
        "workspace_layout_load",
        "workspace_layout_apply",
        "backup_create",
        "backup_list",
        "backup_inspect",
        "backup_import",
        "backup_restore",
        "remote_backup_request",
        "reference_status",
        "reference_resolve",
        "reference_log_review",
        "reference_refresh",
        "reference_schedule",
        "reference_configure",
        "opportunities_snapshot",
        "opportunities_refresh",
        "opportunities_dxpedition_snapshot",
        "opportunities_dxpedition_refresh",
        "logbook_draft",
        "logbook_operator_draft",
        "logbook_operator_draft_apply",
        "logbook_operator_draft_receipt",
        "logbook_operator_draft_qsy_clear",
        "logbook_operator_draft_radio_read",
        "logbook_operator_draft_radio_follow",
        "spot_draft_apply", "spot_draft_status", "spot_draft_stage", "spot_draft_finish", "spot_draft_abandon",
        "logbook_contact",
        "logbook_contact_apply",
        "logbook_contact_receipt",
        "logbook_catalog",
        "logbook_list",
        "logbook_cty_preview",
        "logbook_follow_up",
        "logbook_data_quality",
        "logbook_save",
        "logbook_delete",
        "logbook_undo",
        "logbook_stats",
        "logbook_previous",
        "logbook_duplicate",
        "logbook_matrix",
        "logbook_import_adif",
        "logbook_export_adif",
        "settings_load",
        "settings_receipt",
        "settings_save",
        "workspace_rotor_configuration_load",
        "workspace_rotor_configuration_receipt",
        "workspace_rotor_configuration_save",
        "station_snapshot",
        "connection_doctor_project",
        "operating_goals_evaluate",
        "station_power_selection",
        "station_radio",
        "station_capabilities",
        "station_tune",
        "station_action",
        "station_connect",
        "station_disconnect",
        "station_cat_servers",
        "station_configure",
        "station_configuration",
        "station_configuration_save",
        "station_token_save",
        "station_reconnect",
        "station_forget",
        "station_radio_control",
        "station_rotor_connect",
        "station_rotor_snapshot",
        "station_rotor_disconnect",
        "station_rotor_goto",
        "station_rotor_stop",
        "rotor_snapshot",
        "rotor_connect",
        "rotor_disconnect",
        "rotor_goto",
        "rotor_park",
        "rotor_stop",
        "station_add_spot",
        "station_remove_spot",
        "spot_bridge_snapshot",
        "spot_bridge_configure",
        "spot_bridge_start",
        "spot_bridge_stop",
        "wsjtx_snapshot",
        "wsjtx_configure",
        "wsjtx_start",
        "wsjtx_select",
        "wsjtx_stop",
        "fldigi_snapshot",
        "fldigi_rx_text",
        "fldigi_select",
        "fldigi_accept_completed",
        "fldigi_configure",
        "fldigi_start",
        "fldigi_stop",
        "fldigi_send",
        "cluster_snapshot",
        "cluster_resume",
        "cluster_resume_initialize",
        "cluster_connect",
        "cluster_disconnect",
        "cluster_configure",
        "cluster_radio_spots_configure",
        "cluster_contest_radio_spots_publish",
        "cluster_command",
        "cluster_filter",
        "cluster_password_set",
        "cluster_console_clear",
        "cluster_history",
        "spot_history_status",
        "spot_history_query",
        "spot_history_detail",
        "spot_history_stats",
        "lookup_call",
        "weather",
        "propagation_snapshot",
        "propagation_refresh",
        "secret_save",
        "secret_status",
        "online_log_status",
        "online_log_configure",
        "sync_status",
        "sync_summary",
        "sync_run",
        "sync_configure",
        "sync_resolve",
        "sync_retry",
        "sync_mutation",
        "sync_receipt",
    ]
    .contains(&method)
    {
        return Err("Unknown integration method".into());
    }
    if !request["params"].is_object() {
        return Err("Parameters must be an object".into());
    }
    if serde_json::to_vec(request)
        .map_err(|_| "Invalid request")?
        .len()
        > MAX_REQUEST
    {
        return Err("Request exceeds prototype size limit".into());
    }
    Ok(())
}

fn main() {
    let request=serde_json::json!({"id":"phase6-duplicate","method":"logbook_duplicate","params":{"call":"K1ABC","band":"20m","mode":"CW"}});
    let main=validate_surface("main",&request);
    let detached=validate_surface("log-qso",&request);
    println!("main={main:?} log-qso={detached:?}");
    assert!(main.is_ok()); assert!(detached.is_err());
}
