// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { DetachedQSOSurface, detachedQSOJournalKey } from "/tmp/xlog-phase6-20261029-0ce97a12/agents/frontend/DetachedQSOSurface.baseline";
import { testWorkspaceGeneration } from "/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/tests/operator-draft-fixture";
import type { DraftMutation, DraftPowerState, DraftSnapshot } from "/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/operatorDraftSession";
import { loadWindowSurface } from "/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/windowSurface";

const api = vi.hoisted(() => ({ draft: vi.fn(), read: vi.fn(), invoke: vi.fn(), reconcile: vi.fn(), changes: vi.fn(), protect: vi.fn(), dock: vi.fn(),
  readiness: null as null | ((snapshot: any) => { ready: boolean }),
  refresh: null as (() => Promise<void>) | null, blocked: null as (() => boolean) | null, explain: null as (() => void) | null,
  closeState: null as ((value: boolean) => void) | null }));
vi.mock("/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/operatorDraftTransport", () => ({ requestOperatorDraft: api.draft }));
vi.mock("/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/worker", () => ({ workerRequest: api.read }));
vi.mock("/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/operatorDraftWindows", () => ({ connectOperatorDraftChanges: api.changes, protectOperatorDraftClose: api.protect }));
vi.mock("/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/DetachedClusterBridge", () => ({ dockDetachedWorkspace: api.dock }));
vi.mock("@tauri-apps/api/core", () => ({ invoke: api.invoke, isTauri: () => false }));
vi.mock("/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/useSpotEditor", () => ({ nativeSpotEditor: () => false, useSpotEditor: (_participants: any[], readiness: (snapshot: any) => { ready: boolean }) => { api.readiness = readiness; return {
  status: { phase: "uncertain", tuneConfirmed: false, rotor: "uncertain" }, error: "Global activation warning", reconcile: api.reconcile,
}; } }));

const copy = <T,>(value: T): T => structuredClone(value);
function backend() {
  const id = crypto.randomUUID();
  const qso = { id, call: "K1ABC", start: "2026-10-14T00:00:00Z", end: null, band: "20m", mode: "CW",
    frequencyHz: 14_025_000, txPower: "100", notes: "", name: "", rstSent: "599", rstReceived: "599", extraFields: { OTHER: "keep" } };
  const power: DraftPowerState = { revision: 0, enabled: true, fallback: "100", manualOverride: false, selectedValue: "100",
    contact: { workspaceID: testWorkspaceGeneration, draftID: id, call: "K1ABC", band: "20m", mode: "CW", frequencyHz: 14_025_000 } };
  let current: DraftSnapshot = { generation: testWorkspaceGeneration, revision: 0, qso, power, automaticStart: true };
  const receipts = new Map<string, any>(), contacts: any[] = [];
  const request = async (method: string, params: any = {}) => {
    if (method === "logbook_operator_draft") return { draft: copy(current) };
    if (params.generation !== current.generation) return { status: "workspace_changed", generation: current.generation };
    if (method === "logbook_operator_draft_receipt") return { receipt: copy(receipts.get(params.operationID) ?? null) };
    if (method !== "logbook_operator_draft_apply") throw new Error(`Unexpected ${method}`);
    const mutation = params as DraftMutation;
    if (receipts.has(mutation.operationID)) return { status: "applied", receipt: copy(receipts.get(mutation.operationID)) };
    if (mutation.draftID !== current.qso.id || mutation.expectedRevision !== current.revision) return { status: "conflict", draft: copy(current) };
    const savedQSO = mutation.action === "save" ? copy(current.qso) : null;
    if (savedQSO && current.automaticStart) savedQSO.start = new Date().toISOString();
    if (savedQSO) contacts.push(savedQSO);
    const next = mutation.action === "replace" ? copy(mutation.qso!) : { ...qso, id: crypto.randomUUID(), call: "" };
    const nextPower = copy(current.power!);
    nextPower.contact = { workspaceID: testWorkspaceGeneration, draftID: next.id, call: String(next.call).trim().toUpperCase(),
      band: next.band, mode: next.mode, frequencyHz: next.frequencyHz };
    if (mutation.powerIntent || mutation.action !== "replace") {
      nextPower.revision++; nextPower.selectedSample = null; nextPower.selectedContext = null; nextPower.selectedContact = null;
      nextPower.activeScope = null; nextPower.sessionPeak = null; nextPower.lastObservedAt = null;
    }
    if (mutation.powerIntent?.action === "manual") { nextPower.manualOverride = true; nextPower.selectedValue = mutation.powerIntent.value; }
    if (mutation.powerIntent?.action === "automatic" || mutation.action !== "replace") { nextPower.manualOverride = false; nextPower.selectedValue = nextPower.fallback; }
    next.txPower = nextPower.selectedValue;
    const automaticStart = mutation.action !== "replace" ||
      current.automaticStart === true && next.start === current.qso.start && next.end === current.qso.end;
    current = { generation: testWorkspaceGeneration, revision: current.revision + 1, qso: next, power: nextPower, automaticStart };
    const receipt = { mutation: copy(mutation), draft: copy(current), savedQSO };
    receipts.set(mutation.operationID, receipt);
    return { status: "applied", receipt: copy(receipt) };
  };
  const meter = (watts: number) => {
    const sessionID = crypto.randomUUID(), time = "2026-10-14T00:00:01Z";
    const sample = { source: "kpa500_output" as const, unit: "W" as const, watts, sessionID,
      observedAt: time, radioObservedAt: time, receivedAt: time, amplifierObservedAt: time };
    const context = { providerID: "fixture", selectionID: "fixture", sessionID, sessionStartedAt: "2026-10-14T00:00:00Z",
      source: "direct_agent" as const, meterSource: "kpa500_output" as const };
    current = { ...current, qso: { ...current.qso, txPower: String(watts) }, power: { ...current.power!,
      revision: current.power!.revision + 1, selectedValue: String(watts), selectedSample: sample,
      selectedContext: context, selectedContact: copy(current.power!.contact), lastContext: context } };
  };
  return { request, contacts, meter, get current() { return current; }, change: (draft: DraftSnapshot) => { current = copy(draft); } };
}
function journal() { return JSON.parse(localStorage.getItem(detachedQSOJournalKey) || "null"); }
function deferred<T>() { let resolve!: (value: T) => void; const promise = new Promise<T>(done => { resolve = done; }); return { promise, resolve }; }
beforeEach(() => {
  vi.resetAllMocks(); localStorage.clear(); api.refresh = null; api.blocked = null; api.explain = null; api.closeState = null;
  api.changes.mockImplementation(refresh => { api.refresh = refresh; void refresh(); return vi.fn(); });
  api.protect.mockImplementation((blocked, explain, _failed, closeState) => { api.blocked = blocked; api.explain = explain; api.closeState = closeState; return vi.fn(); });
  api.dock.mockResolvedValue(undefined);
  api.reconcile.mockResolvedValue(true);
  api.read.mockImplementation(async (method, params) => ({ result: method === "lookup_call" ? { call: params.call, source: "Local fixture" }
    : method === "logbook_previous" ? { qsos: [] } : { cells: [] } }));
});
afterEach(() => { cleanup(); vi.useRealTimers(); });


it("PHASE6 immediate valid manual UTC remount must preserve displayed date", async () => {
  const f = backend(); api.draft.mockImplementation(f.request);
  vi.setSystemTime(new Date("2026-10-28T12:34:56Z"));
  render(<DetachedQSOSurface />); await screen.findByDisplayValue("K1ABC");
  fireEvent.change(screen.getByLabelText("Start UTC date"), { target: { value: "2026-10-20" } });
  fireEvent.change(screen.getByLabelText("Start UTC time"), { target: { value: "10:15:30" } });
  expect(journal().draft.start).toBe("2026-10-20T10:15:30Z");
  expect(journal().base.automaticStart).toBe(true);
  fireEvent.click(screen.getByRole("button", { name: "Simple" }));
  expect((screen.getByLabelText("Desk UTC date") as HTMLInputElement).value).toBe("2026-10-20");
});

it("PHASE6 evidence: pre-flush remount shows wall clock but direct Save retains manual value", async () => {
  const f = backend(); api.draft.mockImplementation(f.request);
  vi.setSystemTime(new Date("2026-10-28T12:34:56Z"));
  render(<DetachedQSOSurface />); await screen.findByDisplayValue("K1ABC");
  fireEvent.change(screen.getByLabelText("Start UTC date"), { target: { value: "2026-10-20" } });
  fireEvent.change(screen.getByLabelText("Start UTC time"), { target: { value: "10:15:30" } });
  const before = journal();
  fireEvent.click(screen.getByRole("button", { name: "Simple" }));
  const shown = {date:(screen.getByLabelText("Desk UTC date") as HTMLInputElement).value,time:(screen.getByLabelText("Desk UTC time") as HTMLInputElement).value};
  console.log("PHASE6_PRE_FLUSH", JSON.stringify({before,shown,applyCalls:api.draft.mock.calls.filter(([m]) => m === "logbook_operator_draft_apply")}));
  expect(shown).toEqual({date:"2026-10-28",time:"12:34:56"});
  fireEvent.click(screen.getByRole("button", { name: "Log QSO" }));
  await waitFor(() => expect(f.contacts).toHaveLength(1));
  console.log("PHASE6_SAVED", JSON.stringify({saved:f.contacts[0],applyCalls:api.draft.mock.calls.filter(([m]) => m === "logbook_operator_draft_apply")}));
  expect(f.contacts[0].start).toBe("2026-10-20T10:15:30Z");
});

it("PHASE6 evidence: next manual edit after pre-flush remount replaces the earlier manual date", async () => {
  const f = backend(); api.draft.mockImplementation(f.request);
  vi.setSystemTime(new Date("2026-10-28T12:34:56Z"));
  render(<DetachedQSOSurface />); await screen.findByDisplayValue("K1ABC");
  fireEvent.change(screen.getByLabelText("Start UTC date"), { target: { value: "2026-10-20" } });
  fireEvent.change(screen.getByLabelText("Start UTC time"), { target: { value: "10:15:30" } });
  fireEvent.click(screen.getByRole("button", { name: "Simple" }));
  fireEvent.change(screen.getByLabelText("Desk UTC time"), {target:{value:"11:11:11"}});
  expect(journal().draft.start).toBe("2026-10-28T11:11:11Z");
  fireEvent.click(screen.getByRole("button", { name: "Log QSO" }));
  await waitFor(() => expect(f.contacts).toHaveLength(1));
  console.log("PHASE6_NEXT_EDIT_SAVED", JSON.stringify(f.contacts[0]));
  expect(f.contacts[0].start).toBe("2026-10-28T11:11:11Z");
});
