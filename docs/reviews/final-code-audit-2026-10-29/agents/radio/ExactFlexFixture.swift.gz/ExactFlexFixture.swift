import Foundation
import XCatIntegrationCore
@testable import XLogPrototypeSupport
final class FlexFixtureBox: @unchecked Sendable {
    private let lock = NSLock()
    private var stored: FakeFlexRadio?
    func store(_ value: FakeFlexRadio) { lock.withLock { stored = value } }
    func get() -> FakeFlexRadio? { lock.withLock { stored } }
}

actor FakeFlexRadio: FlexSessionRadio {
    private var value: RadioSnapshot
    private let onSnapshot: FlexRadioClient.SnapshotHandler
    private let onState: FlexRadioClient.StateHandler
    private var commands: [String] = []
    private var observeRelease = true
    private var observeTune = true
    private var observeTransmitStart = true
    private var transmitRevision: UInt64? = 1
    private var powerRevision: UInt64 = 0
    private var powerReadback: Int?
    private var rejectPower = false

    init(snapshot: RadioSnapshot, onState: @escaping FlexRadioClient.StateHandler,
         onSnapshot: @escaping FlexRadioClient.SnapshotHandler) {
        value = snapshot
        powerReadback = snapshot.rfPowerLevel
        if powerReadback != nil { powerRevision = 1 }
        self.onState = onState
        self.onSnapshot = onSnapshot
    }

    func start() {
        onState(.ready, "fixture")
        onSnapshot(value)
    }
    func reconnectNow() { start() }
    func stopTransportOnly() { commands.append("stop_transport") }
    func snapshot() -> RadioSnapshot { value }
    func commandLog() -> [String] { commands }
    func setObserveRelease(_ value: Bool) { observeRelease = value }
    func setObserveTune(_ value: Bool) { observeTune = value }
    func setObserveTransmitStart(_ value: Bool) { observeTransmitStart = value }
    func simulateState(_ state: RadioConnectionState) { onState(state, "fixture") }
    func simulateUnrelatedSnapshot() { onSnapshot(value) }
    func setPowerReadback(_ watts: Int?) { powerReadback = watts }
    func setRejectPower(_ reject: Bool) { rejectPower = reject }
    func simulatePowerStatus(_ watts: Int) {
        value.rfPowerLevel = watts
        powerRevision &+= 1
        onSnapshot(value)
    }
    func rfPowerObservation() -> FlexRadioClient.RFPowerObservation? {
        guard let level = value.rfPowerLevel, powerRevision > 0 else { return nil }
        return .init(revision: powerRevision, level: level, isConnected: value.isConnected)
    }
    func transmitObservation() -> FlexRadioClient.TransmitObservation? {
        guard let transmitRevision else { return nil }
        return .init(revision: transmitRevision, isTransmitting: value.isTransmitting,
                     isConnected: value.isConnected)
    }
    func setTransmitObservationKnown(_ known: Bool) { transmitRevision = known ? 1 : nil }
    func simulateInterlock(_ transmitting: Bool, publish: Bool) {
        value.isTransmitting = transmitting
        transmitRevision = (transmitRevision ?? 0) &+ 1
        if publish { onSnapshot(value) }
    }

    func primaryFrequency() -> Int64? { value.vfo("A")?.frequencyHz }
    func setPrimaryFrequency(_ frequencyHz: Int64) {
        commands.append("frequency_a")
        value.vfos = value.vfos.map { vfo in
            var copy = vfo
            if copy.letter == "A" { copy.frequencyHz = frequencyHz }
            return copy
        }
        if value.slice == "A" { value.frequencyHz = frequencyHz }
        if value.transmitSlice == "A" { value.transmitFrequencyHz = frequencyHz }
        onSnapshot(value)
    }
    func setPrimaryMode(_ mode: String) {
        commands.append("mode_a")
        value.vfos = value.vfos.map { vfo in
            var copy = vfo
            if copy.letter == "A" { copy.mode = mode }
            return copy
        }
        if value.slice == "A" { value.mode = mode }
        onSnapshot(value)
    }
    func setFrequency(_ frequencyHz: Int64) {
        commands.append("frequency")
        value.frequencyHz = frequencyHz
        value.vfos = value.vfos.map { vfo in
            var copy = vfo
            if copy.isReceive { copy.frequencyHz = frequencyHz }
            return copy
        }
        onSnapshot(value)
    }
    func setMode(_ mode: String) {
        commands.append("mode")
        value.mode = mode
        value.vfos = value.vfos.map { vfo in
            var copy = vfo
            if copy.isReceive { copy.mode = mode }
            return copy
        }
        onSnapshot(value)
    }
    func setFrequencyAndMode(_ frequencyHz: Int64, mode: String) {
        commands.append("frequency_mode")
        if observeTune {
            value.frequencyHz = frequencyHz
            value.transmitFrequencyHz = frequencyHz
            value.mode = mode
            value.vfos = value.vfos.map { vfo in
                var copy = vfo
                if copy.letter == "A" { copy.frequencyHz = frequencyHz; copy.mode = mode }
                return copy
            }
            onSnapshot(value)
        }
    }
    func setTransmit(_ enabled: Bool) {
        commands.append(enabled ? "ptt_on" : "ptt_off")
        if enabled && !observeTransmitStart {return}
        if enabled || observeRelease {
            value.isTransmitting = enabled
            transmitRevision = (transmitRevision ?? 0) &+ 1
            onSnapshot(value)
        }
    }
    func setTransmit(_ mode: CATTransmitMode) {
        commands.append("tune_on")
        if !observeTransmitStart { return }
        value.isTransmitting = true
        transmitRevision = (transmitRevision ?? 0) &+ 1
        onSnapshot(value)
    }
    func secondaryFrequency() -> Int64? { value.vfo("B")?.frequencyHz }
    func setSecondaryFrequency(_ frequencyHz: Int64) {
        commands.append("frequency_b")
        value.vfos = value.vfos.map { vfo in
            var copy = vfo
            if copy.letter == "B" { copy.frequencyHz = frequencyHz }
            return copy
        }
        if value.slice == "B" { value.frequencyHz = frequencyHz }
        if value.transmitSlice == "B" { value.transmitFrequencyHz = frequencyHz }
        onSnapshot(value)
    }
    func setSplitTransmit(_ enabled: Bool) {
        commands.append(enabled ? "split_on" : "split_off")
        value.transmitSlice = enabled ? "B" : "A"
        if !enabled { value.transmitFrequencyHz = value.vfo("A")?.frequencyHz ?? value.frequencyHz }
        value.vfos = value.vfos.map { vfo in
            var copy = vfo
            copy.isTransmit = copy.letter == value.transmitSlice
            return copy
        }
        onSnapshot(value)
    }
    func setReceiveVFO(_ vfo: Int) {
        commands.append(vfo == 0 ? "receive_a" : "receive_b")
        value.slice = vfo == 0 ? "A" : "B"
        value.frequencyHz = value.vfo(value.slice)?.frequencyHz ?? value.frequencyHz
        value.mode = value.vfo(value.slice)?.mode ?? value.mode
        value.vfos = value.vfos.map { vfo in
            var copy = vfo
            copy.isReceive = copy.letter == value.slice
            return copy
        }
        onSnapshot(value)
    }
    func setRFPower(_ watts: Int) throws {
        commands.append("rf_power_\(watts)")
        if rejectPower { throw XCatError.server("Rejected") }
        if let powerReadback { simulatePowerStatus(powerReadback) }
    }
    func cwSpeed() -> Int { 25 }
    func setCWSpeed(_ wordsPerMinute: Int) { commands.append("cw_speed") }
    func sendCW(_ text: String) { commands.append("cw_send") }
    func clearCW() {
        commands.append("cw_clear")
        if observeRelease {
            value.isTransmitting = false
            transmitRevision = (transmitRevision ?? 0) &+ 1
            onSnapshot(value)
        }
    }
}
