// swift-tools-version: 5.10
import PackageDescription
let package = Package(name: "PortableIQManifestRegression", platforms: [.macOS(.v14)], targets: [
    .target(name: "XCatIntegrationCore"),
    .testTarget(name: "PortableIQTests", dependencies: ["XCatIntegrationCore"])
])
