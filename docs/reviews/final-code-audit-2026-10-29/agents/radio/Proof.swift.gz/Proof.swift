import Foundation
import XLogCore
import XCatIntegrationCore
@testable import XLogPrototypeSupport

enum ProofError: Error { case timeout, closed }
actor ProofSocket: TCIWebSocketConnection {
    var waiter: CheckedContinuation<TCIWebSocketMessage, Error>?
    var queued: [TCIWebSocketMessage] = []
    var sent: [String] = []
    func receive() async throws -> TCIWebSocketMessage {
        if !queued.isEmpty { return queued.removeFirst() }
        return try await withCheckedThrowingContinuation { waiter = $0 }
    }
    func send(text: String) { sent.append(text) }
    func close() { waiter?.resume(throwing: ProofError.closed); waiter = nil }
    func push(_ text: String) {
        if let waiter { self.waiter = nil; waiter.resume(returning: .text(text)) }
        else { queued.append(.text(text)) }
    }
    func sentCount() -> Int { sent.count }
}
struct ProofConnector: TCIWebSocketConnecting {
    let socket: ProofSocket
    func connect(to: URL) -> any TCIWebSocketConnection { socket }
}
final class ProofClock: @unchecked Sendable {
    let lock = NSLock(); var date = Date(timeIntervalSince1970: 1000)
    func now() -> Date { lock.withLock { date } }
    func advance() { lock.withLock { date.addTimeInterval(1) } }
}

@main struct Proof {
    static func main() async throws {
        let gate = NativeDraftPowerGate(), first = UUID(), second = UUID(), one = UUID(), two = UUID()
        let start = Date()
        gate.attach(sourceID: first, endpointID: "radio1", radioID: "radio1")
        gate.connection(sourceID: first, sequence: 1, sessionID: one, startedAt: start, ready: true)
        gate.attach(sourceID: second, endpointID: "radio2", radioID: "radio2")
        gate.connection(sourceID: second, sequence: 1, sessionID: two, startedAt: start, ready: true)
        gate.select(provider: "direct_agent", selectionID: "selection1", radioID: "radio1")
        print("POWER activeRadio=radio1 beforeInactivePublication=\(gate.state().context?.providerID ?? "nil")")
        gate.select(provider: "direct_agent", selectionID: "selection2", radioID: "radio2")
        print("POWER activeRadio=radio1 afterInactivePublication=\(gate.state().context?.providerID ?? "nil")")
        gate.select(provider: nil, selectionID: nil, radioID: "radio2")
        print("POWER activeRadio=radio1 afterInactiveDisconnect=\(gate.state().context?.providerID ?? "nil")")

        let root = URL(fileURLWithPath: "/tmp/xlog-phase6-20261029-0ce97a12/agents/radio/flex-private")
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let box = FlexFixtureBox()
        let owner = LiveFlexSession(readbackTimeout: .milliseconds(50)) { _, state, snapshot in
            let radio = FakeFlexRadio(snapshot: XCatIntegrationCore.RadioSnapshot(frequencyHz: 14_074_000), onState: state, onSnapshot: snapshot)
            box.store(radio); return radio
        }
        let registry = StationRadioRegistry(flex: ["radio1": owner, "radio2": LiveFlexSession()])
        let worker = LiveWorker(logbook: LiveLogbookMethods(supportDirectory: root, inheritNativePreferences: false),
            runtimeProfile: .contestingTest(supportRoot: root), stationRegistry: registry)
        _ = try await LiveStationMethods.handle("station_connect", params: ["provider": "direct_flex_lan", "radio_id": "radio1", "host": "192.168.1.20", "station_name": "fixture", "allow_transmit": true], registry: registry)
        for _ in 0..<1000 {
            let state = try await owner.handle("station_snapshot", params: ["provider": "direct_flex_lan"])
            if state["available"] as? Bool == true { break }; await Task.yield()
        }
        _ = try await owner.handle("station_radio_control", params: ["provider": "direct_flex_lan", "control": "ptt", "enabled": true])
        guard let radio = box.get() else { throw ProofError.timeout }
        await radio.setObserveRelease(false)
        let outcome = await worker.shutdownOutcome()
        print("FLEX workerOutcome=\(outcome) permitsRestart=\(outcome.permitsRestart) ownerStillAttached=\(await owner.isAttached()) commands=\(await radio.commandLog())")
        do { _ = try await owner.handle("station_radio_control", params: ["provider": "direct_flex_lan", "control": "ptt", "enabled": false]); print("FLEX retry unexpectedly admitted") }
        catch { print("FLEX retry after terminal=\(error)") }

        let socket = ProofSocket(), clock = ProofClock()
        let session = TCIReadOnlyWebSocketSession(endpoint: URL(string: "ws://127.0.0.1:40001")!, configuredAddress: .init(trx: 0, channel: 0), connector: ProofConnector(socket: socket), clock: { clock.now() })
        try await session.connect()
        await socket.push("protocol:ExpertSDR3,1.8;device:SunSDR2PRO;receive_only:false;trx_count:2;channels_count:2;vfo_limits:0.0,160000000.0;if_limits:-156250,156250;modulations_list:AM,LSB,USB,CW,FT8;vfo:0,0,14025000;modulation:0,CW;rx_filter_band:0,-500,500;rx_enable:0,true;tx_enable:0,true;split_enable:0,false;trx:0,false;tune:0,false;ready;")
        for _ in 0..<10000 { if await session.currentObservation().availability == .available { break }; await Task.yield() }
        let before = await session.currentObservation()
        let pending = Task { try await session.tuneReceive(frequencyHz: 14_025_000, mode: "CW", expectedGeneration: before.generation, timeoutNanoseconds: 1_000_000_000) }
        for _ in 0..<10000 { if await socket.sentCount() > 0 { break }; await Task.yield() }
        clock.advance(); await socket.push("ready;")
        do { let confirmed = try await pending.value; print("TCI sameTargetConfirmedWithOnlyREADY=\(confirmed.sequence > before.sequence) frequency=\(confirmed.snapshot?.frequencyHz ?? -1) mode=\(confirmed.snapshot?.transceiver.modulation ?? "nil")") }
        catch { print("TCI correctly rejected sameTargetOnlyREADY=\(error)") }
        await session.disconnect()
    }
}
