import Foundation
import XLogCore
@main struct Proof {
 static func main() throws {
  let root=URL(fileURLWithPath:"/tmp/xlog-phase6-20261029-0ce97a12/agents/persistence/restore-runtime")
  try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true)
  let fixture=root.appendingPathComponent(UUID().uuidString)
  try FileManager.default.createDirectory(at:fixture,withIntermediateDirectories:true)
  defer { try? FileManager.default.removeItem(at:fixture) }
  let a=try LogbookDatabase(url:fixture.appendingPathComponent("sourceA.sqlite"))
  let original=QSO(wavelogID:42,call:"K1BACKUP",start:Date(timeIntervalSince1970:1700000000),band:"20m",mode:"CW")
  try a.save(original,markDirty:false)
  var settingsA=XLogSettings.defaults
  settingsA.wavelogURL="https://destination-a.invalid";settingsA.wavelogStationID=1;settingsA.automaticSync=true
  let preferences=XLogBackupPreferences(deskBandMapBands:[],detachedBandMapBands:[],deskBandMapFollowsRadio:false,detachedBandMapLayout:"",bandMapFontScale:1,intelligenceBands:[],clusterSpotOpensFullEditor:false)
  let manager=XLogBackupManager()
  let preview=try manager.create(database:a,at:fixture.appendingPathComponent("backup.xlogbackup"),settings:settingsA,preferences:preferences)
  a.close()
  let live=fixture.appendingPathComponent("live/OM0RX-xLog.sqlite")
  let b=try LogbookDatabase(url:live)
  try b.save(QSO(wavelogID:42,call:"W9BEFORE",band:"40m",mode:"SSB"),markDirty:false)
  var settingsB=XLogSettings.defaults
  settingsB.wavelogURL="https://destination-b.invalid";settingsB.wavelogStationID=2;settingsB.automaticSync=true
  // Same real-core sequence as retained AppModel's keep-settings path:
  // recovery backup -> close -> installDatabase -> reopen; no provider calls.
  _ = try manager.create(database:b,at:fixture.appendingPathComponent("recovery.xlogbackup"),settings:settingsB,preferences:preferences)
  b.close()
  _ = try manager.installDatabase(from:preview.packageURL,to:live)
  let restored=try LogbookDatabase(url:live);defer { restored.close() }
  let retained=try restored.lookup(localID:original.id)!
  print("backup destination:",preview.settings!.wavelogURL,preview.settings!.wavelogStationID)
  print("retained current destination:",settingsB.wavelogURL,settingsB.wavelogStationID,"automaticSync:",settingsB.automaticSync)
  print("after installDatabase:",retained.call,"linkedID:",retained.wavelogID!,"dirty:",retained.isDirty)
  let bRemote=QSO(wavelogID:42,call:"W9DESTB",start:Date(timeIntervalSince1970:1800000000),band:"40m",mode:"SSB")
  _ = try restored.mergeRemote(bRemote)
  print("after actual B-ID42 merge:",try restored.lookup(localID:original.id)!.call,"rows:",try restored.count())
  let recovery=try LogbookDatabase(url:fixture.appendingPathComponent("recovery.xlogbackup/OM0RX-xLog.sqlite"));defer { recovery.close() }
  print("pre-restore recovery retains:",try recovery.fetchAll().first!.call)
 }
}
