import Foundation

/// The retained native application's restore sequence. The caller preserves the
/// recovery package and closes its live connection before handing over ownership.
public final class NativeBackupRestoreOwner: @unchecked Sendable {
    private let manager: XLogBackupManager
    private let settingsStore: SettingsStore
    internal var afterDatabasePublication: @Sendable () throws -> Void = {}

    public init(settingsStore: SettingsStore, manager: XLogBackupManager = XLogBackupManager()) {
        self.settingsStore = settingsStore
        self.manager = manager
    }

    public static func openDatabase(at url: URL, settings: XLogSettings) throws -> LogbookDatabase {
        try LogbookDatabase(url: url)
    }

    public func restore(preview: XLogBackupPreview, to liveURL: URL,
                        keeping currentSettings: XLogSettings, settingsAfterRestore: XLogSettings,
                        recoveryPackageURL: URL, referenceDataURL: URL?) throws -> LogbookDatabase {
        var paused = currentSettings
        paused.automaticSync = false
        settingsStore.save(paused)
        _ = try manager.installDatabase(from: preview.packageURL, to: liveURL, expectedPreview: preview)
        try afterDatabasePublication()
        settingsStore.save(settingsAfterRestore)
        if preview.manifest.includesReferenceData, let referenceDataURL {
            _ = try manager.installReferenceData(from: preview.packageURL, to: referenceDataURL)
        }
        return try Self.openDatabase(at: liveURL, settings: settingsAfterRestore)
    }
}
