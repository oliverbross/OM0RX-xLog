#if os(macOS)
import Foundation
import XCTest
import XCatIntegrationCore
#if canImport(XLogCore)
import XLogCore
#else
import XLogPortableCore
#endif
@testable import XLogPrototypeSupport

/// Every request is intercepted; the production client still signs, encodes,
/// validates and decodes the actual Agent protocol.
private final class AgentLifecycleScript: @unchecked Sendable {
    struct Packet {
        let host: String
        let authorization: String?
        let command: String
        let arguments: [String: Any]
        let timeout: TimeInterval
    }
    private let lock = NSLock()
    private var packets: [Packet] = []
    private var failures = Set<String>()
    private var transmitting = false
    private var revision = 0
    private var holdState = false
    private var held: (() -> Void)?
    private var requestedState = false

    var sent: [Packet] { lock.withLock { packets } }
    var stateRequested: Bool { lock.withLock { requestedState } }
    func fail(_ command: String?) { lock.withLock { failures = command.map { [$0] } ?? [] } }
    func pauseState() { lock.withLock { holdState = true } }
    func releaseState() {
        let callback = lock.withLock { () -> (() -> Void)? in
            holdState = false; defer { held = nil }; return held
        }
        callback?()
    }
    func delayState(_ callback: @escaping () -> Void) -> Bool {
        lock.withLock {
            requestedState = true
            guard holdState else { return false }
            held = callback; return true
        }
    }
    func response(_ request: URLRequest) throws -> Data {
        let envelope: [String: Any] = try lock.withLock {
            revision += 1
            if request.httpMethod == "POST" {
                let body = try Self.body(request)
                let object = try XCTUnwrap(JSONSerialization.jsonObject(with: body) as? [String: Any])
                let command = try XCTUnwrap(object["command"] as? String)
                let arguments = object["arguments"] as? [String: Any] ?? [:]
                packets.append(Packet(host: request.url?.host ?? "", authorization: request.value(forHTTPHeaderField: "Authorization"),
                    command: command, arguments: arguments, timeout: request.timeoutInterval))
                if failures.contains(command) { return ["success": false, "error": ["code": "fixture-release-failed", "message": "Injected release rejection"]] }
                if command == "send_cw" || command == "station_tune" { transmitting = true }
                if command == "set_ptt" { transmitting = arguments["enabled"] as? Bool ?? false }
                if command == "station_cancel" || command == "clear_cw" { transmitting = false }
                // A harmless control reply supplies actual, authoritative meter
                // evidence for an externally transmitting monitored station.
                if command == "set_cw_speed" { transmitting = true }
            }
            let now = Date(), formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            return ["success": true, "state": ["protocol_version": 1, "revision": revision,
                "capabilities": ["commands": ["send_cw", "clear_cw", "set_ptt", "station_tune", "station_cancel", "set_cw_speed"]],
                "station": ["commissioned": true, "coordinator_state": "safe_rx", "allowed_actions": ["tune", "cancel"]],
                "radio": ["connected": true, "known": true, "stale": false, "station_bound": true,
                    "mox": transmitting, "frequency_hz": 14_025_000, "mode": "CW", "observed_at": formatter.string(from: now)],
                "elecraft": ["kpa500": ["enabled": true, "connected": true, "operate": true, "quality": "good", "fault": "00",
                    "output_power_w": 450, "observed_at": now.timeIntervalSince1970,
                    "meter_observed_at": now.timeIntervalSince1970, "meter_sample_observed_at": now.timeIntervalSince1970,
                    "meter_complete": true, "meter_error": NSNull()]]]]
        }
        return try JSONSerialization.data(withJSONObject: envelope)
    }
    private static func body(_ request: URLRequest) throws -> Data {
        if let data = request.httpBody { return data }
        let stream = try XCTUnwrap(request.httpBodyStream)
        stream.open(); defer { stream.close() }
        var data = Data(), buffer = [UInt8](repeating: 0, count: 4096)
        while true {
            let count = stream.read(&buffer, maxLength: buffer.count)
            if count < 0 { throw URLError(.cannotDecodeContentData) }
            if count == 0 { return data }
            data.append(buffer, count: count)
        }
    }
}

private final class AgentLifecycleProtocol: URLProtocol {
    private static let lock = NSLock()
    private static var scripts: [String: AgentLifecycleScript] = [:]
    static func install(_ script: AgentLifecycleScript, host: String) { lock.withLock { scripts[host] = script } }
    static func remove(_ host: String) { _ = lock.withLock { scripts.removeValue(forKey: host) } }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        guard let script = Self.lock.withLock({ Self.scripts[request.url?.host ?? ""] }) else {
            client?.urlProtocol(self, didFailWithError: URLError(.unsupportedURL)); return
        }
        if request.httpMethod == "GET", script.delayState({ [self] in deliver(script) }) { return }
        deliver(script)
    }
    private func deliver(_ script: AgentLifecycleScript) {
        do {
            let data = try script.response(request)
            let response = try XCTUnwrap(HTTPURLResponse(url: XCTUnwrap(request.url), statusCode: 200, httpVersion: "HTTP/1.1", headerFields: nil))
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}

final class DirectAgentLifecycleTests: XCTestCase {
    private struct Fixture {
        let registry: StationRadioRegistry
        let scripts: [String: AgentLifecycleScript]
        let sessions: [URLSession]
        let hosts: [String]
        func close() { sessions.forEach { $0.invalidateAndCancel() }; hosts.forEach(AgentLifecycleProtocol.remove) }
    }
    private func fixture() -> Fixture {
        var agents: [String: LiveStationSession] = [:], scripts: [String: AgentLifecycleScript] = [:]
        var sessions: [URLSession] = [], hosts: [String] = []
        for radio in ["radio1", "radio2"] {
            let host = "\(radio)-\(UUID().uuidString.lowercased()).invalid", script = AgentLifecycleScript()
            let configuration = URLSessionConfiguration.ephemeral; configuration.protocolClasses = [AgentLifecycleProtocol.self]
            let session = URLSession(configuration: configuration)
            AgentLifecycleProtocol.install(script, host: host)
            var credentials = StationAgentCredentialCache(); credentials.remember("fixture-\(radio)", endpoint: "https://\(host)")
            agents[radio] = LiveStationSession(radioID: radio, credentialCache: credentials) { endpoint, token, state, observed in
                try RemoteAgentClient(baseURL: endpoint, token: token, session: session, onState: state,
                    onObservedSnapshot: observed, enableStream: false)
            }
            scripts[radio] = script; sessions.append(session); hosts.append(host)
        }
        return Fixture(registry: StationRadioRegistry(agents: agents), scripts: scripts, sessions: sessions, hosts: hosts)
    }
    private func connect(_ fixture: Fixture, radio: String, transmit: Bool = true) async throws {
        let index = radio == "radio1" ? 0 : 1
        _ = try await LiveStationMethods.handle("station_connect", params: ["provider": "direct_agent", "radio_id": radio,
            "base_url": "https://\(fixture.hosts[index])", "allow_transmit": transmit], registry: fixture.registry)
        try await ready(fixture.registry.agents[radio]!)
    }
    private func ready(_ owner: LiveStationSession) async throws {
        for _ in 0..<1000 {
            let state = await owner.snapshot()
            if state["transport_state"] as? String == "ready" { return }
            try await Task.sleep(for: .milliseconds(2))
        }
        XCTFail("Intercepted Agent did not become ready"); throw URLError(.timedOut)
    }
    private func request(_ worker: LiveWorker, _ method: String, radio: String, extra: [String: Any] = [:]) async throws -> [String: Any] {
        var params: [String: Any] = ["provider": "direct_agent", "radio_id": radio]
        params.merge(extra) { _, value in value }
        let data = try JSONSerialization.data(withJSONObject: ["id": UUID().uuidString, "method": method, "params": params])
        let reply = await worker.response(to: data)
        return try XCTUnwrap(JSONSerialization.jsonObject(with: reply) as? [String: Any])
    }
    private func releaseFailure(_ acquisition: String, failedCommand: String, radio: String) async throws {
        let fixture = fixture(); defer { fixture.close() }
        try await connect(fixture, radio: radio)
        let other = radio == "radio1" ? "radio2" : "radio1"
        try await connect(fixture, radio: other, transmit: false)
        let script = try XCTUnwrap(fixture.scripts[radio]), owner = try XCTUnwrap(fixture.registry.agents[radio])
        if acquisition == "tune" { _ = try await owner.action("tune") }
        else { _ = try await owner.handle("station_radio_control", params: ["provider": "direct_agent", "control": acquisition,
            "enabled": true, "text": "TEST"]) }
        script.fail(failedCommand)
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("agent-retirement-\(UUID())")
        defer { try? FileManager.default.removeItem(at: root) }
        let worker = LiveWorker(logbook: LiveLogbookMethods(supportDirectory: root, inheritNativePreferences: false), stationRegistry: fixture.registry)
        let outcome = await worker.shutdownOutcome()
        XCTAssertEqual(outcome, .stationRetirementUnconfirmed)
        XCTAssertFalse(outcome.permitsRestart)
        let state = await owner.snapshot()
        XCTAssertFalse(state["radio"] is NSNull, "Original Agent client must remain available for release-only retry")
        let retirement = await fixture.registry.terminate()
        XCTAssertEqual(retirement.unconfirmedRadioIDs, [radio])
        XCTAssertTrue(fixture.scripts[other]!.sent.isEmpty, "Passive peer must receive no release command")
        XCTAssertTrue(script.sent.contains { $0.command == failedCommand && $0.timeout == 1.5 })
        let acquire = try await request(worker, "station_action", radio: radio, extra: ["action": "tune"])
        XCTAssertEqual((acquire["error"] as? [String: Any])?["code"] as? String, "worker_stopping")
        let uncertain = try await request(worker, "station_disconnect", radio: radio)
        XCTAssertEqual((uncertain["error"] as? [String: Any])?["code"] as? String, "release_unconfirmed")
        script.fail(nil)
        let recovered = try await request(worker, "station_disconnect", radio: radio)
        XCTAssertEqual(recovered["ok"] as? Bool, true)
        XCTAssertTrue(script.sent.allSatisfy { $0.host == fixture.hosts[radio == "radio1" ? 0 : 1] && $0.authorization == "Bearer fixture-\(radio)" })
        let repeated = await worker.shutdownOutcome()
        XCTAssertEqual(repeated, .clean)
    }
    func testCWReleaseFailureReachesRegistryAndWorker() async throws { try await releaseFailure("send_cw", failedCommand: "clear_cw", radio: "radio1") }
    func testTuneReleaseFailureReachesRegistryAndWorker() async throws { try await releaseFailure("tune", failedCommand: "station_cancel", radio: "radio2") }
    func testPTTReleaseFailureReachesRegistryAndWorker() async throws { try await releaseFailure("ptt", failedCommand: "set_ptt", radio: "radio1") }

    func testConnectBeforeCaptureInstallAttachesBothLiveClientsAndReconnects() async throws {
        let fixture = fixture(); defer { fixture.close() }
        for radio in ["radio1", "radio2"] { try await connect(fixture, radio: radio, transmit: false) }
        let gate = NativeDraftPowerGate()
        await fixture.registry.installPowerCapture(gate)
        for (index, radio) in ["radio1", "radio2"].enumerated() {
            gate.select(provider: "direct_agent", selectionID: UUID().uuidString, radioID: radio)
            gate.activate(radioID: radio, generation: UInt64(index + 1))
            let initial = try XCTUnwrap(gate.state().context, "Late installation must attach the established source")
            _ = try await fixture.registry.agents[radio]!.handle("station_reconnect", params: ["provider": "direct_agent"])
            try await ready(fixture.registry.agents[radio]!)
            let reconnected = try XCTUnwrap(gate.state().context)
            XCTAssertNotEqual(reconnected.sessionID, initial.sessionID)
        }
        _ = await fixture.registry.terminate()
    }

    func testCaptureInstallDuringInitialFetchAttachesWithoutInventingReady() async throws {
        let fixture = fixture(); defer { fixture.close() }
        for (index, radio) in ["radio1", "radio2"].enumerated() {
            let script = fixture.scripts[radio]!; script.pauseState()
            _ = try await LiveStationMethods.handle("station_connect", params: ["provider": "direct_agent", "radio_id": radio,
                "base_url": "https://\(fixture.hosts[index])"], registry: fixture.registry)
            for _ in 0..<1000 { if script.stateRequested { break }; try await Task.sleep(for: .milliseconds(2)) }
            XCTAssertTrue(script.stateRequested)
            let gate = NativeDraftPowerGate()
            gate.select(provider: "direct_agent", selectionID: UUID().uuidString, radioID: radio)
            gate.activate(radioID: radio, generation: 1)
            await fixture.registry.agents[radio]!.installPowerCapture(gate)
            XCTAssertNil(gate.state().context, "Pending GET is not ready telemetry")
            script.releaseState()
            try await ready(fixture.registry.agents[radio]!)
            XCTAssertNotNil(gate.state().context, "The same initial connection must become capturable")
        }
        _ = await fixture.registry.terminate()
    }
}
#endif
