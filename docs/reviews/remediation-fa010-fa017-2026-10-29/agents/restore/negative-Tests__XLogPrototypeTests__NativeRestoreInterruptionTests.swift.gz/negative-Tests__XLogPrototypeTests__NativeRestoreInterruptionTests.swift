import Foundation
import XCTest
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
#if canImport(Darwin)
import Darwin
#else
import Glibc
#endif
#if os(macOS)
@testable import XLogCore
#else
@testable import XLogPortableCore
#endif

private final class RestoreHistoryProtocol: URLProtocol {
    private static let lock = NSLock()
    private static var count = 0
    private static var remoteID = 42
    static func reset(remoteID: Int = 42) { lock.withLock { count = 0; self.remoteID = remoteID } }
    static var requests: Int { lock.withLock { count } }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        let id = Self.lock.withLock { Self.count += 1; return Self.remoteID }
        guard request.httpMethod == "GET", let url = request.url else {
            client?.urlProtocol(self, didFailWithError: URLError(.unsupportedURL)); return
        }
        let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
        let body: Data
        if items.contains(where: { $0.name == "format" && $0.value == "adif" }) {
            let record = ADIFRecord(fields: ["CALL": "K1AUTHORITY", "QSO_DATE": "20231114",
                "TIME_ON": "221320", "BAND": "20m", "MODE": "CW"])
            body = try! JSONEncoder().encode(WavelogADIFPage(
                data: WavelogADIFData(exported: 1, lastFetchedID: id, adif: record.adifDocument),
                meta: WavelogListMeta(page: 1, perPage: 1000, count: 1, total: 1, totalPages: 1, hasMore: false)))
        } else {
            body = Data("""
            {"data":[{"id":\(id),"station_id":1,"call":"K1AUTHORITY","band":"20m","mode":"CW","qso_date":"2023-11-14 22:13:20"}],"meta":{"page":1,"per_page":1000,"count":1,"total":1,"total_pages":1,"has_more":false}}
            """.utf8)
        }
        let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: nil,
                                       headerFields: ["Content-Type": "application/json"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: body)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

final class NativeRestoreInterruptionTests: XCTestCase {
    private struct Checkpoint: Codable {
        let pid: Int32
        let executable: String
        let root: String
    }
    private enum Interruption: Error { case afterDatabase }

    func testNativeOwnerUsesSelectedReferenceBytesWhenPackageIsReplacedAfterDatabasePublication() throws {
        let fm = FileManager.default
        let root = fm.temporaryDirectory.appendingPathComponent("xlog-native-swap-\(UUID())")
        let suite = "xlog-native-swap-\(UUID())"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite); try? fm.removeItem(at: root) }
        let selectedReference = root.appendingPathComponent("selected-reference")
        let replacementReference = root.appendingPathComponent("replacement-reference")
        for directory in [selectedReference, replacementReference] {
            try fm.createDirectory(at: directory, withIntermediateDirectories: true)
        }
        try Data("selected-reference-A".utf8).write(to: selectedReference.appendingPathComponent("identity.txt"))
        try Data("replacement-reference-B".utf8).write(to: replacementReference.appendingPathComponent("identity.txt"))
        let fixture = try makeFixture(root: root, defaults: defaults, referenceDataURL: selectedReference)
        let manager = XLogBackupManager()
        let replacementDB = try LogbookDatabase(url: root.appendingPathComponent("replacement.sqlite"))
        try replacementDB.save(QSO(wavelogID: 42, call: "K3REPLACEMENT", band: "40m", mode: "CW"), markDirty: false)
        var replacementSettings = fixture.selected
        replacementSettings.wavelogStationID = 3
        let replacement = try manager.create(database: replacementDB, at: root.appendingPathComponent("replacement.xlogbackup"),
            settings: replacementSettings, preferences: preferences(), referenceDataURL: replacementReference)
        replacementDB.close()
        let selectedURL = fixture.preview.packageURL
        let retainedURL = root.appendingPathComponent("selected-retained.xlogbackup")
        let replacementURL = replacement.packageURL
        let owner = NativeBackupRestoreOwner(settingsStore: fixture.store, manager: manager)
        owner.afterDatabasePublication = {
            try FileManager.default.moveItem(at: selectedURL, to: retainedURL)
            try FileManager.default.moveItem(at: replacementURL, to: selectedURL)
        }
        let liveReference = root.appendingPathComponent("live-reference")
        let restored = try owner.restore(preview: fixture.preview, to: fixture.live,
            keeping: fixture.old, settingsAfterRestore: fixture.selected,
            recoveryPackageURL: fixture.recovery, referenceDataURL: liveReference)
        defer { restored.close() }
        XCTAssertEqual(try restored.fetchAll().first?.call, "K2RESTORED")
        XCTAssertEqual(fixture.store.load().wavelogStationID, 2)
        XCTAssertEqual(try String(contentsOf: liveReference.appendingPathComponent("identity.txt"), encoding: .utf8),
                       "selected-reference-A")
        XCTAssertTrue(fm.fileExists(atPath: retainedURL.path))
        XCTAssertTrue(fm.fileExists(atPath: fixture.recovery.path))
        XCTAssertEqual(try manager.inspect(at: retainedURL).settings?.wavelogStationID, 2)
        XCTAssertEqual(try manager.inspect(at: selectedURL).settings?.wavelogStationID, 3)
    }

    func testInterruptedOwnerRejectsOverlappingAndAbsentRemoteIDsBeforeAnyRequest() async throws {
        for remoteID in [42, 84] {
            let root = FileManager.default.temporaryDirectory.appendingPathComponent("xlog-native-restore-\(UUID())")
            let suite = "xlog-native-restore-\(UUID())"
            let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
            defer { defaults.removePersistentDomain(forName: suite); try? FileManager.default.removeItem(at: root) }
            let fixture = try makeFixture(root: root, defaults: defaults)
            let owner = NativeBackupRestoreOwner(settingsStore: fixture.store)
            owner.afterDatabasePublication = { throw Interruption.afterDatabase }
            XCTAssertThrowsError(try owner.restore(preview: fixture.preview, to: fixture.live,
                keeping: fixture.old, settingsAfterRestore: fixture.selected,
                recoveryPackageURL: fixture.recovery, referenceDataURL: nil))
            XCTAssertTrue(fixture.store.load().hasSameWavelogDestination(as: fixture.old))
            try await assertInterruptedAdmission(root: root, fixture: fixture, remoteID: remoteID)
        }
    }

    func testControlledProcessInterruptionAtDatabasePublicationBlocksFreshOwner() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("xlog-native-process-\(UUID())").resolvingSymlinksInPath()
        let suite = "xlog-native-process-\(UUID())"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite); try? FileManager.default.removeItem(at: root) }
        let fixture = try makeFixture(root: root, defaults: defaults)
        XCTAssertTrue(defaults.synchronize())
        let executable = URL(fileURLWithPath: CommandLine.arguments[0]).resolvingSymlinksInPath()
        let process = Process()
        process.executableURL = executable
        let selector = "\(String(reflecting: Self.self))/testInterruptionChild"
        #if os(macOS)
        process.arguments = executable.lastPathComponent == "xctest"
            ? ["-XCTest", selector, Bundle(for: Self.self).bundleURL.path] : [selector]
        #else
        process.arguments = [selector]
        #endif
        var environment = ProcessInfo.processInfo.environment
        environment["XLOG_RESTORE_CHILD_ROOT"] = root.path
        environment["XLOG_RESTORE_CHILD_SUITE"] = suite
        process.environment = environment
        let output = Pipe()
        process.standardOutput = output
        process.standardError = output
        try process.run()
        defer { if process.isRunning { process.terminate(); process.waitUntilExit() } }
        let receiptURL = root.appendingPathComponent("database-published.json")
        let deadline = Date().addingTimeInterval(12)
        while !FileManager.default.fileExists(atPath: receiptURL.path), process.isRunning, Date() < deadline {
            try await Task.sleep(nanoseconds: 20_000_000)
        }
        guard FileManager.default.fileExists(atPath: receiptURL.path) else {
            if process.isRunning { process.terminate() }
            process.waitUntilExit()
            let text = String(decoding: output.fileHandleForReading.readDataToEndOfFile(), as: UTF8.self)
            return XCTFail("Disposable child did not reach its publication checkpoint: \(text)")
        }
        let receipt = try JSONDecoder().decode(Checkpoint.self, from: Data(contentsOf: receiptURL))
        XCTAssertTrue(process.isRunning)
        XCTAssertEqual(receipt.pid, process.processIdentifier)
        XCTAssertEqual(receipt.executable, executable.path)
        XCTAssertEqual(receipt.root, root.path)
        XCTAssertEqual(kill(process.processIdentifier, 0), 0)
        // Only this positively identified owned child is terminated. There is no GUI binding.
        guard process.isRunning, receipt.pid == process.processIdentifier,
              receipt.executable == executable.path, receipt.root == root.path,
              kill(process.processIdentifier, 0) == 0 else { return XCTFail("Child isolation identity failed") }
        process.terminate()
        process.waitUntilExit()
        XCTAssertNotEqual(process.terminationStatus, 0)
        XCTAssertTrue(fixture.store.load().hasSameWavelogDestination(as: fixture.old))
        try await assertInterruptedAdmission(root: root, fixture: fixture, remoteID: 42)
    }

    func testInterruptionChild() throws {
        guard let rootPath = ProcessInfo.processInfo.environment["XLOG_RESTORE_CHILD_ROOT"],
              let suite = ProcessInfo.processInfo.environment["XLOG_RESTORE_CHILD_SUITE"] else {
            throw XCTSkip("Only the disposable interruption parent starts this helper")
        }
        let root = URL(fileURLWithPath: rootPath).resolvingSymlinksInPath()
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        let store = SettingsStore(defaults: defaults)
        let old = store.load()
        let manager = XLogBackupManager()
        let preview = try manager.inspect(at: root.appendingPathComponent("selected.xlogbackup"))
        let selected = try preview.settingsForRestore(keeping: old, restoreSettings: true)
        let owner = NativeBackupRestoreOwner(settingsStore: store, manager: manager)
        owner.afterDatabasePublication = {
            let receipt = Checkpoint(pid: ProcessInfo.processInfo.processIdentifier,
                executable: URL(fileURLWithPath: CommandLine.arguments[0]).resolvingSymlinksInPath().path,
                root: root.path)
            try JSONEncoder().encode(receipt).write(to: root.appendingPathComponent("database-published.json"), options: .atomic)
            Thread.sleep(forTimeInterval: 25)
            throw Interruption.afterDatabase
        }
        _ = try owner.restore(preview: preview, to: root.appendingPathComponent("live.sqlite"),
            keeping: old, settingsAfterRestore: selected,
            recoveryPackageURL: root.appendingPathComponent("recovery.xlogbackup"), referenceDataURL: nil)
        XCTFail("Child must be terminated at the publication checkpoint")
    }

    private typealias Fixture = (store: SettingsStore, old: XLogSettings, selected: XLogSettings,
                                preview: XLogBackupPreview, live: URL, recovery: URL)

    private func makeFixture(root: URL, defaults: UserDefaults, referenceDataURL: URL? = nil) throws -> Fixture {
        let manager = XLogBackupManager()
        var old = XLogSettings.defaults
        old.wavelogURL = "https://restore.invalid"
        old.wavelogStationID = 1
        old.automaticSync = true
        let store = SettingsStore(defaults: defaults)
        store.save(old)
        let live = root.appendingPathComponent("live.sqlite")
        let database = try LogbookDatabase(url: live)
        try database.save(QSO(wavelogID: 42, call: "K1AUTHORITY", band: "20m", mode: "CW"), markDirty: false)
        let recovery = root.appendingPathComponent("recovery.xlogbackup")
        _ = try manager.create(database: database, at: recovery, settings: old, preferences: preferences())
        database.close()
        let backup = try LogbookDatabase(url: root.appendingPathComponent("source.sqlite"))
        defer { backup.close() }
        try backup.save(QSO(wavelogID: 42, call: "K2RESTORED", band: "20m", mode: "CW"), markDirty: false)
        var selected = old
        selected.wavelogStationID = 2
        let preview = try manager.create(database: backup, at: root.appendingPathComponent("selected.xlogbackup"),
                                        settings: selected, preferences: preferences(), referenceDataURL: referenceDataURL)
        selected.automaticSync = false
        return (store, old, selected, preview, live, recovery)
    }

    private func assertInterruptedAdmission(root: URL, fixture: Fixture, remoteID: Int) async throws {
        XCTAssertThrowsError(try NativeBackupRestoreOwner.openDatabase(at: fixture.live, settings: fixture.old))
        let database = try LogbookDatabase(url: fixture.live)
        defer { database.close() }
        let original = try XCTUnwrap(try database.fetchAll().first)
        XCTAssertEqual(original.call, "K2RESTORED")
        XCTAssertEqual(original.wavelogID, 42)
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [RestoreHistoryProtocol.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        // AppModel's timer and explicit Sync share this same actual engine admission.
        for intent in ["automatic", "manual"] {
            RestoreHistoryProtocol.reset(remoteID: remoteID)
            let saved = try fixture.store.wavelogConfiguration(for: fixture.store.load(), token: "wl2_fixture")
            do {
                _ = try await SyncEngine(database: database, configuration: saved, session: session).synchronize()
                XCTFail("\(intent) sync admitted an incomplete restore")
            } catch { }
            XCTAssertEqual(RestoreHistoryProtocol.requests, 0, "\(intent) must reject before provider requests")
            XCTAssertEqual(try database.lookup(localID: original.id)?.call, "K2RESTORED")
            XCTAssertNil(try database.lookup(localID: original.id)?.deletedAt)
        }
        XCTAssertTrue(FileManager.default.fileExists(atPath: fixture.recovery.path))
        let recovery = try LogbookDatabase(url: fixture.recovery.appendingPathComponent("OM0RX-xLog.sqlite"))
        defer { recovery.close() }
        XCTAssertEqual(try recovery.fetchAll().first?.call, "K1AUTHORITY")
    }

    private func preferences() -> XLogBackupPreferences {
        .init(deskBandMapBands: [], detachedBandMapBands: [], deskBandMapFollowsRadio: false,
              detachedBandMapLayout: "Adaptive grid", bandMapFontScale: 1,
              intelligenceBands: [], clusterSpotOpensFullEditor: false)
    }
}
