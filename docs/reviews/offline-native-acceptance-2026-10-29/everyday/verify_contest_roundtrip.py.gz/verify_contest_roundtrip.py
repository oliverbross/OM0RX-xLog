from pathlib import Path
import json,sqlite3
stage=Path(__file__).parent
def database(label,name):return next((stage/'snapshots'/label).rglob(name))
def rows(label,name,table):
    db=sqlite3.connect(database(label,name));db.row_factory=sqlite3.Row
    try:return [dict(r) for r in db.execute('SELECT * FROM '+table)]
    finally:db.close()
before='edit-last-before';after='edit-last-fixed-cancel';final='final-roundtrip'
b=rows(before,'contest.sqlite','DXLOG');a=rows(after,'contest.sqlite','DXLOG');f=rows(final,'contest.sqlite','DXLOG')
assert len(b)==len(a)==len(f)==1
assert b[0]['ID']==a[0]['ID']==f[0]['ID']=='3f141c39-d0c0-4765-83cd-7e7e6377a3fd'
assert b[0]['Call']==a[0]['Call']==f[0]['Call']=='K1SAFE'
assert a[0]['Comment']==f[0]['Comment']=='Everyday Edit last correction Ω'
diff={k:{'before':b[0][k],'after':a[0][k]} for k in b[0] if b[0][k]!=a[0][k]};assert set(diff)=={'Comment'},diff
assert a==f
serial=rows(before,'contest.sqlite','xlog_serial')
assert serial==rows(after,'contest.sqlite','xlog_serial')==rows(final,'contest.sqlite','xlog_serial')
auditBefore=rows(before,'contest.sqlite','xlog_qso_audit');audit=rows(final,'contest.sqlite','xlog_qso_audit')
assert len(audit)==len(auditBefore)+1 and audit[-1]['qso_id']==b[0]['ID']
sessionB=json.loads(rows(before,'contest.sqlite','xlog_session')[0]['state']);sessionF=json.loads(rows(final,'contest.sqlite','xlog_session')[0]['state'])
differentSession={k:{'before':v,'after':sessionF.get(k)} for k,v in sessionB.items() if v!=sessionF.get(k)}
assert set(differentSession)=={'revision','settings'}
assert sessionF['revision']==sessionB['revision']+1
assert sessionF['settings']=={**sessionB['settings'],'PowerCategory':''}
draftB=json.loads(rows('blob-export-no-file','OM0RX-xLog.sqlite','xlog_operator_draft')[0]['payload']);draftF=json.loads(rows(final,'OM0RX-xLog.sqlite','xlog_operator_draft')[0]['payload'])
assert draftB==draftF and draftF['qso']['call']=='K9KEEP'
normalB=rows('blob-export-no-file','OM0RX-xLog.sqlite','qsos');normalF=rows(final,'OM0RX-xLog.sqlite','qsos');assert normalB==normalF
out={'contestQSOID':b[0]['ID'],'count':len(f),'onlyContactDifference':diff,'serialLedgerIdentical':True,'serialLedger':serial,'auditBefore':auditBefore,'auditAfter':audit,'sessionDifferences':differentSession,'normalDraftIdentical':True,'normalDraft':draftF,'normalContactsIdentical':True,'normalCount':len(normalF),'roundtripSource':'6ed87f3c28fb6c6e4528cc79ed98eaa627de83c8','nativeRoundtrip':'50858/50867 Normal ->50893/50895 Contesting ->50965/50973 Normal'}
(stage/'contest-roundtrip-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['auditBefore','auditAfter','normalDraft','sessionDifferences','serialLedger']}));print(json.dumps({'sessionDifferenceKeys':list(differentSession),'auditKinds':[r['kind'] for r in audit]}))
