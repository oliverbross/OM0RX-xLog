from pathlib import Path
import hashlib,json,plistlib,shutil,subprocess
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog');stage=Path(__file__).parent
old=stage/'XLog Everyday Development.app';new=stage/'XLog Everyday Native Save Development.app';assert not new.exists()
receipt=json.loads((stage/'host-export-build-receipt.json').read_text());assert receipt['exit']==0
assert not any(str(old/'Contents/MacOS/xlog-prototype') in line for line in subprocess.check_output(['ps','-axo','args='],text=True).splitlines())
shutil.copytree(old,new,symlinks=True)
target=new/'Contents/MacOS/xlog-prototype';target.unlink();shutil.copy2(receipt['binary'],target)
assert hashlib.sha256(target.read_bytes()).hexdigest()==receipt['sha256']
info=new/'Contents/Info.plist';v=plistlib.loads(info.read_bytes());v['CFBundleName']='XLog Everyday Native Save Development';info.write_bytes(plistlib.dumps(v))
source=(stage/'native_fixture.py').read_text().replace('app = Path('+repr(str(old))+')','app = Path('+repr(str(new))+')')
source=source.replace("'dev-server.json'","'dev-server-r2.json'").replace("'dev-server.log'","'dev-server-r2.log'").replace("'dev-server-stopped.json'","'dev-server-r2-stopped.json'")
(stage/'native_fixture_final.py').write_text(source)
seedpath=stage/'seed.json';seed=json.loads(seedpath.read_text());(stage/'pre-export-repair-seed.json').write_text(json.dumps(seed,indent=2));seed.update(app=str(new),executable=str(target),worker=str(new/'Contents/MacOS/xlog-prototype-worker'));seedpath.write_text(json.dumps(seed,indent=2))
result={'head':receipt['head'],'app':str(new),'hostSHA256':receipt['sha256'],'workerSHA256':hashlib.sha256((new/'Contents/MacOS/xlog-prototype-worker').read_bytes()).hexdigest(),'preservedDevelopmentLayout':str(old),'installed':False,'candidate':False,'versionBumped':False,'provenance':'Affected Rust host rebuilt; matching existing worker/resources retained unchanged'}
(stage/'native-save-development-receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
