from pathlib import Path
import json,hashlib
stage=Path(__file__).parent
scope={}
exec((stage/'native_fixture.py').read_text().split('mode = sys.argv[1]')[0],scope)
seed=json.loads((stage/'seed.json').read_text())
records=[{'CALL':'K6NITE','QSO_DATE':'20261028','TIME_ON':'235958','QSO_DATE_OFF':'20261029','TIME_OFF':'000009','FREQ':'14.025','BAND':'20m','MODE':'CW','RST_SENT':'599','RST_RCVD':'579','NAME':'Night Ω','COMMENT':'Midnight <pair> & exact Ω','NOTES':'Preserve café and end date','TX_PWR':'37'}, {'CALL':'K7MAN','QSO_DATE':'20261028','TIME_ON':'101112','QSO_DATE_OFF':'20261028','TIME_OFF':'101234','FREQ':'7.074','BAND':'40m','MODE':'FT8','RST_SENT':'-07','RST_RCVD':'+03','COMMENT':'Fixed manual fixture','GRIDSQUARE':'FN31pr'}]
text='Everyday synthetic reviewed input\n<ADIF_VER:5>3.1.7<EOH>\n'+''.join(''.join(f'<{k}:{len(v.encode())}>{v}' for k,v in r.items())+'<EOR>\n' for r in records)
(stage/'synthetic-reviewed.adi').write_text(text)
s=scope['Worker'](Path(seed['root']),transcript_name='extra-corrected')
try:
    preview=s.request('logbook_import_adif',action='preview',text=text)
    applied=s.request('logbook_import_adif',text=text,generation=preview['generation'])
    assert applied['imported']==2,applied
finally:s.close()
(stage/'reviewed-scope.json').write_text(json.dumps({'records':records,'sha256':hashlib.sha256(text.encode()).hexdigest(),'preview':preview,'applied':applied,'provenance':'synthetic fixture seed via actual private worker; not native import acceptance'},indent=2))
print(json.dumps({'imported':2,'calls':[r['CALL'] for r in records]}))
