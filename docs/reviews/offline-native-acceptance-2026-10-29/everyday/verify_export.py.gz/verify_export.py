from pathlib import Path
import datetime,json,hashlib,re,sqlite3
stage=Path(__file__).parent
data=(stage/'native-normal-export.adi').read_bytes()
def parse(data):
    offset=0;fields={};rows=[]
    while offset<len(data):
        begin=data.find(b'<',offset)
        if begin<0:break
        end=data.index(b'>',begin);tag=data[begin+1:end].decode('ascii');offset=end+1
        if tag.upper()=='EOH':fields={};continue
        if tag.upper()=='EOR':rows.append(fields);fields={};continue
        parts=tag.split(':');assert len(parts)>=2 and parts[1].isdigit(),tag
        size=int(parts[1]);value=data[offset:offset+size].decode('utf-8');assert len(data[offset:offset+size])==size
        offset+=size;assert parts[0].upper() not in fields
        fields[parts[0].upper()]=value
    assert not fields
    return rows
rows=parse(data);bycall={r['CALL']:r for r in rows}
assert len(rows)==3 and set(bycall)=={'K8AUTO','K6NITE','K7MAN'},rows
scope=json.loads((stage/'reviewed-scope.json').read_text())
for expected in scope['records']:
    for k,v in expected.items():
        if k=='FREQ':assert float(bycall[expected['CALL']][k])==float(v)
        elif k=='GRIDSQUARE':assert bycall[expected['CALL']][k]==v.upper()
        else:assert bycall[expected['CALL']][k]==v,(k,v,bycall[expected['CALL']])
assert bycall['K8AUTO']['TIME_ON']=='130536' and bycall['K8AUTO']['COMMENT']=='Everyday auto Ω <save>'
snapshot=json.loads((stage/'snapshot-blob-export-no-file.json').read_text())
store=next(s for p,s in snapshot['stores'].items() if p.endswith('OM0RX-xLog.sqlite'))
draft=json.loads(store['xlog_operator_draft'][0][-1]['hex']) if False else store['xlog_operator_draft']
dbpath=next((stage/'snapshots/blob-export-no-file').rglob('OM0RX-xLog.sqlite'))
db=sqlite3.connect(dbpath);db.row_factory=sqlite3.Row
assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
assert not db.execute('PRAGMA foreign_key_check').fetchall()
tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]
contacts=[dict(r) for r in db.execute('SELECT * FROM qsos')]
assert len(contacts)==3
for contact in contacts:
    qso=json.loads(contact['record_json']);row=bycall[qso['call']]
    assert qso['id']==contact['local_id'] and row['CALL']==contact['call']
    for key,datekey,timekey in [('start','QSO_DATE','TIME_ON'),('end','QSO_DATE_OFF','TIME_OFF')]:
        if key not in qso:assert datekey not in row and timekey not in row;continue
        stamp=datetime.datetime(2001,1,1,tzinfo=datetime.timezone.utc)+datetime.timedelta(seconds=qso[key])
        assert stamp.strftime('%Y%m%d')==row[datekey] and stamp.strftime('%H%M%S')==row[timekey]
    for key,adif in [('band','BAND'),('mode','MODE'),('comment','COMMENT'),('notes','NOTES'),('name','NAME'),('gridSquare','GRIDSQUARE'),('rstSent','RST_SENT'),('rstReceived','RST_RCVD'),('txPower','TX_PWR')]:
        if qso.get(key):assert row[adif]==qso[key]
    assert round(float(row['FREQ'])*1_000_000)==qso['frequencyHz']==contact['frequency_hz']
draft=json.loads(db.execute('SELECT payload FROM xlog_operator_draft').fetchone()[0])
assert draft['qso']['call']=='K9KEEP' and draft['qso']['comment']=='Everyday unfinished draft stays'
receipts=[json.loads(r[0]) for r in db.execute('SELECT payload FROM xlog_operator_receipts')]
save=next(r for r in receipts if r['mutation']['action']=='save')
date=datetime.datetime(2001,1,1,tzinfo=datetime.timezone.utc)+datetime.timedelta(seconds=save['savedQSO']['start'])
assert date.strftime('%Y%m%d')==bycall['K8AUTO']['QSO_DATE'] and date.strftime('%H%M%S')==bycall['K8AUTO']['TIME_ON']
out={'filePath':'/Users/oliver/Downloads/OM0RX-xLog-integrated-2026-10-29 (1).adi','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'records':rows,'sqliteContacts':contacts,'draft':draft,'automaticSaveReceipt':save,'integrity':'ok','foreignKeyViolations':0,'preparedReceipt':None,'receiptBoundary':'Normal route uses frozen begin/read snapshot but supplies no final prepared hash/file receipt. Digest calculated from actual native persisted file, not invented native receipt.'}
(stage/'normal-export-verification.json').write_text(json.dumps(out,indent=2,default=lambda x:{'hex':bytes(x).hex()}))
print(json.dumps({'count':len(rows),'calls':list(bycall),'sha256':out['sha256'],'sqliteIntegrity':'ok','draftPreserved':draft['qso']['id'],'nativeSaveUTC':date.isoformat(),'midnightDateOff':bycall['K6NITE']['QSO_DATE_OFF'],'midnightTimeOff':bycall['K6NITE']['TIME_OFF'],'preparedReceipt':None}))
