from pathlib import Path
import datetime,json,hashlib,shutil
stage=Path(__file__).parent
paths=[Path('/Users/oliver/Downloads'),Path(json.loads((stage/'seed.json').read_text())['root']),stage]
matches={str(p):[str(q) for q in (p.glob('OM0RX-xLog-integrated-2026-10-29*') if p.exists() else [])] for p in paths}
files=[]
for name in matches['/Users/oliver/Downloads']:
    p=Path(name);s=p.stat()
    entry={'path':name,'size':s.st_size,'mtimeUTC':datetime.datetime.fromtimestamp(s.st_mtime,datetime.timezone.utc).isoformat(),'birthUTC':datetime.datetime.fromtimestamp(s.st_birthtime,datetime.timezone.utc).isoformat()}
    if s.st_mtime>datetime.datetime(2026,10,29,13,4,tzinfo=datetime.timezone.utc).timestamp():
        data=p.read_bytes();entry.update(sha256=hashlib.sha256(data).hexdigest(),text=data.decode())
        target=stage/'native-normal-export.adi';assert not target.exists();shutil.copy2(p,target)
    files.append(entry)
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exactBasenameSearch':matches,'files':files,'uiResult':'3 QSOs exported from the integrated logbook; no save chooser','limitation':'Exact synthetic export basename only; old matching file metadata only, no production directory search.'}
(stage/'blob-file-readback.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))
