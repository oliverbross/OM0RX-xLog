from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog');stage=Path(__file__).parent
old=repo/'.build/offline-native-acceptance-20261029-6e8bc944'
assert not any(str(old/'XLog Offline Precision Development.app/Contents/MacOS/xlog-prototype') in line for line in subprocess.check_output(['ps','-axo','args='],text=True).splitlines())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','--','prototype/src-tauri','prototype/src/contesting'],cwd=repo,text=True).strip(),'Commit tested repair first'
paths=[p for p in (repo/'prototype/src-tauri').rglob('*') if p.is_file() and 'target' not in p.parts]
inputs={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(old/'cargo'),XLOG_SOURCE_COMMIT=head)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
argv=['cargo','build','--locked','--release','--jobs','2']
with (stage/'host-export-build.log').open('wb') as log:r=subprocess.run(argv,cwd=repo/'prototype/src-tauri',env=env,stdout=log,stderr=subprocess.STDOUT)
binary=old/'cargo/release/xlog-prototype'
out={'head':head,'argv':argv,'cwd':str(repo/'prototype/src-tauri'),'env':{k:env[k] for k in ['CARGO_TARGET_DIR','XLOG_SOURCE_COMMIT']},'startUTC':started,'endUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed':time.monotonic()-tick,'exit':r.returncode,'inputs':inputs,'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest() if r.returncode==0 else None}
(stage/'host-export-build-receipt.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='inputs'}));raise SystemExit(r.returncode)
