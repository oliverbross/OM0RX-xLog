from pathlib import Path
import hashlib,json,subprocess
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
old=repo/'.build/offline-native-acceptance-20261029-6e8bc944'
stage=Path(__file__).parent
app=old/'XLog Offline Precision Development.app'
manifest=json.loads((old/'final-source-inputs.json').read_text())
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in manifest['inputs'].items())
expected={'xlog-prototype':'6771a241d39741d0d1af725194ba21b1f18eabc0dcb702fab180d4092e862672','xlog-prototype-worker':'b3c984c5a38b39f563be7ee45179738fe9d12af34aa647d06a244e946a79a71e'}
assert all(hashlib.sha256((app/'Contents/MacOS'/p).read_bytes()).hexdigest()==h for p,h in expected.items())
source=(old/'native_fixture.py').read_text().replace("stage = repo / '.build/offline-native-acceptance-20261029-6e8bc944'", "stage = repo / '.build/everyday-native-acceptance-20261029'")
source=source.replace("app = stage / ('XLog Offline Precision Development.app' if app_profile == 'precision' else 'XLog Offline Development.app')", 'app = Path('+repr(str(app))+')')
source=source.replace("'xlog-wave1-offline-native-'", "'xlog-wave1-everyday-native-'")
(stage/'native_fixture.py').write_text(source)
(stage/'development-receipt.json').write_text(json.dumps({'source':'e6cab56f50953798f08df8d16142bfc90fd193b1','documentationHEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'reusedApp':str(app),'executables':expected,'inputCount':len(manifest['inputs']),'allInputsMatch':True},indent=2))
print(json.dumps({'all1843InputsMatch':True,'hostWorkerHashMatch':True,'app':str(app)}))
