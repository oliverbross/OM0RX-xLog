from pathlib import Path
stage=Path(__file__).parent
source=(stage/'frontend_build.py').read_text().replace("'frontend-everyday'","'frontend-native-save'").replace("'frontend-build.log'","'frontend-native-save-build.log'").replace("'frontend-build-receipt.json'","'frontend-native-save-build-receipt.json'")
source=source.replace("'builtFiles':hashes(built)","'builtFiles':hashes(built),'sourceDiff':subprocess.check_output(['git','diff'],cwd=repo,text=True)")
(stage/'frontend_build_native_save.py').write_text(source)
source=(stage/'build_host.py').read_text().replace("'host-build.log'","'host-export-build.log'").replace("'host-build-receipt.json'","'host-export-build-receipt.json'")
(stage/'build_host_export.py').write_text(source)
