from pathlib import Path
import json,sys
stage=Path(__file__).parent;scope={}
exec((stage/'native_fixture_final.py').read_text().split('mode = sys.argv[1]')[0],scope)
assert not scope['own_processes']()
seed=json.loads((stage/'seed.json').read_text())
label=sys.argv[1];path=stage/sys.argv[2]
s=scope['Worker'](Path(seed['root']),transcript_name=label)
try:
    before=s.request('logbook_stats');draftBefore=s.request('logbook_operator_draft')
    parsed=s.request('parse_adif',text=path.read_text())
    assert parsed['record_count']==3 and {r['fields']['CALL'] for r in parsed['records']}=={'K8AUTO','K6NITE','K7MAN'}
    after=s.request('logbook_stats');draftAfter=s.request('logbook_operator_draft')
    assert before==after and draftBefore==draftAfter
finally:s.close()
(stage/(label+'-result.json')).write_text(json.dumps({'file':str(path),'parsed':parsed,'before':before,'after':after,'draftPreserved':draftBefore==draftAfter},indent=2))
print(json.dumps({'parsedResult':parsed,'unchangedStatsAndDraft':True}))
