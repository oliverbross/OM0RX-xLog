from pathlib import Path
import datetime,hashlib,json,subprocess
stage=Path(__file__).parent;seed=json.loads((stage/'seed.json').read_text())
ps=subprocess.check_output(['ps','-axo','pid=,ppid=,comm=,args='],text=True)
assert any(line.strip().startswith('50965 ') and seed['executable']+' --offline-contest-acceptance='+seed['root'] in line for line in ps.splitlines())
sample=subprocess.run(['sample','50965','1','1','-file',str(stage/'export-observation-process.sample')],capture_output=True,text=True,timeout=20)
files=[]
for p in sorted(Path('/Users/oliver/Downloads').glob('OM0RX-xLog-integrated-2026-10-29*')):
    s=p.stat();value={'path':str(p),'mtimeUTC':datetime.datetime.fromtimestamp(s.st_mtime,datetime.timezone.utc).isoformat(),'size':s.st_size}
    if s.st_mtime>=datetime.datetime(2026,10,29,13,24,tzinfo=datetime.timezone.utc).timestamp():
        data=p.read_bytes();value.update(sha256=hashlib.sha256(data).hexdigest(),matchesInitialNativeFile=data==(stage/'native-normal-export.adi').read_bytes())
        target=stage/'native-normal-final-source.adi';assert not target.exists();target.write_bytes(data)
    files.append(value)
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'GUIError':['noWindowsAvailable','timeoutReached'],'samePIDStillLive':True,'processes':[line for line in ps.splitlines() if seed['app'] in line],'sampleExit':sample.returncode,'sampleStdout':sample.stdout,'sampleStderr':sample.stderr,'files':files}
(stage/'export-observation-error.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
