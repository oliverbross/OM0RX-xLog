from pathlib import Path
import datetime,json,os,signal,subprocess,time
stage=Path(__file__).parent;seed=json.loads((stage/'seed.json').read_text())
def processes():return subprocess.check_output(['ps','-axo','pid=,ppid=,comm=,args='],text=True).splitlines()
before=processes();app=[p for p in before if p.strip().startswith('50965 ')];worker=[p for p in before if p.strip().startswith('50973 ')]
assert len(app)==len(worker)==1
assert seed['executable']+' --offline-contest-acceptance='+seed['root'] in app[0]
assert seed['worker']+' --offline-contest-acceptance='+seed['root'] in worker[0] and worker[0].split()[1]=='50965'
assert (stage/'snapshots/export-observation-error').is_dir()
sample=(stage/'export-observation-process.sample').read_text();assert 'DownloadProxy::decideDestination' in sample and '__mac_syscall' in sample
os.kill(50965,signal.SIGTERM)
deadline=time.monotonic()+10
while any(p.strip().split()[0] in {'50965','50973'} for p in processes()) and time.monotonic()<deadline:time.sleep(.1)
remaining=[p for p in processes() if p.strip().split()[0] in {'50965','50973'}]
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'identifiedBefore':app+worker,'signal':'SIGTERM','ordinaryQuit':False,'reason':'Main thread blocked in native WebKit download sandbox syscall; AX unavailable; no active edit/unsaved local field; complete private snapshot retained. No escalation or production fallback.','remaining':remaining,'dataPreserved':True}
(stage/'identified-download-hang-stopped.json').write_text(json.dumps(out,indent=2));assert not remaining,'Hard stop; no SIGKILL escalation'
print(json.dumps(out))
