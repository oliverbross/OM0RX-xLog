from pathlib import Path
import datetime,json,sqlite3,sys
stage=Path(__file__).parent;label=sys.argv[1]
path=next((stage/'snapshots'/label).rglob('OM0RX-xLog.sqlite'))
db=sqlite3.connect(path);db.row_factory=sqlite3.Row
draft=json.loads(db.execute('SELECT payload FROM xlog_operator_draft').fetchone()[0])
epoch=datetime.datetime(2001,1,1,tzinfo=datetime.timezone.utc)
def iso(value,wire=False):
    if value is None:return None
    stamp=epoch+datetime.timedelta(seconds=value)
    return stamp.isoformat(timespec='seconds' if wire else 'microseconds').replace('+00:00','Z')
out={'draftID':draft['qso']['id'],'revision':draft['revision'],'automaticStart':draft['automaticStart'],'call':draft['qso']['call'],
    'nativePair':{k:iso(draft['qso'].get(k)) for k in ['start','end']},'canonicalWirePair':{k:iso(draft['qso'].get(k),True) for k in ['start','end']},
    'receipts':[json.loads(r[0]) for r in db.execute('SELECT payload FROM xlog_operator_receipts ORDER BY revision')],
    'contacts':[dict(r) for r in db.execute('SELECT local_id,call,qso_start,record_json FROM qsos ORDER BY qso_start')]}
(stage/('timestamp-'+label+'.json')).write_text(json.dumps(out,indent=2,default=lambda x:json.loads(x)))
print(json.dumps({k:v for k,v in out.items() if k not in ['receipts','contacts']}))
