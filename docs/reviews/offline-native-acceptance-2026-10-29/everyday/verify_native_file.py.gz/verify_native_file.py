from pathlib import Path
import datetime,hashlib,json,sqlite3
stage=Path(__file__).parent;path=stage/'everyday-reviewed-final.adi'
data=path.read_bytes();expected=(stage/'native-normal-export.adi').read_bytes();assert data==expected
prior=json.loads((stage/'normal-export-verification.json').read_text());assert hashlib.sha256(data).hexdigest()==prior['sha256']
def contacts_draft(label):
    p=next((stage/'snapshots'/label).rglob('OM0RX-xLog.sqlite'));db=sqlite3.connect(p)
    try:
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok' and not db.execute('PRAGMA foreign_key_check').fetchall()
        return list(db.execute('SELECT * FROM qsos ORDER BY local_id')),json.loads(db.execute('SELECT payload FROM xlog_operator_draft').fetchone()[0])
    finally:db.close()
before=contacts_draft('native-save-before');cancel=contacts_draft('native-save-cancel');after=contacts_draft('native-save-after')
assert before==cancel==after and len(after[0])==3 and after[1]['qso']['call']=='K9KEEP'
out={'source':'c09ecfdd5f9eec9834733f7dff3ae3bccffa8be7','actualFile':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'birthUTC':datetime.datetime.fromtimestamp(path.stat().st_birthtime,datetime.timezone.utc).isoformat(),'identicalToIndependentlyParsedReviewedRecords':True,'records':prior['records'],'cancelPreservedContactsAndDraft':True,'savePreservedContactsAndDraft':True,'retainedDraft':after[1],'preparedHashReceipt':None,'receiptBoundary':'Normal supplies no prepared-file SHA receipt; digest is calculated from actual NSSavePanel-persisted file and compared against independently parsed reviewed SQLite records and original native file. Actual UI confirms native Save then3 QSOs exported.'}
(stage/'native-file-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['records','retainedDraft']}))
