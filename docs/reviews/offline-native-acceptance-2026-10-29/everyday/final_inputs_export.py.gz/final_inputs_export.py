from pathlib import Path
import hashlib,json,subprocess
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog');stage=Path(__file__).parent
old=json.loads((repo/'.build/offline-native-acceptance-20261029-6e8bc944/final-source-inputs.json').read_text())
now={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in old['inputs']}
changed=[p for p,h in now.items() if h!=old['inputs'][p]]
expected={'prototype/src-tauri/src/main.rs','prototype/src/contesting/DetachedContestSurface.tsx','prototype/src/contesting/DetachedContestSurface.test.tsx','prototype/src-tauri/src/contest_analytics.rs','prototype/src/contesting/contestAnalyticsExport.ts','prototype/src/live/LogbookPanel.tsx','prototype/src/live/LogbookPanel.transfer.test.tsx'}
assert set(changed)==expected,changed
out={'testedSource':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'entryCheckpoint':'b755f3fd062f87af1658a2475b9708cb5e8b1a32','previousApplicationInputs':old['testedSource'],'inputs':now,'changedInputs':changed,'unchangedInputs':len(now)-len(changed),'workerInputsUnchanged':True,'versionAndLocksUnchanged':True}
(stage/'native-save-source-inputs.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='inputs'}))
