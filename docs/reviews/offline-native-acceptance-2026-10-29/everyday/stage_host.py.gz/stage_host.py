from pathlib import Path
import datetime,hashlib,json,plistlib,shutil,subprocess
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog');stage=Path(__file__).parent
old=repo/'.build/offline-native-acceptance-20261029-6e8bc944/XLog Offline Precision Development.app'
new=stage/'XLog Everyday Development.app';assert not new.exists()
receipt=json.loads((stage/'host-build-receipt.json').read_text());assert receipt['exit']==0
assert not any(str(old/'Contents/MacOS/xlog-prototype') in line for line in subprocess.check_output(['ps','-axo','args='],text=True).splitlines())
shutil.copytree(old,new,symlinks=True)
target=new/'Contents/MacOS/xlog-prototype';target.unlink();shutil.copy2(receipt['binary'],target)
assert hashlib.sha256(target.read_bytes()).hexdigest()==receipt['sha256']
info=new/'Contents/Info.plist';values=plistlib.loads(info.read_bytes());values['CFBundleName']='XLog Everyday Development';info.write_bytes(plistlib.dumps(values))
fixture=stage/'native_fixture.py';source=fixture.read_text();source=source.replace('app = Path('+repr(str(old))+')','app = Path('+repr(str(new))+')');fixture.write_text(source)
seedpath=stage/'seed.json';seed=json.loads(seedpath.read_text());(stage/'initial-seed-preserved.json').write_text(json.dumps(seed,indent=2));seed.update(app=str(new),executable=str(target),worker=str(new/'Contents/MacOS/xlog-prototype-worker'));seedpath.write_text(json.dumps(seed,indent=2))
result={'head':receipt['head'],'app':str(new),'hostSHA256':receipt['sha256'],'workerSHA256':hashlib.sha256((new/'Contents/MacOS/xlog-prototype-worker').read_bytes()).hexdigest(),'preservedDevelopmentLayout':str(old),'installed':False,'candidate':False,'versionBumped':False,'provenance':'Private development layout using affected host build only, matching existing worker/resources'}
(stage/'everyday-development-receipt.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
