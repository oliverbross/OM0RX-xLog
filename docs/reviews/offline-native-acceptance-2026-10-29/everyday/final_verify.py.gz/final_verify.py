from pathlib import Path
import datetime,hashlib,json,sqlite3,subprocess
stage=Path(__file__).parent;repo=stage.parent.parent
def load(name):return json.loads((stage/name).read_text())
def rows(label,name,table):
    path=next((stage/'snapshots'/label).rglob(name));db=sqlite3.connect(path)
    db.row_factory=sqlite3.Row
    try:return [dict(r) for r in db.execute('SELECT * FROM '+table)]
    finally:db.close()
def normal(label):return rows(label,'OM0RX-xLog.sqlite','qsos'),json.loads(rows(label,'OM0RX-xLog.sqlite','xlog_operator_draft')[0]['payload'])
first=normal('blob-export-no-file');last=normal('native-save-roundtrip');assert first==last
before=rows('edit-last-before','contest.sqlite','DXLOG');after=rows('native-save-roundtrip','contest.sqlite','DXLOG')
assert len(before)==len(after)==1 and {k for k in before[0] if before[0][k]!=after[0][k]}=={'Comment'}
assert after[0]['Comment']=='Everyday Edit last correction Ω'
assert rows('edit-last-before','contest.sqlite','xlog_serial')==rows('native-save-roundtrip','contest.sqlite','xlog_serial')
audit=rows('native-save-roundtrip','contest.sqlite','xlog_qso_audit');assert [r['kind'] for r in audit]==['commit','correct']
rapid=load('timestamp-timestamp-rapid-ready.json');manual=load('timestamp-timestamp-manual-ready.json');final=load('timestamp-timestamp-final-reopen.json');canonical=load('timestamp-timestamp-reversal-canonical.json')
assert rapid['automaticStart'] is True and manual['automaticStart'] is False
assert len(final['contacts'])==2 and {r['call'] for r in final['contacts']}=={'K2RAPID','K3MANUAL'}
record={r['call']:r['record_json'] for r in final['contacts']}
epoch=datetime.datetime(2001,1,1,tzinfo=datetime.timezone.utc)
def iso(value):return (epoch+datetime.timedelta(seconds=value)).isoformat().replace('+00:00','Z')
autoUTC=iso(record['K2RAPID']['start']);manualUTC=iso(record['K3MANUAL']['start'])
assert manualUTC=='2026-10-29T13:54:27Z'
assert record['K2RAPID']['id']==rapid['draftID'] and record['K3MANUAL']['id']==manual['draftID']
assert record['K2RAPID']['start']>datetime.datetime.fromisoformat(rapid['nativePair']['start'].replace('Z','+00:00')).timestamp()-epoch.timestamp()+5
b=datetime.datetime.fromisoformat(load('rapid-real-before-save-stamp.json')['utc']);a=datetime.datetime.fromisoformat(load('rapid-after-save-stamp.json')['utc']);saved=epoch+datetime.timedelta(seconds=record['K2RAPID']['start']);assert b<=saved<=a
assert {k:canonical[k] for k in ['draftID','revision','automaticStart','nativePair','canonicalWirePair','call']}=={k:final[k] for k in ['draftID','revision','automaticStart','nativePair','canonicalWirePair','call']}
saves=[r for r in final['receipts'] if r['mutation']['action']=='save'];assert len(saves)==2 and len({r['mutation']['operationID'] for r in saves})==2
assert {r['savedQSO']['id'] for r in saves}=={v['id'] for v in record.values()}
integrity=[]
for p in sorted((stage/'snapshots').rglob('*.sqlite')):
    db=sqlite3.connect('file:'+str(p)+'?mode=ro&immutable=1',uri=True)
    try:result=db.execute('PRAGMA integrity_check').fetchone()[0];fk=list(db.execute('PRAGMA foreign_key_check'));assert result=='ok' and not fk;integrity.append({'copy':str(p.relative_to(stage)),'integrity':result,'foreignKeyViolations':len(fk)})
    finally:db.close()
source=load('native-save-source-inputs.json');assert source['testedSource']=='c09ecfdd5f9eec9834733f7dff3ae3bccffa8be7'
assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in source['inputs'].items())
build=load('frontend-native-save-wrapper-build-receipt.json');assert build['exit']==0 and all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in build['inputs'].items())
assert not any('XLog Everyday Native Save Development.app/Contents/MacOS/xlog-prototype' in p for p in subprocess.check_output(['ps','-axo','args='],text=True).splitlines())
out={'testedSource':source['testedSource'],'checks':{'normalExport':'PASS after NA-005: actual Native Save/Cancel/file/parse/SQLite','editLast':'PASS after NA-004: actual editor/correctiononce/cancel/reopen; sameidentity/count/serialledger','exactTimestampReversal':'UNVERIFIED: full-pair preflush condition not established through supported native tooling; no fabricated automatic reversal pass'},'automaticControlUTC':autoUTC,'automaticButtonBounds':{'before':b.isoformat(),'after':a.isoformat()},'manualControlUTC':manualUTC,'saveReceipts':saves,'retainedReversalDraft':{k:final[k] for k in ['draftID','revision','automaticStart','nativePair','canonicalWirePair','call']},'normalDraftPreserved':last[1],'contestQSOID':after[0]['ID'],'contestCount':1,'serialLedgerIdentical':True,'auditKinds':[r['kind'] for r in audit],'finalRoundtrip':'57683/57724 ->57818/57820 ->57892/57901','copiedDatabaseChecks':integrity,'all1843SourceHashesMatch':True,'finalFrontendConsumedHashesMatch':True,'privateAppStopped':True,'NO_GO':True}
(stage/'everyday-native-final-verification.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['saveReceipts','normalDraftPreserved','copiedDatabaseChecks']}));print('Copied SQLite integrity/foreign-key checks: '+str(len(integrity)))
