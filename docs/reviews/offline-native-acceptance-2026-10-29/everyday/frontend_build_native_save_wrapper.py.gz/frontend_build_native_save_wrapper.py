from pathlib import Path
import datetime,hashlib,json,subprocess,time
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog');stage=Path(__file__).parent
original=repo/'prototype/dist';retained=stage/'original-dist-during-check';built=stage/'frontend-native-save-wrapper'
assert original.is_dir() and not retained.exists() and not built.exists()
def hashes(path):return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}
before=hashes(original);inode=original.stat().st_ino
started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
original.rename(retained)
try:
    with (stage/'frontend-native-save-wrapper-build.log').open('wb') as log:result=subprocess.run(['npm','run','build'],cwd=repo/'prototype',stdout=log,stderr=subprocess.STDOUT)
finally:
    if original.exists():original.rename(built)
    retained.rename(original)
    assert original.stat().st_ino==inode and hashes(original)==before
receipt={'argv':['npm','run','build'],'cwd':str(repo/'prototype'),'startUTC':started,'endUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed':time.monotonic()-tick,'exit':result.returncode,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'originalDistInode':inode,'originalDistHashes':before,'originalDistRestored':True,'inputs':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((repo/'prototype/src').rglob('*')) if p.is_file()},'builtFiles':hashes(built),'sourceDiff':subprocess.check_output(['git','diff'],cwd=repo,text=True)}
(stage/'frontend-native-save-wrapper-build-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps({'exit':result.returncode,'restoredOriginalDist':True,'head':receipt['head']}));raise SystemExit(result.returncode)
