from pathlib import Path
stage=Path(__file__).parent
source=(stage/'frontend_build_native_save.py').read_text().replace("'frontend-native-save'","'frontend-native-save-wrapper'").replace("'frontend-native-save-build.log'","'frontend-native-save-wrapper-build.log'").replace("'frontend-native-save-build-receipt.json'","'frontend-native-save-wrapper-build-receipt.json'")
(stage/'frontend_build_native_save_wrapper.py').write_text(source)
