from pathlib import Path
import gzip,hashlib,json
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog');stage=Path(__file__).parent
target=repo/'docs/reviews/offline-native-acceptance-2026-10-29/everyday'
assert json.loads((stage/'everyday-native-final-verification.json').read_text())['privateAppStopped']
assert not (target/'MANIFEST.json').exists()
target.mkdir(parents=True,exist_ok=True)
files=[p for p in stage.iterdir() if p.is_file() and p.suffix in {'.json','.md','.py','.adi','.log','.sample','.stderr'}]
files += [p for p in (stage/'snapshots').rglob('*') if p.is_file() and p.suffix=='.sqlite']
manifest=[]
for p in sorted(files):
    relative=p.relative_to(stage);data=p.read_bytes();compress=p.suffix not in {'.md','.adi'}
    stored=Path(str(relative)+('.gz' if compress else ''));destination=target/stored
    assert not destination.exists();destination.parent.mkdir(parents=True,exist_ok=True)
    encoded=gzip.compress(data,mtime=0) if compress else data;destination.write_bytes(encoded)
    manifest.append({'original':str(relative),'stored':str(stored),'originalBytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'storedBytes':len(encoded),'storedSHA256':hashlib.sha256(encoded).hexdigest(),'encoding':'gzip' if compress else 'identity'})
(target/'MANIFEST.json').write_text(json.dumps({'testedSource':'c09ecfdd5f9eec9834733f7dff3ae3bccffa8be7','artifactCount':len(manifest),'artifacts':manifest},indent=2))
for item in manifest:
    data=(target/item['stored']).read_bytes();assert hashlib.sha256(data).hexdigest()==item['storedSHA256']
    original=gzip.decompress(data) if item['encoding']=='gzip' else data;assert hashlib.sha256(original).hexdigest()==item['sha256']
print(json.dumps({'artifacts':len(manifest),'directory':str(target),'allOriginalAndStoredHashesVerified':True,'developmentAppsNotArchived':True,'allPriorArchivesPreserved':True}))
