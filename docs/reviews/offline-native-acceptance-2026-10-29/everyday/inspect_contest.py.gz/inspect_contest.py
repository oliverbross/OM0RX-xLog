from pathlib import Path
import sqlite3,json,sys
stage=Path(__file__).parent
label=sys.argv[1]
paths=[p for p in (stage/'snapshots'/label).rglob('*.sqlite') if p.name!='OM0RX-xLog.sqlite']
assert len(paths)==1,paths
db=sqlite3.connect(paths[0]);db.row_factory=sqlite3.Row
tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
out={}
for table in tables:
    rows=list(db.execute('SELECT * FROM "'+table+'"'))
    if not rows:continue
    out[table]=[dict(row) for row in rows]
(stage/('contest-'+label+'.json')).write_text(json.dumps(out,indent=2,default=lambda x:{'hex':bytes(x).hex()}))
print(json.dumps({'path':str(paths[0]),'tables':{k:len(v) for k,v in out.items()},'columns':{k:list(v[0]) for k,v in out.items()}}))
