from pathlib import Path
import datetime, gzip, hashlib, json, re, shutil, subprocess

ROOT=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
TASK=Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1')
DEST=ROOT/'docs/reviews/final-code-audit-followup-2026-10-29'
sha=lambda value:hashlib.sha256(value).hexdigest()
baseline=json.loads((TASK/'baseline.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==baseline['head']
prior=(ROOT/'FINAL_CODE_AUDIT.md').read_bytes()
assert sha(prior)==baseline['priorReportSHA256']
assert (DEST/'PRIOR_FINAL_CODE_AUDIT.md').read_bytes()==prior
assert json.loads((TASK/'audit-qa.json').read_text())['rangeErrors']==[]
for path,digest in json.loads((TASK/'source-sha256.json').read_text()).items():
    assert sha((ROOT/path).read_bytes())==digest,path

commands=r'''# Commands and result boundaries

Audited source: canonical main 0375a8e1a385252519a99127fe9d8f40d639365a; application f3f6e3dee40af29cb6801ef8ee422c521629e168. All commands below used isolated fixtures or source inspection. No live application/provider/hardware/RF was operated. Timestamps and exact root argv/cwd are in root-checks.json; environment.json records observed versions. Original tool-output blocks for compile-only attempts are represented by reviewer receipts, not newly manufactured raw logs.

## Executed current-source checks

From /Users/oliver/Documents/Projects/OM0RX-xLog/prototype:

```sh
node node_modules/vitest/vitest.mjs run --configLoader native --cache false --maxWorkers 1 src/live/OperatorDraftTime.test.tsx src/live/DetachedQSOSurface.test.tsx src/live/operatorDraftSession.test.ts src/live/operatorDraftTransport.test.ts src/live/QSOEditorPower.test.tsx src/live/adifTransfer.test.ts src/live/adifTransfer.schema.test.ts tests/detached-logbook.test.tsx
```

PASS 1442 tests / 8 files, agents/frontend/existing-tests.log.gz. Four FA-009 cases are included, not added to this count. No clean dependency install/build was performed.

From the repository root:

```sh
node --test prototype/scripts/contesting-worker-acceptance-qso.node-test.mjs prototype/scripts/contesting-worker-current-scenario.node-test.mjs
/opt/homebrew/bin/python3.12 -B -m unittest discover -s python/tests -p test_reviewed_security_patches.py -v
/opt/homebrew/bin/python3.12 -B prototype/scripts/test-contest-python-relocation.py
/opt/homebrew/bin/python3.12 -B tools/check_reviewed_security_patches.py
```

PASS 6 Node, 7 Python policy, 12 relocation, four reviewed patch floors. Corresponding root .json/.log.gz pairs retain exit0 and hashes. The frontend agent's node-stale.log.gz runs only the four current-scenario cases and overlaps the root six. No actual worker process was launched by these commands.

```sh
/opt/homebrew/bin/python3.12 -B /tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/data/run_python.py
```

PASS17: test_remediation_import_replica (8), test_remediation_wae (3), test_recorder (6). Runner and actual summary retained. The runner disables contest UDP and puts temporary data under its scratch runtime. A standalone raw stdout log was not captured for this agent run; python-test-summary.json is the retained result receipt.

```sh
swift test --skip-build --scratch-path /Users/oliver/Documents/Projects/OM0RX-xLog/.build/phase5-followup-20261029/portable --no-parallel --filter 'BackupRestoreAuthorityTests|WavelogDestinationAuthorityTests|LiveFldigiBridgeTests|StationRadioRegistryTests|NativePowerSelectionTests|CWComputeWirePrimitiveTests|LiveOpportunitiesMethodsTests|portablePriorCleanupUsesFirstAdmissionClock'
```

PASS39 XCTest +19 Swift Testing=58. Existing exact-source portable build cache, no fresh compilation. root_checks.py records the explicit environment: inherited XLOG/XCW opt-ins removed, portable profile and test Python selected, UDP denied. All five root commands' generic buildBoundary text is conservative but applies as a compiled-cache boundary only to Swift.

## Executed audit counterexamples

```sh
/opt/homebrew/bin/python3.12 -B /tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/data/probe_country_reconcile.py
/opt/homebrew/bin/python3.12 -B /tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/data/schema_compare.py
```

First command reproduces FA-013 in actual current master/client Hosts: legitimate reference_reconcile rejected and client SQLite dump unchanged. Successful driver exit means the expected defect occurred. Initial /tmp alias attempt failed the Host root guard; the canonical /private/tmp run succeeded. Second command independently matches179 source/XML standard names, not full XSD scalar validation. The initial schema lookup used wrong nesting; corrected source and successful result retained.

From repository root, using the scratch config (root and imports explicitly canonicalized):

```sh
node prototype/node_modules/vitest/vitest.mjs run reversal.test.tsx --config /tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/frontend/vitest.config.mjs --configLoader native --cache false
node prototype/node_modules/vitest/vitest.mjs run detached-reversal.test.tsx --config /tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/frontend/vitest.config.mjs --configLoader native --cache false
node /tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/frontend/make-fldigi-proof.mjs
node prototype/node_modules/vitest/vitest.mjs run fldigi-stop --testNamePattern 'fresh fldigi uncertain Stop' --config /tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/frontend/vitest.config.mjs --configLoader native --cache false
```

Final authoritative logs: reversal-r2 (1FAIL/1PASS), detached-reversal-r2 (2FAIL/1PASS), fldigi-stop-r3 (1FAIL/1PASS/195SKIP). Failures are intended product-behavior requirements, not altered assertions. Native/backend behavior is source traced and simulated in these rendered cases; no SQLite Save or fldigi RPC occurs. r3 supersedes r2's weaker retained-duty precondition; failed first fixture setup is retained. Existing skipped Not1MM cases are not treated as passes. Scratch sources and config are gzip byte copies; decompress to a separate private directory before reuse, adjust explicit roots/imports intentionally, and never run against production roots.

## Compile-only and blocked evidence

agents/data/prepare_swift.py.gz and DataProof.swift.gz contain an exact core-method driver and source-bound URLProtocol fake. source-evidence.json binds existing f3 native core objects/modules. Compilation succeeded after retaining @testable for test DTO initializers; runtime data-proof was permanently denied by the tool allowlist. FA-015/016 are source-confirmed, not runtime-reproduced. The initial compiler access error is documented in the reviewer narrative; no raw compiler log was captured.

agents/radio/build_proofs.py.gz contains exact source extraction for TCI and agent retirement. TCI exact-source compilation succeeded, but tci-proof execution was permanently denied. Repeated READY reachability/consequence remains a hypothesis. An earlier agent-proof compiled against an incorrect neighboring ownership fake; generator corrected later, binary stale and unexecuted. No runtime result is claimed. Source binding/static-proofs and coverage-qa are preserved. Binaries are deliberately excluded.

No blocked executable was retried through wrappers, renaming or another tool; no allowlist/security configuration changed. cargo-audit/sw_vers restrictions from prior work were not retried. This is command-policy limitation, not an application-test failure or an approval request.

## Read-only QA / preservation

finish_inventory.py, merge_coverage.py, audit_qa.py, publish_audit.py and verify_publication.py are retained as compressed audit scripts. They hash all1838 source inputs, assign79 changed inputs, validate329 explicit source ranges, compare historical report bytes, check two private disposable SQLite databases read-only (integrity ok, zero foreign-key violations), check report IDs/links and verify archive hashes. Initial draft-link QA caught a wrong RemoteAgentClient directory; the link was corrected before publication. This is report QA, not an application failure.

No full regression/build/sanitizer/advisory scan was repeated. Historical exact-source Phase5 builds/CI are referenced with their own scope and skipped steps in STABILITY_REPORT.md; this audit does not copy their passing status into fresh runtime acceptance.
'''
(TASK/'COMMANDS.md').write_text(commands)

findings=[]
for number in range(10,18):
    item={'id':f'FA-{number:03}','severity':'High' if number==10 else 'Medium','disposition':'Return to Phase5; no repair in independent audit'}
    if number in [13,14,17]:
        item['evidence']='Executed counterexample'+(' with native/backend semantics simulated' if number in [14,17] else ' using actual current Hosts')
    else:item['evidence']='Source-confirmed failure mechanism; runtime verification unexecuted'
    findings.append(item)
(TASK/'finding-evidence.json').write_text(json.dumps(findings,indent=2)+'\n')

def artifact(relative, data):
    target=DEST/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert target.read_bytes()==data,relative
    else:target.write_bytes(data)

entries=[]
excluded=[]
plain={'.json','.md'}
compressed={'.py','.mjs','.swift','.tsx','.diff','.log'}
for source in sorted(TASK.rglob('*')):
    if source.is_symlink(): excluded.append(str(source.relative_to(TASK)));continue
    if not source.is_file():continue
    relative=source.relative_to(TASK)
    if any(part in ['runtime','cache','__pycache__','node_modules'] for part in relative.parts) or source.name=='FINAL_CODE_AUDIT.draft.md':
        excluded.append(str(relative));continue
    if source.suffix not in plain|compressed:
        excluded.append(str(relative));continue
    data=source.read_bytes()
    if source.suffix in compressed:
        saved=Path(str(relative)+'.gz');stored=gzip.compress(data,mtime=0)
    else:saved=relative;stored=data
    artifact(saved,stored)
    entries.append({'originalPath':str(relative),'artifact':str(saved),'originalBytes':len(data),'originalSHA256':sha(data),'artifactBytes':len(stored),'artifactSHA256':sha(stored),'encoding':'gzip' if source.suffix in compressed else 'identity'})

index={'schema':1,'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':baseline['head'],'applicationSource':baseline['applicationSource'],'entries':entries,'excludedScratchPaths':excluded,'exclusionPolicy':'No executable binaries, SQLite/sidecars, runtime/caches/dependencies, symlinks or duplicate root report; preserved text bytes only'}
(DEST/'artifact-index.json').write_text(json.dumps(index,indent=2)+'\n')

readme='''# Independent Phase 6 follow-up evidence — 29 October 2026

Audited canonical `main` at `0375a8e1a385252519a99127fe9d8f40d639365a`, application `f3f6e3dee40af29cb6801ef8ee422c521629e168`, version1.3.60. No application/test/config/dependency edits or live application/provider/hardware/RF operations. Report/evidence only.

Read [the final audit](/Users/oliver/Documents/Projects/OM0RX-xLog/FINAL_CODE_AUDIT.md) for severity, failure mechanisms, original-finding dispositions, release criteria and Phase5 return. Eight findings: oneHigh/sevenMedium; three executed counterexamples and five source-confirmed runtime-unverified mechanisms. No introduced application regression established. Previous report preserved as PRIOR_FINAL_CODE_AUDIT.md (SHA256 b4ec929f38cfa5b0989c72320f6e337a82b8f485ddf5a00bb151839778830104).

- COMMANDS.md, environment.json, root-checks.json and per-check receipts: commands, actual outcomes and cache boundaries.
- changed-input-coverage.json: all79 changed inputs; latest-remediation-paths.json identifies32 latest followup inputs. Compressed diffs preserve comparisons.
- agents/*/coverage.json and root-coverage.json: function/caller/test depth; audit-qa.json validates329 explicit ranges across90 current keyed paths. historical-coverage-followup.json maps70 frozen-inventory paths (27partial/26scan/17full), without automatic whole-file promotion.
- agents/*/REVIEW.md and frontend/FLDIGI_REVIEW.md: independent source-first scopes, rejected hypotheses, evidence and limitations. Local candidate IDs map to root FA-010–017 in finding-evidence.json.
- agents/data/country-reconcile-result.json: actual Host failure and rollback. agents/frontend/*-r2.log.gz and fldigi-stop-r3.log.gz: intended-behavior requirement failures and passing controls; first attempts also retained.
- source-sha256.json and preservation-before-publication.json:1838unchanged source inputs and five historical reports preserved. disposable-db-integrity.json: only two private fixture databases read; both clean, no production data accessed.
- artifact-index.json records original and saved byte counts/hashes; gzip uses fixedmtime0. SHA256SUMS covers every evidence file except itself. verify_publication.py.gz validates the report, immutable prior report, archive, ranges, source and permitted Git paths.

All probe sources are audit artifacts, not installed application tests. Decompression does not authorize running a provider or using production roots. No executable binary, fixture SQLite/runtime tree, dependency cache or symlink is archived. Compilation is not execution; the agent-stop compiled binary is explicitly stale, and TCI/data binaries were tool-blocked. No bypass attempted. A missing raw agent compile/Python stdout log is not fabricated; the actual summary/source receipts and boundaries are stated in COMMANDS.md.

Earlier review/remediation/stability evidence directories and the other root reports are unchanged. Full manual review and installed/native/provider/hardware/physical acceptance remain incomplete. Passing existing tests does not erase the new failures.
'''
(DEST/'README.md').write_text(readme)
(ROOT/'FINAL_CODE_AUDIT.md').write_bytes((TASK/'FINAL_CODE_AUDIT.draft.md').read_bytes())

files=[]
for path in sorted(DEST.rglob('*')):
    assert not path.is_symlink(),path
    if path.is_file() and path.name!='SHA256SUMS':files.append((str(path.relative_to(DEST)),sha(path.read_bytes())))
(DEST/'SHA256SUMS').write_text(''.join(digest+'  '+path+'\n' for path,digest in files))
print(json.dumps({'reportSHA256':sha((ROOT/'FINAL_CODE_AUDIT.md').read_bytes()),'artifacts':len(entries),'evidenceFiles':len(files)+1,'excludedScratchFiles':len(excluded),'applicationChanges':0},indent=2))
