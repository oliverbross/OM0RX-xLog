import hashlib,json,pathlib,subprocess,tomllib
ROOT=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog'); TASK=pathlib.Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1')
old='530de4c4e4b23281ec60585cc7a2e5ca011476fb'
def contents(path,commit=None): return subprocess.check_output(['git','show',commit+':'+path],cwd=ROOT) if commit else (ROOT/path).read_bytes()
np='prototype/package-lock.json'; cp='prototype/src-tauri/Cargo.lock'
a=json.loads(contents(np,old))['packages']; b=json.loads(contents(np))['packages']
npm=[]
for name in sorted(a.keys()|b.keys()):
    if a.get(name)!=b.get(name):
        npm.append({'path':name,'beforeVersion':a.get(name,{}).get('version'),'afterVersion':b.get(name,{}).get('version'),'changedFields':sorted(k for k in a.get(name,{}).keys()|b.get(name,{}).keys() if a.get(name,{}).get(k)!=b.get(name,{}).get(k))})
def rust(data): return {(r['name'],r['version']):r for r in tomllib.loads(data.decode())['package']}
a=rust(contents(cp,old)); b=rust(contents(cp)); removed=[list(k) for k in a.keys()-b.keys()]; added=[list(k) for k in b.keys()-a.keys()]
edges=[{'package':list(k),'before':a[k].get('dependencies',[]),'after':b[k].get('dependencies',[])} for k in a.keys()&b.keys() if a[k]!=b[k]]
obj={'base':old,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'npm':npm,'cargoRemoved':sorted(removed),'cargoAdded':sorted(added),'cargoExistingChanged':edges,
 'currentLockSHA256':{p:hashlib.sha256(contents(p)).hexdigest() for p in [np,cp]},'scope':'Lock/delta and narrow patch-floor review only, not new full advisory scan or supply-chain certification'}
(TASK/'lock-review.json').write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps(obj,indent=2))
