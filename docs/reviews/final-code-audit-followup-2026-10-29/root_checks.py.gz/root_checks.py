import datetime,hashlib,json,os,pathlib,subprocess,time
ROOT=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
TASK=pathlib.Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1')
env={k:v for k,v in os.environ.items() if not k.startswith(('XLOG_','XCW_'))}
env.update({'PYTHONDONTWRITEBYTECODE':'1','XLOG_CONTEST_N1MM_UDP_ALLOWED':'0','XLOG_PORTABLE_ONLY':'1',
 'XLOG_TEST_PYTHON':'/opt/homebrew/bin/python3.12','XLOG_CONTEST_PYTHON':'/opt/homebrew/bin/python3.12'})
checks=[
 ('node-evidence',['node','--test',*[str(p.relative_to(ROOT)) for p in sorted((ROOT/'prototype/scripts').glob('*.node-test.mjs'))]]),
 ('security-policy',['/opt/homebrew/bin/python3.12','-B','-m','unittest','discover','-s','python/tests','-p','test_reviewed_security_patches.py','-v']),
 ('runtime-boundaries',['/opt/homebrew/bin/python3.12','-B','prototype/scripts/test-contest-python-relocation.py']),
 ('patch-floors',['/opt/homebrew/bin/python3.12','-B','tools/check_reviewed_security_patches.py']),
 ('focused-swift',['swift','test','--skip-build','--scratch-path',str(ROOT/'.build/phase5-followup-20261029/portable'),'--no-parallel','--filter','BackupRestoreAuthorityTests|WavelogDestinationAuthorityTests|LiveFldigiBridgeTests|StationRadioRegistryTests|NativePowerSelectionTests|CWComputeWirePrimitiveTests|LiveOpportunitiesMethodsTests|portablePriorCleanupUsesFirstAdmissionClock']),
]
rows=[]
for label,command in checks:
    started=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
    log=TASK/(label+'.log')
    with log.open('wb') as stream:
        try:
            child=subprocess.run(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=300)
            code=child.returncode
        except subprocess.TimeoutExpired: code=124
    row={'id':label,'command':command,'cwd':str(ROOT),'startedUTC':started,'finishedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':round(time.monotonic()-t,3),'exit':code,'logSHA256':hashlib.sha256(log.read_bytes()).hexdigest(),
      'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'buildBoundary':'Existing exact-source cached build; no fresh build or hardware/provider acceptance claimed','environment':'Inherited XLOG/XCW opts removed; UDP denied; Python and portable test profile explicit'}
    (TASK/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n'); rows.append(row)
    print(json.dumps(row),flush=True)
(TASK/'root-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
