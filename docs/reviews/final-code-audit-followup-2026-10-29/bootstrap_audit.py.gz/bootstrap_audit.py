import datetime,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
TASK=pathlib.Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1')
DEST=ROOT/'docs/reviews/final-code-audit-followup-2026-10-29'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='0375a8e1a385252519a99127fe9d8f40d639365a'
DEST.mkdir(parents=True,exist_ok=True)
prior=(ROOT/'FINAL_CODE_AUDIT.md').read_bytes()
(DEST/'PRIOR_FINAL_CODE_AUDIT.md').write_bytes(prior)
names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
prefixes=('Sources/','Tests/','prototype/','python/','native/','tools/','scripts/','.github/')
inputs=[p for p in names if p and (p.startswith(prefixes) or p in ('AGENTS.md','Package.swift','Package.resolved'))]
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest={p:sha((ROOT/p).read_bytes()) for p in inputs}
(TASK/'source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
for label,base in [('all-remediation','530de4c4e4b23281ec60585cc7a2e5ca011476fb'),('latest-remediation','fd774aef41f196e5f3b7da627a1b221af6594ba7')]:
    command=['git','diff','--unified=30',base,head,'--',*prefixes,'Package.swift','Package.resolved']
    data=subprocess.check_output(command,cwd=ROOT)
    (TASK/(label+'.diff')).write_bytes(data)
    paths=subprocess.check_output(['git','diff','--name-only',base,head,'--',*prefixes,'Package.swift','Package.resolved'],cwd=ROOT,text=True).splitlines()
    (TASK/(label+'-paths.json')).write_text(json.dumps(paths,indent=2)+'\n')
receipt={'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'applicationSource':'f3f6e3dee40af29cb6801ef8ee422c521629e168','cleanAtEntry':True,'FFMainChecked':True,'inputs':len(manifest),'priorReportSHA256':sha(prior),'scope':'Read-only current-source audit; report/evidence changes only; no production/provider/hardware/UI operation.'}
(TASK/'baseline.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
for label in ['all-remediation','latest-remediation']:
    print(label,len(json.loads((TASK/(label+'-paths.json')).read_text())),'changed inputs')
