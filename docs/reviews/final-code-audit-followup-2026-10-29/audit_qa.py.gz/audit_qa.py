from pathlib import Path
import collections, csv, datetime, hashlib, json, re, sqlite3, subprocess

ROOT=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
TASK=Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1')
sha=lambda data:hashlib.sha256(data).hexdigest()
errors=[]
ranges=[]
paths=set()
def visit(value, path=None, ledger=''):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str): path=value['path']
        if path:
            source=ROOT/path
            if not source.is_file(): errors.append([ledger,'missing path',path])
            else: paths.add(path)
            for key in ['range','ranges','additionalReviewedRanges','supportingReviewedRanges']:
                spans=value.get(key)
                if not spans: continue
                if isinstance(spans,list) and all(isinstance(v,int) for v in spans): spans=[spans]
                if not isinstance(spans,list): continue
                for span in spans:
                    if not isinstance(span,list) or len(span)!=2 or not all(isinstance(v,int) for v in span):
                        errors.append([ledger,'bad range shape',path,key,span]);continue
                    count=len(source.read_text().splitlines())
                    if not 1<=span[0]<=span[1]<=count: errors.append([ledger,'range outside file',path,span,count])
                    ranges.append({'ledger':ledger,'path':path,'range':span})
        for child in value.values(): visit(child,path,ledger)
    elif isinstance(value,list):
        for child in value: visit(child,path,ledger)

for label in ['radio','frontend','data']:
    visit(json.loads((TASK/'agents'/label/'coverage.json').read_text()),ledger=label)
visit(json.loads((TASK/'root-coverage.json').read_text()),ledger='root')
changed=json.loads((TASK/'all-remediation-paths.json').read_text())
coverage=json.loads((TASK/'changed-input-coverage.json').read_text())
assert {row['path'] for row in coverage}==set(changed)
assert all(row['reviewers'] for row in coverage)
assert all(sha((ROOT/row['path']).read_bytes())==row['sha256'] for row in coverage)

with (ROOT/'docs/reviews/full-code-review-verification-2026-10-29/REVIEW_INVENTORY.tsv').open() as f:
    inventory=list(csv.DictReader(f,delimiter='\t'))
matched=[{'path':row['path_relative_to_reviewed_root'],'historicalDepth':row['depth'],'freshDepth':'See current function/range ledgers; no automatic whole-file promotion'} for row in inventory if row['path_relative_to_reviewed_root'] in paths]
gap={'scope':'Intersection with frozen historical inventory; range review is not automatic whole-file promotion','ledgerKeyedCurrentPaths':len(paths),'matchedHistoricalPaths':len(matched),'historicalDepthCounts':dict(collections.Counter(row['historicalDepth'] for row in matched)),'rows':matched}
(TASK/'historical-coverage-followup.json').write_text(json.dumps(gap,indent=2)+'\n')

databases=[]
for db in sorted((TASK/'agents/data/runtime').rglob('*.sqlite')):
    canonical=db.resolve();assert canonical.is_relative_to(TASK.resolve())
    connection=sqlite3.connect(canonical.as_uri()+'?mode=ro',uri=True)
    try:
        integrity=connection.execute('PRAGMA integrity_check').fetchall()
        foreign=connection.execute('PRAGMA foreign_key_check').fetchall()
    finally: connection.close()
    databases.append({'path':str(db.relative_to(TASK)),'integrity':integrity,'foreignKeyViolations':foreign})
    assert integrity==[('ok',)] and not foreign
(TASK/'disposable-db-integrity.json').write_text(json.dumps(databases,indent=2)+'\n')

manifest=json.loads((TASK/'source-sha256.json').read_text())
assert len(manifest)==1838
source_changes=[path for path,digest in manifest.items() if sha((ROOT/path).read_bytes())!=digest]
assert not source_changes,source_changes
draft=(TASK/'FINAL_CODE_AUDIT.draft.md').read_text()
expected=[f'FA-{i:03}' for i in range(10,18)]
headings=re.findall(r'^### (FA-\d{3}) —',draft,re.M)
assert headings==expected,headings
assert len(re.findall(r'^\| CR-\d{3} \|',draft,re.M))==12
assert len(re.findall(r'^\| FA-00\d \|',draft,re.M))==9
links=[]
for target in re.findall(r'\]\((/[^)]+)\)',draft):
    clean=target;line=None
    match=re.match(r'^(.*?):(\d+)$',clean)
    if match: clean,line=match.group(1),int(match.group(2))
    candidate=Path(clean)
    if 'final-code-audit-followup-2026-10-29/' in clean: continue
    assert candidate.is_file(),target
    if line: assert line<=len(candidate.read_text().splitlines()),target
    links.append({'path':clean,'line':line})

result={'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceInputsChecked':len(manifest),'sourceChanges':source_changes,'changedInputs':len(changed),'assignedInputs':sum(bool(row['reviewers']) for row in coverage),'validatedExplicitRanges':len(ranges),'rangeErrors':errors,'reviewedCurrentPaths':len(paths),'originalIDsReassessed':21,'newFindingIDs':headings,'newSeverityCounts':{'High':1,'Medium':7},'executedCounterexampleFindings':['FA-013','FA-014','FA-017'],'sourceConfirmedRuntimeUnverified':['FA-010','FA-011','FA-012','FA-015','FA-016'],'productionSourceLinksChecked':len(links),'disposableDatabasesChecked':len(databases)}
(TASK/'audit-qa.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert not errors,errors
