from pathlib import Path
import gzip, hashlib, json, re, subprocess

ROOT=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
DEST=ROOT/'docs/reviews/final-code-audit-followup-2026-10-29'
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads((DEST/'source-sha256.json').read_text())
assert len(manifest)==1838
assert all(sha((ROOT/path).read_bytes())==digest for path,digest in manifest.items())
for row in json.loads((DEST/'preservation-before-publication.json').read_text())['historicalReports'].values():assert row['unchanged']
for path in ['CODE_REVIEW.md','REMEDIATION_TRACKER.md','REGRESSION_TEST_REPORT.md','REVIEW_COVERAGE.md','STABILITY_REPORT.md']:
    assert (ROOT/path).read_bytes()==subprocess.check_output(['git','show','0375a8e1:'+path],cwd=ROOT),path
assert sha((DEST/'PRIOR_FINAL_CODE_AUDIT.md').read_bytes())=='b4ec929f38cfa5b0989c72320f6e337a82b8f485ddf5a00bb151839778830104'
assert (DEST/'PRIOR_FINAL_CODE_AUDIT.md').read_bytes()==subprocess.check_output(['git','show','0375a8e1:FINAL_CODE_AUDIT.md'],cwd=ROOT)
index=json.loads((DEST/'artifact-index.json').read_text())
for item in index['entries']:
    content=(DEST/item['artifact']).read_bytes()
    assert sha(content)==item['artifactSHA256'],item['artifact']
    original=gzip.decompress(content) if item['encoding']=='gzip' else content
    assert sha(original)==item['originalSHA256'],item['artifact']
    assert len(original)==item['originalBytes']
checksum_paths=set()
for line in (DEST/'SHA256SUMS').read_text().splitlines():
    digest,path=line.split('  ',1);checksum_paths.add(path)
    assert sha((DEST/path).read_bytes())==digest,path
actual={str(path.relative_to(DEST)) for path in DEST.rglob('*') if path.is_file() and path.name!='SHA256SUMS'}
assert checksum_paths==actual,(checksum_paths^actual)
qa=json.loads((DEST/'audit-qa.json').read_text());assert not qa['rangeErrors'] and qa['assignedInputs']==79
report=(ROOT/'FINAL_CODE_AUDIT.md').read_text()
links=[]
for target in re.findall(r'\]\((/[^)]+)\)',report):
    clean=target;line=None
    match=re.match(r'^(.*?):(\d+)$',clean)
    if match:clean,line=match.group(1),int(match.group(2))
    file=Path(clean);assert file.is_file(),target
    if line:assert 1<=line<=len(file.read_text().splitlines()),target
    links.append(target)
assert re.findall(r'^### (FA-\d{3}) —',report,re.M)==[f'FA-{n:03}' for n in range(10,18)]
changed=subprocess.check_output(['git','diff','--name-only','0375a8e1','--'],cwd=ROOT,text=True).splitlines()
assert all(path=='FINAL_CODE_AUDIT.md' or path.startswith('docs/reviews/final-code-audit-followup-2026-10-29/') for path in changed),changed
status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
print(json.dumps({'sourceInputsUnchanged':len(manifest),'artifactOriginalHashesVerified':len(index['entries']),'evidenceChecksumsVerified':len(checksum_paths),'reportLinksVerified':len(links),'originalReportsPreserved':5,'priorReportPreserved':True,'changedTrackedPaths':len(changed),'reportSHA256':sha(report.encode()),'gitStatus':status},indent=2))
