from pathlib import Path
import os, sys, tempfile, unittest, json
root=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out=Path(__file__).parent
runtime=out/'runtime';runtime.mkdir(parents=True,exist_ok=True)
tempfile.tempdir=str(runtime)
os.environ['XLOG_CONTEST_N1MM_UDP_ALLOWED']='0'
sys.path[:0]=[str(root/'python'),str(root/'python/tests')]
suite=unittest.defaultTestLoader.loadTestsFromNames(['test_remediation_import_replica','test_remediation_wae','test_recorder'])
result=unittest.TextTestRunner(verbosity=2).run(suite)
(out/'python-test-summary.json').write_text(json.dumps({'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors)},indent=2)+'\n')
sys.exit(not result.wasSuccessful())
