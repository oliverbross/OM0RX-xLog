from pathlib import Path
import hashlib,json
root=Path('/Users/oliver/Documents/Projects/OM0RX-xLog');out=Path(__file__).parent
text=(root/'Tests/XLogCoreTests/WavelogDestinationAuthorityTests.swift').read_text()
prefix=text[:text.index('final class WavelogDestinationAuthorityTests:')].replace('import XCTest\n','')
body=r'''
func expect(_ value: Bool, _ message: String) throws {
    if !value { throw NSError(domain: "FreshAudit", code: 1, userInfo: [NSLocalizedDescriptionKey:message]) }
}
@main struct DataProof {
  static func main() async throws {
    let fm=FileManager.default
    let root=URL(fileURLWithPath:CommandLine.arguments[1],isDirectory:true)
    try fm.createDirectory(at:root,withIntermediateDirectories:true)
    let manager=XLogBackupManager()
    let prefs=XLogBackupPreferences(deskBandMapBands:[],detachedBandMapBands:[],deskBandMapFollowsRadio:false,detachedBandMapLayout:"Adaptive grid",bandMapFontScale:1,intelligenceBands:[],clusterSpotOpensFullEditor:false)
    var settingsA=XLogSettings.defaults;settingsA.wavelogURL="https://destination-a.invalid";settingsA.wavelogStationID=1;settingsA.automaticSync=true
    var settingsB=settingsA;settingsB.wavelogStationID=2
    let source=try LogbookDatabase(url:root.appendingPathComponent("foreign-source.sqlite"))
    let first=QSO(wavelogID:42,call:"K1BACKUP",start:Date(timeIntervalSince1970:1_700_000_000),band:"20m",mode:"CW")
    let second=QSO(wavelogID:43,call:"K2BACKUP",start:Date(timeIntervalSince1970:1_700_000_060),band:"40m",mode:"CW")
    try source.save(first,markDirty:false);try source.save(second,markDirty:false)
    let preview=try manager.create(database:source,at:root.appendingPathComponent("foreign.xlogbackup"),settings:settingsB,preferences:prefs)
    source.close()
    let suite="FreshDataProof-"+UUID().uuidString;let defaults=UserDefaults(suiteName:suite)!
    defer { defaults.removePersistentDomain(forName:suite) }
    let store=SettingsStore(defaults:defaults);store.save(settingsA)
    let selected=try preview.settingsForRestore(keeping:settingsA,restoreSettings:true)
    try expect(selected.wavelogStationID==2 && !selected.automaticSync,"Backup authority helper did not select B safely")
    var paused=settingsA;paused.automaticSync=false;store.save(paused)
    let liveURL=root.appendingPathComponent("native-live.sqlite")
    let before=try LogbookDatabase(url:liveURL);try before.save(QSO(call:"W1BEFORE",band:"20m",mode:"CW"));before.close()
    _=try manager.installDatabase(from:preview.packageURL,to:liveURL,expectedPreview:preview)
    // Exact persisted state at AppModel1174, before1177/1178. A new process
    // loads this saved A and the newly installed B database (AppModel328/365).
    let reopenedStore=SettingsStore(defaults:UserDefaults(suiteName:suite)!)
    let restored=try LogbookDatabase(url:liveURL)
    let current=reopenedStore.load()
    try expect(current.wavelogStationID==1 && !current.automaticSync,"Paused A was not retained at interruption point")
    let config=try reopenedStore.wavelogConfiguration(for:current,token:"wl2_injected_fixture")
    let sessionConfig=URLSessionConfiguration.ephemeral;sessionConfig.protocolClasses=[DestinationHistoryProtocol.self]
    let session=URLSession(configuration:sessionConfig);defer{session.invalidateAndCancel()}
    DestinationHistoryProtocol.reset()
    _=try await SyncEngine(database:restored,configuration:config,session:session).synchronize()
    let firstAfter=try restored.lookup(localID:first.id),secondAfter=try restored.lookup(localID:second.id)
    try expect(secondAfter?.deletedAt != nil,"Wrong-authority synchronization did not expose the retained foreign ID")
    let interruption:[String:Any]=["savedStationID":current.wavelogStationID,"backupStationID":selected.wavelogStationID,"automaticSync":current.automaticSync,"firstCallAfter":firstAfter?.call ?? "missing","secondTombstoned":secondAfter?.deletedAt != nil,"interceptedRequests":DestinationHistoryProtocol.requests.count]
    restored.close()

    func package(_ name:String,_ stationID:Int) throws -> XLogBackupPreview {
      let dir=root.appendingPathComponent(name,isDirectory:true)
      try fm.createDirectory(at:dir,withIntermediateDirectories:true)
      let db=try LogbookDatabase(url:dir.appendingPathComponent("main.sqlite"));defer{db.close()}
      try db.save(QSO(call:"MAIN"+name,band:"20m",mode:"CW"))
      let contestRoot=dir.appendingPathComponent("Python",isDirectory:true)
      let contest=try LogbookDatabase(url:contestRoot.appendingPathComponent("session.sqlite"))
      try contest.save(QSO(call:"CONTEST"+name,band:"20m",mode:"CW"));contest.close()
      let reference=dir.appendingPathComponent("Reference",isDirectory:true)
      try fm.createDirectory(at:reference,withIntermediateDirectories:true)
      try Data(name.utf8).write(to:reference.appendingPathComponent("marker.txt"))
      var settings=settingsA;settings.wavelogStationID=stationID
      return try manager.create(database:db,at:dir.appendingPathComponent("selected.xlogbackup"),settings:settings,preferences:prefs,referenceDataURL:reference,contestingDataURL:contestRoot)
    }
    let a=try package("A",1),b=try package("B",2)
    let mixedLive=root.appendingPathComponent("mixed-main.sqlite")
    _=try manager.installDatabase(from:a.packageURL,to:mixedLive,expectedPreview:a)
    try fm.moveItem(at:a.packageURL,to:a.packageURL.deletingLastPathComponent().appendingPathComponent("retained-original.xlogbackup"))
    try fm.moveItem(at:b.packageURL,to:a.packageURL)
    // Same order and public methods as LiveLogbookMethods1513–1524.
    let mixedContests=root.appendingPathComponent("mixed-Python",isDirectory:true)
    _=try manager.installContestingData(from:a.packageURL,to:mixedContests)
    let mixedReference=root.appendingPathComponent("mixed-Reference",isDirectory:true)
    _=try manager.installReferenceData(from:a.packageURL,to:mixedReference)
    let main=try LogbookDatabase(url:mixedLive),contest=try LogbookDatabase(url:mixedContests.appendingPathComponent("session.sqlite"))
    let mainCall=try main.fetchAll().first!.call,contestCall=try contest.fetchAll().first!.call
    let ref=try String(contentsOf:mixedReference.appendingPathComponent("marker.txt"),encoding:.utf8)
    try expect(mainCall=="MAINA" && contestCall=="CONTESTB" && ref=="B","Cross-package publication was prevented")
    main.close();contest.close()
    let result:[String:Any]=["interruptedNativeRestore":interruption,"packageSwap":["main":mainCall,"contest":contestCall,"reference":ref,"selectedStationID":a.settings!.wavelogStationID,"replacementStationID":b.settings!.wavelogStationID]]
    let data=try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys])
    try data.write(to:root.deletingLastPathComponent().appendingPathComponent("swift-proof-result.json"))
    print(String(decoding:data,as:UTF8.self))
  }
}
'''
driver=out/'DataProof.swift';driver.write_text(prefix+body)
(out/'driver-preparation.json').write_text(json.dumps({'driverSHA256':hashlib.sha256(driver.read_bytes()).hexdigest(),'protocolSource':'Tests/XLogCoreTests/WavelogDestinationAuthorityTests.swift','protocolExtraction':'Verbatim prefix before XCTestCase, remove XCTest import only; retain @testable for internal test DTO initializers','allRequestsIntercepted':True},indent=2)+'\n')
print(driver)
