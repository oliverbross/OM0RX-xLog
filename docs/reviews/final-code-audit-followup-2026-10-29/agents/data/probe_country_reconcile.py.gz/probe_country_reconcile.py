from pathlib import Path
from copy import deepcopy
import os,sys,tempfile,json,uuid
root=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out=Path(__file__).parent;runtime=(out/'runtime').resolve();runtime.mkdir(parents=True,exist_ok=True);tempfile.tempdir=str(runtime)
os.environ['XLOG_CONTEST_N1MM_UDP_ALLOWED']='0'
sys.path[:0]=[str(root/'python'),str(root/'python/tests')]
from contest_host.host import Host,HostError
from test_cq_ww_ssb_host import CQWWSSBHostTests
uid=lambda:str(uuid.uuid4())
fixture=CQWWSSBHostTests();fixture.setUp()
config=deepcopy(fixture.create);fixture.tearDown()
session,workspace=uid(),uid();cursor={'revision':0,'sequence':0}
hosts=[Host(runtime/'country-master'),Host(runtime/'country-client')]
def call(h,method,**p):return h.dispatch({'id':uid(),'method':method,'params':deepcopy(p)})
def params(h):return dict(sessionID=session,workspaceGeneration=workspace,operationID=uid(),expectedRevision=h.database(session).state(session)['revision'])
def sync():
    global cursor
    p=call(hosts[0],'multi_changes',sessionID=session,workspaceGeneration=workspace,requestID=uid(),afterRevision=cursor['revision'],afterSequence=cursor['sequence'],limit=100)
    end={'revision':p['nextRevision'],'sequence':p['nextSequence']}
    result=call(hosts[1],'multi_replica_apply',**params(hosts[1]),authority=p['authority'],fromCursor=cursor,toCursor=end,changes=p['changes'],historyComplete=True)
    cursor=end
    return p
try:
    for h,master in zip(hosts,[True,False]):
        p=deepcopy(config);p.update(sessionID=session,workspaceGeneration=workspace,operationID=uid())
        call(h,'session_create',**p)
        setup=call(h,'setup_get',sessionID=session)['setup'];setup['network'].update(multiEnabled=True,multiMaster=master,stationName='M' if master else 'C')
        call(h,'setup_save',**params(h),setup=setup)
    sync()
    qso=uid()
    call(hosts[0],'qso_commit',**params(hosts[0]),qsoID=qso,timestamp='2026-10-20 08:00:00',fields={'callsign':'OE8DDX','other_2':'15'})
    sync()
    country=deepcopy(config['reference']['countries']['OE8DDX']);country['primary_pfx']='OE'
    call(hosts[0],'country_reconcile',**params(hosts[0]),referenceID=config['reference']['id'],repairs=[{'qsoID':qso,'callsign':'OE8DDX','country':country}])
    store=hosts[1].database(session);before=tuple(store.conn.iterdump())
    try: sync(); raise AssertionError('Expected unsupported real reference event')
    except HostError as e:
        result={'errorCode':e.code,'message':str(e),'replicaUnchanged':tuple(store.conn.iterdump())==before,'masterAudit':hosts[0].database(session).exec_sql_mult('SELECT kind,before_identity_json,after_identity_json FROM xlog_qso_audit ORDER BY sequence')}
        print(json.dumps(result,indent=2));(out/'country-reconcile-result.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
    for h in hosts:h.close()
