import {readFileSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
const original='/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/contesting/Not1MMContestWorkspace.test.tsx';
let text=readFileSync(original,'utf8').replace(/(["'])(\.{1,2}\/[^"']+)\1/g,(_all,quote,path)=>quote+resolve(dirname(original),path)+quote);
text=text.replace('from "@testing-library/user-event"','from "/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/node_modules/@testing-library/user-event/dist/esm/index.js"');
text+=String.raw`
it.each([true,false])('fresh fldigi uncertain Stop retains truthful recovery (uncertain=%s)',async uncertain=>{
 const current={...projection(),pluginID:'cq_ww_rtty',pluginName:'CQ WW RTTY',mode:'RTTY',supportedModes:['RTTY'],fldigiTransmitAvailable:true};
 const request=vi.fn(async(method:string,params:Record<string,unknown>={})=>{
  const support=workspaceSupport(method,params,current);if(support)return support;
  if(method==='contest_scp_status')return unavailableSCP();if(method==='contest_history_status')return unavailableHistory();
  const result=method==='contest_catalog'?{plugins:[{id:'cq_ww_rtty',name:'CQ WW RTTY',modes:['RTTY']}]}:
   method==='contest_sessions'?{sessions:[]}:method==='contest_create'?{projection:current}:method==='contest_log_page'?{rows:[],total:0}:method==='contest_score'?{score:current.score}:null;
  if(!result)throw Error(method);return{id:crypto.randomUUID(),ok:true,result};
 });
 const digital={configuration:{enabled:false,address:'224.0.0.1',port:42424,destination:'active_contest'},running:false,status:'Stopped',receive_only:true,contest_target_supported:true,active_contest:{session_id:current.sessionID,plugin_id:current.pluginID}};
 // Source-valid starting state after an earlier admitted macro: duty retained,
 // send finished, receive release has not yet been requested or failed.
 let fldigi={configuration:{receive_enabled:false,transmit_enabled:true},receive_supported:true,transmit_supported:true,receive_running:false,status:'Sent 1 fldigi macro.',udp_endpoint:'127.0.0.1:9876',xmlrpc_endpoint:'http://127.0.0.1:7362/RPC2',transmit_release_required:true,transmit_release_uncertain:false};
 const serviceRequest=vi.fn(async(method:string,params?:Record<string,unknown>)=>{
  if(method==='wsjtx_snapshot'||method==='wsjtx_stop')return digital;
  if(method==='fldigi_snapshot')return fldigi;
  if(method==='fldigi_stop'){fldigi={...fldigi,configuration:{receive_enabled:false,transmit_enabled:false},status:uncertain?'fldigi receive release is unconfirmed; use Stop to retry before transmitting.':'Off',transmit_release_required:uncertain,transmit_release_uncertain:uncertain};return fldigi;}
  return request(method,params);
 });
 render(<Not1MMContestWorkspace setupOnly request={request} serviceRequest={serviceRequest} {...workspaceProps}/>);
 await createContestThroughSetup();await userEvent.click(screen.getByRole('button',{name:'Productivity desk'}));
 await waitFor(()=>expect(surfaceOwner.current.projections['active-qso'].operator.outputAvailable).toBe(true));
 await act(async()=>{fireEvent.click(screen.getByRole('button',{name:'Stop',exact:true}));});
 const first={hasStop:!!screen.queryByRole('button',{name:'Stop',exact:true}),hasUncertainty:!!screen.queryByText(/receive release is unconfirmed/),operator:surfaceOwner.current.projections['active-qso'].operator};
 await act(async()=>{await setupDialogOwner.current.saveDigital({configuration:digital.configuration,fldigi_configuration:fldigi.configuration,action:'stop'});});
 const afterSnapshot={hasStop:!!screen.queryByRole('button',{name:'Stop',exact:true}),hasUncertainty:!!screen.queryByText(/receive release is unconfirmed/),operator:surfaceOwner.current.projections['active-qso'].operator};
 const stopCallsBefore=serviceRequest.mock.calls.filter(([method])=>method==='fldigi_stop').length;
 const entry=surfaceOwner.current.projections['active-qso'];
 await act(async()=>{await surfaceOwner.current.handle({operatingContext,sessionID:current.sessionID,workspaceGeneration,action:'entry_operator_key',params:{draftID:current.draftID,expectedDraftRevision:entry.draft.revision,key:'Escape',focusedField:'callsign'}});});
 console.log(JSON.stringify({uncertain,returned:fldigi,first,afterSnapshot,fldigiStopCallsBeforeSurfaceStop:stopCallsBefore,fldigiStopCallsAfterSurfaceStop:serviceRequest.mock.calls.filter(([method])=>method==='fldigi_stop').length,cwStops:nativeCW.stop.mock.calls.length}));
 expect(afterSnapshot.operator.status).toBe(uncertain?'uncertain':'disarmed');
});
`;
writeFileSync('/tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/frontend/fldigi-stop.test.tsx',text);
