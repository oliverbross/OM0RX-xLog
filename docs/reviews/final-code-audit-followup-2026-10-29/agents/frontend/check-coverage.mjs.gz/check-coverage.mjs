import {readFileSync} from 'node:fs';
const coverage=JSON.parse(readFileSync(new URL('./coverage.json',import.meta.url)));
for(const entry of coverage.entries){
 const lines=readFileSync(`/Users/oliver/Documents/Projects/OM0RX-xLog/${entry.path}`,'utf8').trimEnd().split('\n').length;
 for(const fn of entry.functions??[])for(const [start,end]of fn.ranges??[]){
  if(start<1||end>lines)console.log(JSON.stringify({path:entry.path,function:fn.name,start,end,lines}));
 }
}
console.log(JSON.stringify({validJSON:true,entries:coverage.entries.length}));
