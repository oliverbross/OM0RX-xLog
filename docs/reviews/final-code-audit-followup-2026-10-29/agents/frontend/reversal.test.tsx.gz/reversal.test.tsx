// @vitest-environment jsdom
import { useState } from 'react';
import { afterEach, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { QSOEditor } from '/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/QSOEditorCore';
import { DeskQSO } from '/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/OperatorDesk';
import { effectiveDraftAutomaticStart } from '/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/operatorDraftTimeIntent';
const initial = { id: 'fixture', call: 'K1ABC', start: '2026-10-20T10:15:30Z', end: null, band: '20m', mode: 'CW', frequencyHz: 14_025_000, rstSent: '599', rstReceived: '599', extraFields: {} };
afterEach(() => { cleanup(); vi.useRealTimers(); });
function Harness({full,save}:any) {
 const [draft,setDraft] = useState(initial);
 const automaticStart=effectiveDraftAutomaticStart({base:{revision:0,qso:initial,automaticStart:true},draft});
 const props={draft,setDraft,save,clear:vi.fn(),busy:false,automaticStart,lookup:null,previous:[],follow:false,setFollow:vi.fn(),request:vi.fn(async()=>({cells:[]})),refresh:0};
 return <><output aria-label="Effective automatic">{String(automaticStart)}</output>{full?<QSOEditor {...props} inspector={false} radioControls={false}/>:<DeskQSO {...props} radioControls={false}/>}</>;
}
it.each([true,false])('reversal restores automatic display as well as native intent full=%s',full=>{
 vi.useFakeTimers(); vi.setSystemTime(new Date('2026-10-28T12:34:56Z'));
 const save=vi.fn(); render(<Harness full={full} save={save}/>);
 const date=screen.getByLabelText(full?'Start UTC date':'Desk UTC date');
 const time=screen.getByLabelText(full?'Start UTC time':'Desk UTC time');
 fireEvent.change(date,{target:{value:'2026-10-21'}});
 fireEvent.change(time,{target:{value:'10:15:30'}});
 fireEvent.change(date,{target:{value:'2026-10-20'}});
 console.log(JSON.stringify({full,automatic:screen.getByLabelText('Effective automatic').textContent,date:(date as HTMLInputElement).value,time:(time as HTMLInputElement).value}));
 expect(screen.getByLabelText('Effective automatic').textContent).toBe('true');
 expect((date as HTMLInputElement).value).toBe('2026-10-28');
 expect((time as HTMLInputElement).value).toBe('12:34:56');
});
