from pathlib import Path
import hashlib,json
root=Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/radio')
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
d=json.loads((root/'coverage.json').read_text());rows=d['functions']+d['changed_tests']
failures=[]
for row in rows:
    lines=(repo/row['path']).read_text().splitlines();a,b=row['range']
    if not(1<=a<=row['body_open_line']<=b<=len(lines)):failures.append([row['path'],row['symbol'],'invalid source bounds'])
    if row['symbol'] not in lines[a-1]:failures.append([row['path'],row['symbol'],'declaration anchor does not match'])
    if '}' not in lines[b-1]:failures.append([row['path'],row['symbol'],'end does not close body'])
known={('Sources/XLogPrototypeSupport/LiveStationMethods.swift','init(agents:'):[44,51],('Sources/XLogPrototypeSupport/LiveOpportunitiesMethods.swift','init(logbook:'):[42,60],('Sources/XLogPrototypeSupport/LiveWorker.swift','static func resolve(onlineLogsRetired:'):[38,46],('Sources/XLogPrototypeSupport/LiveWorker.swift','public func response(to data:'):[437,814],('Sources/XLogPrototypeSupport/LiveStationSession.swift','func handle(_ method:'):[243,534]}
anchors=[]
for (path,symbol),expected in known.items():
    row=next(x for x in rows if x['path']==path and x['symbol']==symbol)
    anchors.append({'path':path,'symbol':symbol,'range':row['range'],'expected':expected})
    if row['range']!=expected:failures.append([path,symbol,'manual extent differs'])
for path,digest in d['source_sha256'].items():
    if hashlib.sha256((repo/path).read_bytes()).hexdigest()!=digest:failures.append([path,'source hash drift'])
result={'schema':1,'entries_validated':len(rows),'range_kind':'declaration-through-complete-body','locator':'signature-parenthesis-aware, skips comments and quoted strings; manually checked key complete body anchors','manual_anchors':anchors,'failures':failures,'source_hashes_current':not failures,'evidence_frozen_after_this_qa':True,'artifact_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['REVIEW.md','coverage.json','static-proofs.json','proof-source-binding.json','write_coverage.py','static_proofs.py','build_proofs.py']}}
(root/'coverage-qa.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
assert not failures
