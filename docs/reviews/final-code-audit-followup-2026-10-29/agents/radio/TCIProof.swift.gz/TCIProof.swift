import Foundation
private enum TCIFixtureError: Error { case closed }
private final class TCIClock: @unchecked Sendable {
    private let lock = NSLock(); private var value = Date(timeIntervalSince1970: 1000)
    func now() -> Date { lock.lock(); defer { lock.unlock() }; return value }
    func advance(_ seconds: TimeInterval) { lock.lock(); defer { lock.unlock() }; value.addTimeInterval(seconds) }
}
actor TCIFixtureSocket: TCIWebSocketConnection {
    private var messages: [TCIWebSocketMessage] = []
    private var waiter: CheckedContinuation<TCIWebSocketMessage, Error>?
    private var closes = 0, closed = false
    private var sent: [String] = []
    private let resumeOnClose: Bool
    init(resumeOnClose: Bool = true) { self.resumeOnClose = resumeOnClose }
    func receive() async throws -> TCIWebSocketMessage {
        if !messages.isEmpty { return messages.removeFirst() }
        if closed { throw TCIFixtureError.closed }
        return try await withCheckedThrowingContinuation { waiter = $0 }
    }
    func send(text: String) throws {
        guard !closed else { throw TCIFixtureError.closed }
        sent.append(text)
    }
    func enqueue(_ value: TCIWebSocketMessage) { if let waiter { self.waiter = nil; waiter.resume(returning: value) } else { messages.append(value) } }
    func fail() { closed = true; waiter?.resume(throwing: TCIFixtureError.closed); waiter = nil }
    func close() { closes += 1; closed = true; if resumeOnClose { waiter?.resume(throwing: TCIFixtureError.closed); waiter = nil } }
    func closeCount() -> Int { closes }
    func sentTexts() -> [String] { sent }
}
actor TCIFixtureConnector: TCIWebSocketConnecting {
    private var sockets: [TCIFixtureSocket], calls = 0
    init(_ sockets: [TCIFixtureSocket]) { self.sockets = sockets }
    func connect(to endpoint: URL) async throws -> any TCIWebSocketConnection { calls += 1; guard !sockets.isEmpty else { throw TCIFixtureError.closed }; return sockets.removeFirst() }
    func count() -> Int { calls }
}

@main struct Probe {
 static func main() async throws {
  let socket=TCIFixtureSocket(), time=TCIClock()
  let session=TCIReadOnlyWebSocketSession(endpoint:URL(string:"ws://127.0.0.1:40001")!,configuredAddress:TCIReceiverAddress(trx:0,channel:0),connector:TCIFixtureConnector([socket]),clock:{time.now()})
  try await session.connect()
  await socket.enqueue(.text("protocol:ExpertSDR3,1.8;device:SunSDR2PRO;receive_only:false;trx_count:2;channels_count:2;vfo_limits:0,160000000;if_limits:-156250,156250;modulations_list:AM,LSB,USB,CW;vfo:0,0,14025000;modulation:0,CW;trx:0,false;ready;"))
  while await session.currentObservation().availability != .available { await Task.yield() }
  let baseline=await session.currentObservation()
  let tune=Task {try await session.tuneReceive(frequencyHz:14025000,mode:"CW",expectedGeneration:baseline.generation,timeoutNanoseconds:500000000)}
  while await socket.sentTexts().isEmpty {await Task.yield()}
  time.advance(1)
  await socket.enqueue(.text("ready;"))
  let result=try await tune.value
  print("same_target_ready_only_confirmed=\(result.sequence > baseline.sequence) frequency=\(result.snapshot!.frequencyHz) frames=\(await socket.sentTexts())")
  await session.disconnect()
 }
}
