
import Foundation
enum RemoteStationAction:Sendable {case tune,cancel,standby,operate}
struct StationTransmitOwnership {
    enum Release: Equatable { case clearCW, cancelTune, releasePTT }
    private var ptt = false
    private var cw = false
    private var tune = false

    mutating func beginControl(_ control: String, enabled: Bool = false) {
        if control == "ptt", enabled { ptt = true }
        if control == "send_cw" { cw = true }
    }

    mutating func completeControl(_ control: String, enabled: Bool = false) {
        if control == "ptt", !enabled { ptt = false }
        if control == "clear_cw" { cw = false }
    }

    mutating func beginAction(_ action: RemoteStationAction) {
        if action == .tune { tune = true }
    }

    mutating func completeAction(_ action: RemoteStationAction, acquisitionsInFlight: Bool = false) {
        // A Cancel acknowledgement cannot retire the obligation of an older
        // HTTP acquisition whose reply is still outstanding. Its wire outcome
        // is unknown; keep explicit release available after it finishes.
        if action == .cancel && acquisitionsInFlight { return }
        if action == .cancel { tune = false }
    }

    var releases: [Release] {
        (cw ? [.clearCW] : []) + (tune ? [.cancelTune] : [])
            + (ptt || cw || tune ? [.releasePTT] : [])
    }
}
struct StationGUIPTT {var ownerID:UUID?}
actor RemoteAgentClient {
 var attempts=0; var stopped=false
 func shutdownClearCW() throws {attempts += 1;throw NSError(domain:"fake",code:1)}
 func shutdownCancelTune() throws {attempts += 1;throw NSError(domain:"fake",code:1)}
 func shutdownReleasePTT() throws {attempts += 1;throw NSError(domain:"fake",code:1)}
 func stop(){stopped=true}
 func counts()->(Int,Bool){(attempts,stopped)}
}
final class NativeDraftPowerGate: @unchecked Sendable {}
actor StationProviderClaim {}
actor LiveFlexSession {func terminate()->StationOwnerRetirement{.retired}}
actor LiveTCISession {init(claim:StationProviderClaim){};func terminate(){}}
actor LiveStationSession {
 let fake:RemoteAgentClient
 var transmitOwnership=StationTransmitOwnership()
 var guiPTT=StationGUIPTT();var embeddedCATPTT=false
 init(radioID:String){fake=RemoteAgentClient();transmitOwnership.beginControl("ptt",enabled:true)}
 func installPowerCapture(_ capture:NativeDraftPowerGate){}
 func terminate()async {await stop(fake)}
 func dutyCount()->Int{transmitOwnership.releases.count}
private func stop(_ current: RemoteAgentClient) async {
        var releases = transmitOwnership.releases
        if guiPTT.ownerID != nil && !releases.contains(.releasePTT) {releases.append(.releasePTT)}
        guiPTT = StationGUIPTT()
        embeddedCATPTT = false
        transmitOwnership = StationTransmitOwnership()
        // Attempt every owned release immediately: a stalled CW/cancel reply
        // must not delay PTT-off. The desktop bounds graceful EOF to eight
        // seconds; crashes or missing acknowledgments cannot confirm RF safety.
        await withTaskGroup(of: Void.self) { group in
            for release in releases {
                group.addTask {
                    switch release {
                    case .clearCW: try? await current.shutdownClearCW()
                    case .cancelTune: try? await current.shutdownCancelTune()
                    case .releasePTT: try? await current.shutdownReleasePTT()
                    }
                }
            }
        }
        await current.stop()
    }
}
struct StationRetirementResult: Sendable, Equatable {
    let unconfirmedRadioIDs: Set<String>
}

enum StationOwnerRetirement: Sendable, Equatable { case retired, unconfirmed }

struct StationRadioRegistry: Sendable {
    static let shared = StationRadioRegistry()
    #if os(macOS)
    let claims: [String: StationProviderClaim]
    let agents: [String: LiveStationSession]
    let flex: [String: LiveFlexSession]
    let tci: [String: LiveTCISession]

    init(agents: [String: LiveStationSession]? = nil, flex: [String: LiveFlexSession]? = nil,
         tciFactory: @Sendable (StationProviderClaim) -> LiveTCISession = { LiveTCISession(claim: $0) }) {
        let claims = ["radio1": StationProviderClaim(), "radio2": StationProviderClaim()]
        self.claims = claims
        self.agents = agents ?? ["radio1": LiveStationSession(radioID: "radio1"), "radio2": LiveStationSession(radioID: "radio2")]
        self.flex = flex ?? ["radio1": LiveFlexSession(), "radio2": LiveFlexSession()]
        self.tci = claims.mapValues(tciFactory)
    }

    func installPowerCapture(_ capture: NativeDraftPowerGate) async {
        for owner in agents.values { await owner.installPowerCapture(capture) }
    }

    func terminate() async -> StationRetirementResult {
        await withTaskGroup(of: (String, StationOwnerRetirement).self) { group in
            for (id, owner) in agents { group.addTask { await owner.terminate(); return (id, .retired) } }
            for (id, owner) in flex { group.addTask { (id, await owner.terminate()) } }
            for (id, owner) in tci { group.addTask { await owner.terminate(); return (id, .retired) } }
            var unconfirmed = Set<String>()
            for await (id, outcome) in group where outcome == .unconfirmed { unconfirmed.insert(id) }
            return StationRetirementResult(unconfirmedRadioIDs: unconfirmed)
        }
    }
    #endif
}


@main struct AgentProbe {
 static func main() async {
  let agent=LiveStationSession(radioID:"radio1")
  let registry=StationRadioRegistry(agents:["radio1":agent])
  let result=await registry.terminate()
  let counts=await agent.fake.counts()
  print("agent_release_attempts=\(counts.0) all_throw=true transport_stopped=\(counts.1) remaining_duties=\(await agent.dutyCount()) unconfirmed_radios=\(result.unconfirmedRadioIDs.count)")
 }
}
