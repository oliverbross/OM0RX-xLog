from pathlib import Path
import json,hashlib,subprocess
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog');out=Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/radio')
def current(path):return (repo/path).read_text()
def old(path):return subprocess.check_output(['git','show','530de4c4:'+path],cwd=repo,text=True)
def function(text,marker):
    start=text.index(marker); opening=text.index('{',start);end=opening+1;level=1
    while level:level+=(text[end]=='{')-(text[end]=='}');end+=1
    return text[start:end]
agent='Sources/XLogPrototypeSupport/LiveStationSession.swift'
worker='Sources/XLogPrototypeSupport/LiveWorker.swift'
entry='Sources/XLogPrototypeWorker/main.swift'
fldigi='Sources/XLogPrototypeSupport/LiveFldigiBridge.swift'
now=current(agent);base=old(agent)
install=function(now,'func installPowerCapture');stop=function(now,'private func stop(_ current:')
assert install==function(base,'func installPowerCapture')
assert stop==function(base,'private func stop(_ current:')
assert 'powerCapture = capture' in install and 'attach(' not in install
assert 'let capture = powerCapture' in now and 'capture?.observe(' in now
assert function(current(worker),'public func startBackgroundServices()')==function(old(worker),'public func startBackgroundServices()')
assert current(entry)==old(entry)
stop_branch=current(fldigi).split('case "fldigi_stop":',1)[1].split('case "fldigi_send":',1)[0]
old_branch=old(fldigi).split('case "fldigi_stop":',1)[1].split('case "fldigi_send":',1)[0]
assert stop_branch.replace('returnToReceive(emergency: true)','returnToReceive()')==old_branch
assert stop_branch.index('try save(next)')<stop_branch.index('returnToReceive(emergency: true)')
result={'schema':1,'kind':'source assertions only; no runtime proof','entry':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'comparand':'530de4c4','checks':{'install_power_capture_body_unchanged':True,'stop_agent_body_unchanged':True,'background_startup_body_unchanged':True,'worker_entry_file_unchanged':True,'fldigi_stop_branch_unchanged_except_explicit_emergency_argument':True,'fldigi_save_precedes_release':True},'actual_source_sha256':{p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in [agent,worker,entry,fldigi]}}
(out/'static-proofs.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['checks']))
