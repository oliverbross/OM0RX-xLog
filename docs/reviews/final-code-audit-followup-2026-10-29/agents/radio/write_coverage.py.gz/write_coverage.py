from pathlib import Path
import hashlib,json,re,subprocess
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out=Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/radio')
rows=[]
def code_chars(text,start):
    # Source-range locator, not a compiler: ignore comments and quoted strings;
    # count signature parentheses so default closure bodies are not mistaken
    # for the function body. Preserve the real source byte/line coordinates.
    i=start
    while i<len(text):
        if text.startswith('//',i):
            end=text.find('\n',i);i=len(text) if end<0 else end;continue
        if text.startswith('/*',i):
            depth=1;i+=2
            while depth and i<len(text):
                if text.startswith('/*',i):depth+=1;i+=2
                elif text.startswith('*/',i):depth-=1;i+=2
                else:i+=1
            continue
        if text[i]=='"':
            triple=text.startswith('"""',i);quote='"""' if triple else '"';i+=len(quote)
            while i<len(text):
                if text[i]=='\\':i+=2;continue
                if text.startswith(quote,i):i+=len(quote);break
                i+=1
            continue
        yield i,text[i];i+=1
def extent(text,start):
    parens=0;opening=None;level=0
    for i,ch in code_chars(text,start):
        if opening is None:
            if ch=='(':parens+=1
            elif ch==')':parens-=1
            elif ch=='{' and parens==0:opening=i;level=1
        else:
            level+=(ch=='{')-(ch=='}')
            if level==0:return opening,i+1
    raise ValueError('unterminated function body')
def add(file, markers, callers, tests, assessment, changed=True):
    text=(repo/file).read_text()
    for marker in markers:
        if marker not in text:
            raise ValueError(f'{file}: missing {marker}')
        start=text.index(marker);opening,end=extent(text,start)
        rows.append(dict(path=file,symbol=marker.split('\n')[0],range=[text.count('\n',0,start)+1,text.count('\n',0,end)+1],range_kind='declaration-through-complete-body',body_open_line=text.count('\n',0,opening)+1,changed=changed,callers=callers,tests=tests,assessment=assessment))
p='Sources/XLogPrototypeSupport/'
add(p+'LiveStationMethods.swift',['init(agents:','func installPowerCapture(_ capture:','func terminate() async -> StationRetirementResult'],['LiveWorker.init:285','LiveWorker.startPowerCapture:379','LiveWorker.shutdownOutcome:426','LiveStationMethods.handle:133-255'],['StationRadioRegistryTests.swift:8-168'],'Correct routed registry ownership; agent failures unconditionally mapped retired; startup install not a barrier.')
add(p+'LiveStationMethods.swift',['static func cwFlexCapabilities','static func cwFlexRevokeHandoffs','static func cwFlexHandoff','static func cwStartFlex','static func cwStopFlex','static func cwFlexCapture','static func cwTCICapabilities','static func cwStartTCI','static func cwStopTCI','static func cwTCICapture','static func handle(_ method:'],['LiveWorker.response:527,759','LiveCWDecodeMethods IQ provider callbacks'],['StationRadioRegistryTests.swift:8-168','LiveTCISessionTests.swift:90-102'],'Helpers route shared production registry; direct injected worker router uses its exact registry; per-slot claims retained; terminal/profile paths checked.')
add(p+'LiveStationSession.swift',['func handle(_ method:','func shutdown() async'],['LiveStationMethods.handle:169-255','LiveStationSession.terminate:577-580'],['StationRadioRegistryTests.swift:8-31,84-105'],'Changed attach/detach use radioID; connect captures optional gate before callbacks; reconnect does not recreate client.')
add(p+'LiveStationSession.swift',['func installPowerCapture','private func recordState','private func reconcilePowerObservationSession','private func stop(_ current:','func terminate() async'],['LiveStationMethods.installPowerCapture:53-55','LiveStationSession.handle/connect:315-344','LiveStationSession.shutdown:599'],['StationRadioRegistryTests.swift:8-31','AgentProof.swift compile-only unusable stale binary'],'Unchanged interactions independently traced; late registration cannot attach source; all release failures swallowed and ownership cleared.',False)
add(p+'LiveFlexSession.swift',['func handle(_ method:','@discardableResult func terminate()'],['LiveStationMethods.handle:177-197','StationRadioRegistry.terminate:60'],['StationRadioRegistryTests.swift:52-82,107-168'],'FLEX failure propagated; terminal exact disconnect-only recovery; new acquisition sealed.')
add(p+'LiveFlexSession.swift',['private func disconnect()','private func retireCurrent()','private func releaseOwned('],['LiveFlexSession.terminate:189','LiveFlexSession.handle:124,134'],['StationRadioRegistryTests.swift:107-155'],'Retains failed owned duty/radio; off observation required; busy activeControl/release barrier retained.',False)
add(p+'LiveWorker.swift',['static func resolve(onlineLogsRetired:','init(logbook:','func startPowerCapture(','public func shutdownOutcome()','public func response(to data:'],['XLogPrototypeWorker/main.swift:101-119,158-167','LiveWorker.startBackgroundServices:342'],['StationRadioRegistryTests.swift:8-168','NativePowerSelectionTests.swift:7-131','NativeDraftPowerCaptureTests.swift:39-205'],'Registry injection and structured FLEX error checked; terminal recovery profile gate retained; native active authority and per-slot metadata validated; startup race remains.')
add(p+'LiveWorker.swift',['public func startBackgroundServices()','func beginTerminalShutdown()','func reconcilePower()','func capturePower('],['XLogPrototypeWorker/main.swift:106,162','LiveWorker.startPowerCapture:376-381','LiveWorker.response Save drain:628-634'],['NativeDraftPowerAdmissionTests.swift:40-312','NativeDraftPowerCaptureTests.swift:39-205'],'Background startup is unawaited; gate callbacks serialized, DB authorization rechecked without holding source lock over DB waiting.',False)
add(p+'NativeDraftPowerGate.swift',['func select(','@discardableResult func activate(','func attach(','func connection(','func detach('],['LiveWorker.response:588-619','LiveStationSession.handle:320,334,343','LiveStationSession.shutdown:586'],['StationRadioRegistryTests.swift:84-105','NativePowerSelectionTests.swift:23-80','NativeDraftPowerCaptureTests.swift:143-179'],'Per-slot metadata/sources and separate active generation fence; inactive metadata cannot replace active meter; old source callbacks rejected.')
add(p+'NativeDraftPowerGate.swift',['func state()','func arm(','func observe(','func permits(','func recordCaptured(','func enqueue(','func drain()'],['LiveWorker.LogbookLane:91-132','LiveWorker.response:630'],['NativeDraftPowerAdmissionTests.swift:129-312','NativeDraftPowerCaptureTests.swift:143-179'],'Unchanged gate/DB/FIFO safeguards checked for changed routing interactions; no numeric cross-slot corruption path found.',False)
add(p+'LiveFldigiBridge.swift',['public func handle(method:','private func returnToReceive(','private func snapshot('],['LiveWorker.response:776-792','LiveFldigiBridge.stopForShutdown:127-130','LiveFldigiBridge.suspendForWorkspaceChange:132-138'],['LiveFldigiBridgeTests.swift:39-319'],'Automatic cleanup duty and overlap policy correct; completed send followed by explicit Stop storage failure skips RX; all actions prevalidated.')
add(p+'LiveFldigiBridge.swift',['public func stopForShutdown()','public func suspendForWorkspaceChange()','private func load()','private func save(_ value:'],['LiveWorker.shutdownOutcome:400','LiveWorker.response/workspace:650','LiveFldigiBridge.handle/stop:207-209'],['LiveFldigiBridgeTests.swift:39-319'],'Unchanged caller/storage interactions inspected; lifecycle cleanup bypasses save; explicit Stop does not. load cached; do not claim JSON corruption trigger.',False)
add(p+'LiveTCISession.swift',['func handle(_ method:','func terminate() async','private func disconnect()','private func record(','private func snapshot()'],['LiveStationMethods.handle:165-166','StationRadioRegistry.terminate:61'],['LiveTCISessionTests.swift:8-36,104-149,186-212','StationRadioRegistryTests.swift:34-50'],'Receive-only lifecycle; generation and exact identity before recording results; no new defect established.',False)
add('Sources/XCatIntegrationCore/TCIWebSocketSession.swift',['private func receiveCommand(','private static func waitForTuneReadback(','private func process(','private func isConfiguredEvidence('],['LiveTCISession.handle/station_tune:93-106','TCIReadOnlyWebSocketSession.tuneReceive:414-422'],['LiveTCISessionTests.swift:104-149','TCIProof.swift compile-only (execution blocked)'],'READY-only same-target evidence hypothesis; real protocol trigger/consequence unverified; reconnect failure/generation safeguards remain.',False)
r='prototype/src-tauri/src/'
add(r+'radio_slots.rs',['pub(crate) fn request(&self)','fn admit_tx_route(','fn load(','fn routing_owner(','fn with_routing','pub fn active(','pub(crate) fn prepare_power_authority','pub(crate) fn bind_power_authority','fn stamp_power_authority','fn set_active_on(','pub(crate) fn set_active(','pub fn claim_active_tx(','pub fn claim_tx(','fn claim_tx_lease('],['main.rs:2216-2235,2271','station_selection.rs:853-855,878-911','hamlib.rs reconnect claim_tx'],['radio_slots.rs:284-400'],'Native route fence before durable change; no lock over publication IPC; routing→TX order consistent; Hamlib reacquisition shares fence; failed final publication retryable.')
add(r+'station_selection.rs',['pub(crate) fn worker_generation_started(','pub fn owner_for('],['worker.rs:announce_session:metadata bootstrap','main.rs:2075-2085,2245,2264'],['radio_slots.rs:290-302','NativePowerSelectionTests.swift:23-80'],'Initialize routing before selection transport; stamp ordinary and exact-child bootstrap notices; no RPC while worker registry lock held.')
add(r+'station_selection.rs',['fn allocate_notice(','fn send_power(','fn finish_power(','fn bootstrap_worker(','pub fn initialize(','fn exclusive_tune<'],['station_selection.rs:853-864,878-921','main.rs:2264-2302'],['Existing per-slot selection tests; radio_slots stamp tests'],'Unchanged notice sequence/coalescing/identity and active-control locks challenged against new authority; delayed notices cannot restore stale active generation.',False)
add(r+'main.rs',['async fn station_session_request('],['Tauri command station_session_request','station_session::owner_for/apply'],['main.rs:5015-5034','radio_slots.rs:306-368'],'Changed set_active branch inspected with surrounding role/runtime/module/TX and event invalidation gates; no profile bypass found.')
add(r+'worker.rs',['fn worker_retirement_exit_message('],['Session.shutdown_result_with_grace:695','worker::shutdown_for_module_transition:1035-1043'],['worker.rs:2629-2639'],'Exit74 surfaced distinctly; child fixture mapping does not test production Swift emission.')
add(r+'worker.rs',['pub fn validate_surface('],['main.rs worker_request native admission'],['worker.rs:1606-1620,1913-1925'],'Narrow detached duplicate whitelist amendment inspected; detailed frontend behavior owned by parent/frontend review.')
add(r+'worker.rs',['fn shutdown_result_with_grace(','pub fn shutdown_for_module_transition()','fn session_from_registry('],['main.rs module/quit retirement','worker.rs existing_session/active_session'],['worker.rs:2592-2675'],'Unchanged native EOF failure propagation, pending reply drain, watchdog, announcement barrier examined. Ordinary shutdown ignores Result by design; module transition propagates.',False)
add('Sources/XCWCore/CWComputeWire.swift',['private static func number(','private static func boolean(','private static func isJSONBoolean(','static func isFoundationBoolean('],['CWComputeWire.event:111-147','CWComputeProcess.consume:160'],['CWComputeWirePrimitiveTests.swift:10-53'],'CoreFoundation primary boolean distinction retained; canonical singleton-identity fallback rejects boxed numeric truthiness; source reviewed, no platform execution.')
add(p+'LiveOpportunitiesMethods.swift',['init(logbook:'],['LiveWorker.init opportunities owner','LiveOpportunitiesMethods.snapshot:170'],['LiveOpportunitiesMethodsTests.swift:15-29'],'Moves default async actor callback construction inside actor init; retained cluster read only currentSpotRowsIfStarted:552-555, never connects.')
tests=[]
def test(file,markers,assessment):
    before=len(rows);add(file,markers,['Production functions identified in assessment'],[],assessment)
    tests.extend(rows[before:]);del rows[before:]
test('Tests/XLogPrototypeTests/StationRadioRegistryTests.swift',[
'func testWorkerRegistersBothRoutedAgentsAndRetiresEverySlotWithoutGlobalServices','func testWorkerRetiresConnectedTCIWithoutSendingReceiveOrTransmitControls','func testWorkerReleasesOwnedFlexTuneButOnlyStopsPassiveSlotTransport','func testPowerSourcesRemainBoundToTheirSelectedRadioAcrossOtherSlotReconnectAndDetach','func testUnconfirmedFlexRetirementBlocksRestartAndAllowsOnlyReleaseRecovery','func testTerminalReleaseRecoveryDoesNotBypassTestProfileIODenial'],
'Actual worker/router/registry with injected or passive owners; no native subprocess EOF. Explicitly awaited startup hides registration race; no failing agent client. FLEX missing off and profile denial useful.')
test('Tests/XLogPrototypeTests/LiveFldigiBridgeTests.swift',[
'func call(method:','func testAutomaticLifecycleNeverControlsUnownedFldigi','func testOwnedLifecycleReleasesOnceAndUncertainReleaseBlocksNewOutputUntilExplicitStop','func testAutomaticShutdownRetainsPendingTXDutyUntilLateAttemptRetires','func testExplicitEmergencyStopStillSendsRXWithoutPriorTransmitDuty','func testWorkspaceRetirementDuringPendingTextCannotStartTheNextAction','func testInvalidLaterActionNeverPartiallyTransmitsTheBundle','func setTextGateForTesting'],
'Fake RPC records before waiting; one continuation enough because sendInFlight serializes sends, RX unheld. Matrix covers unowned/ownership/TX-text retirement/late release/prevalidate. Writable storage everywhere; no RX state proof.')
test('Tests/XLogPrototypeTests/NativePowerSelectionTests.swift',['private func send(','private func activate(','func independentActiveAuthority()','func invalidActiveAuthority()'],
'Actual worker response and gate; synthetic source callbacks; stale/conflicting/malformed/idempotent generations and inactive metadata covered; no Rust IPC or startup connection callback.')
test('Tests/XLogPrototypeTests/NativeDraftPowerCaptureTests.swift',['private func fixture','func activeRadioCapture()','func lifecycle()'],
'Actual DB and worker lane with manually attached sources; active route commit and save covered; fixture starts capture before synthetic sources, so no registration schedule coverage.')
test('Tests/XLogPrototypeTests/NativeDraftPowerAdmissionTests.swift',['private func fixture('],
'Only change activates explicit native route in existing contention/durable peak fixture; meaningful tests keep DB/service waits outside source lock, synthetic source.')
test('Tests/XCWCoreTests/CWComputeWirePrimitiveTests.swift',['func testFoundationFallbackSeparatesJSONBooleansAndBoxedNumbers','func testReadyNumericFieldsNeverAcceptBooleanOrStringCoercion','func testTrackBooleanFieldsNeverAcceptNumericTruthiness'],
'Direct fallback checks JSON bool vs boxed numbers and parser coercion negatives; no claim target no-CoreFoundation runtime was tested here.')
test('Tests/XLogPrototypeTests/LiveOpportunitiesMethodsTests.swift',['func defaultClusterProjection()'],
'Uses default retained cluster callback and actual private logbook; verifies output flags and terminal rejection; no injected default closure/no transport start.')
test('Tests/XLogPrototypeTests/LiveClusterMethodsTests.swift',['func recordCleanup(cutoff:','func cutoffSnapshot()','func portablePriorCleanupUsesFirstAdmissionClock()'],
'Portable replacement validates first-admission cutoff and exactly one cleanup. macOS branch asserts forwarding; nonmacOS deliberately expects zero backend acceptance despite injected callbacks. macOS durable inventory tests remain cfg-gated; portable pass is not native inventory proof.')
for file,marker in [(r+'radio_slots.rs','fn fixture(path:'),(r+'radio_slots.rs','fn ordinary_and_bootstrap_metadata_keep_their_slot_under_native_active_authority'),(r+'radio_slots.rs','fn active_power_is_fenced_before_persist_and_published_even_without_metadata_changes'),(r+'radio_slots.rs','fn rejected_fence_preserves_route_and_advances_restoration_generation'),(r+'radio_slots.rs','fn failed_persistence_restores_old_authority_and_failed_final_reply_is_retryable'),(r+'radio_slots.rs','fn owned_transmit_vetoes_active_power_change_before_any_publication'),(r+'worker.rs','fn shutdown_reports_spot_retirement_failure_instead_of_a_deadline')]:
    test(file,[marker],'Injected function closures/isolated files or synthetic child exit74; meaningful policy test, not whole production call-chain execution.')
files=sorted(set(x['path'] for x in rows+tests))
data=dict(schema=1,review='fresh Phase6 radio/native lifecycle',entry='0375a8e1a385252519a99127fe9d8f40d639365a',application='f3f6e3d',comparison='530de4c4',functions=rows,changed_tests=tests,
test_only_visibility_changes=[dict(path='Tests/XLogPrototypeTests/LiveTCISessionTests.swift',range=[378,404],change='TCIFixtureSocket and TCIFixtureConnector private removed for registry test reuse; no assertions changed')],
original_verdicts={'CR-002':'original owner root repaired; startup capture remains incomplete','CR-003':'unowned automatic RX repaired; explicit Stop storage ordering remains','CR-010':'label source repaired, frontend four cases inspected not rerun','FA-004':'explicit active authority root repaired; no surviving wrong-meter path found','FA-005':'specific FLEX failure/recovery root repaired; direct-agent uncertainty remains'},
findings=['R6-RADIO-003','R6-RADIO-001','R6-RADIO-002'],finding_severity={'R6-RADIO-003':'High','R6-RADIO-001':'Medium','R6-RADIO-002':'Medium'},supplementary_caller_ranges=[{'path':'prototype/src/contesting/Not1MMContestWorkspace.tsx','ranges':[[2335,2341],[3794,3800]],'assessment':'Explicit visible operator/configuration Stop calls fldigi_stop with no compensating RX fallback'}],unverified=['TCI same-target READY synthetic confirmation hypothesis; no protocol reachability or wrong target consequence established'],
execution={'repository_tests_run':False,'scratch_tci_compiled':True,'scratch_tci_run':False,'scratch_tci_execution':'Explicit lean-ctx allowlist block; not retried or bypassed','scratch_agent_compiled_prior_revision':True,'scratch_agent_binary':'STALE AND UNUSABLE after neighbor fake correction','scratch_agent_run':False,'hardware_or_network_io':False,'gui_launch':False},
limits=['Source and test review primary; compiler success is not runtime acceptance','Agent fixture uses exact stop/registry but neighboring lifecycle/client stubs; no dynamic result','No source/test/config/Git mutations','Parent owns build/provenance and complete archive criteria; sibling frontend/persistence coverage not claimed'],
source_sha256={f:hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in files})
(out/'coverage.json').write_text(json.dumps(data,indent=2)+'\n')
report=out/'REVIEW.md';s=report.read_text().replace('LiveStationMethods.swift:60`; unchanged producer','LiveStationMethods.swift:59`; unchanged producer').replace('`LiveStationMethods.swift:60`), so','`LiveStationMethods.swift:59`), so').replace('(`LiveFldigiBridgeTests.swift:111–118`)','(`LiveFldigiBridgeTests.swift:112–119`)')
first=s.index('### R6-RADIO-001');second=s.index('### R6-RADIO-002');third=s.index('### R6-RADIO-003');end=s.index('## Original findings')
if first<second<third:s=s[:first]+s[third:end]+s[first:second]+s[second:third]+s[end:]
report.write_text(s)
print(json.dumps({'function_entries':len(rows),'changed_test_entries':len(tests),'source_files':len(files),'report':str(report),'coverage':str(out/'coverage.json')}))
