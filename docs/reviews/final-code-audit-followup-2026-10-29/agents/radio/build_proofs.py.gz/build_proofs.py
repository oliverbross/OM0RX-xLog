from pathlib import Path
import hashlib,json,subprocess
repo=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out=Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/radio')
out.mkdir(parents=True,exist_ok=True)
def body(path,name):
    text=(repo/path).read_text(); start=text.index(name); opening=text.index('{',start); level=1; end=opening+1
    while level:
        level+=(text[end]=='{')-(text[end]=='}');end+=1
    return text[start:end]
files=['TCIProtocol.swift','TCIIQFrame.swift','TCIIQSubscription.swift','TCIWebSocketSession.swift']
receipt={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_files':{}}
for name in files:
    src=repo/'Sources/XCatIntegrationCore'/name
    (out/name).write_bytes(src.read_bytes())
    receipt['source_files'][str(src.relative_to(repo))]=hashlib.sha256(src.read_bytes()).hexdigest()
test=(repo/'Tests/XLogPrototypeTests/LiveTCISessionTests.swift').read_text()
fixture=test[test.index('private enum TCIFixtureError:'):test.index('private actor TCIHeldConnector:')]
main='''
@main struct Probe {
 static func main() async throws {
  let socket=TCIFixtureSocket(), time=TCIClock()
  let session=TCIReadOnlyWebSocketSession(endpoint:URL(string:"ws://127.0.0.1:40001")!,configuredAddress:TCIReceiverAddress(trx:0,channel:0),connector:TCIFixtureConnector([socket]),clock:{time.now()})
  try await session.connect()
  await socket.enqueue(.text("protocol:ExpertSDR3,1.8;device:SunSDR2PRO;receive_only:false;trx_count:2;channels_count:2;vfo_limits:0,160000000;if_limits:-156250,156250;modulations_list:AM,LSB,USB,CW;vfo:0,0,14025000;modulation:0,CW;trx:0,false;ready;"))
  while await session.currentObservation().availability != .available { await Task.yield() }
  let baseline=await session.currentObservation()
  let tune=Task {try await session.tuneReceive(frequencyHz:14025000,mode:"CW",expectedGeneration:baseline.generation,timeoutNanoseconds:500000000)}
  while await socket.sentTexts().isEmpty {await Task.yield()}
  time.advance(1)
  await socket.enqueue(.text("ready;"))
  let result=try await tune.value
  print("same_target_ready_only_confirmed=\\(result.sequence > baseline.sequence) frequency=\\(result.snapshot!.frequencyHz) frames=\\(await socket.sentTexts())")
  await session.disconnect()
 }
}
'''
(out/'TCIProof.swift').write_text('import Foundation\n'+fixture+main)
stop=body('Sources/XLogPrototypeSupport/LiveStationSession.swift','private func stop(_ current: RemoteAgentClient) async')
registry=(repo/'Sources/XLogPrototypeSupport/LiveStationMethods.swift').read_text()
registry=registry[registry.index('struct StationRetirementResult:'):registry.index('/// The Mac worker')]
# Compile the exact failure-erasing production stop and exact registry aggregate
# with fake release methods and lifecycle neighbors. No transport is constructed.
ownership=body('Sources/XLogPrototypeSupport/LiveStationSession.swift','struct StationTransmitOwnership')
agent='''
import Foundation
enum RemoteStationAction:Sendable {case tune,cancel,standby,operate}
'''+ownership+'''
struct StationGUIPTT {var ownerID:UUID?}
actor RemoteAgentClient {
 var attempts=0; var stopped=false
 func shutdownClearCW() throws {attempts += 1;throw NSError(domain:"fake",code:1)}
 func shutdownCancelTune() throws {attempts += 1;throw NSError(domain:"fake",code:1)}
 func shutdownReleasePTT() throws {attempts += 1;throw NSError(domain:"fake",code:1)}
 func stop(){stopped=true}
 func counts()->(Int,Bool){(attempts,stopped)}
}
final class NativeDraftPowerGate: @unchecked Sendable {}
actor StationProviderClaim {}
actor LiveFlexSession {func terminate()->StationOwnerRetirement{.retired}}
actor LiveTCISession {init(claim:StationProviderClaim){};func terminate(){}}
actor LiveStationSession {
 let fake:RemoteAgentClient
 var transmitOwnership=StationTransmitOwnership()
 var guiPTT=StationGUIPTT();var embeddedCATPTT=false
 init(radioID:String){fake=RemoteAgentClient();transmitOwnership.beginControl("ptt",enabled:true)}
 func installPowerCapture(_ capture:NativeDraftPowerGate){}
 func terminate()async {await stop(fake)}
 func dutyCount()->Int{transmitOwnership.releases.count}
'''+stop+'\n}\n'+registry+'''
@main struct AgentProbe {
 static func main() async {
  let agent=LiveStationSession(radioID:"radio1")
  let registry=StationRadioRegistry(agents:["radio1":agent])
  let result=await registry.terminate()
  let counts=await agent.fake.counts()
  print("agent_release_attempts=\\(counts.0) all_throw=true transport_stopped=\\(counts.1) remaining_duties=\\(await agent.dutyCount()) unconfirmed_radios=\\(result.unconfirmedRadioIDs.count)")
 }
}
'''
(out/'AgentProof.swift').write_text(agent)
receipt['agent_proof_exact_bodies']=['StationTransmitOwnership','LiveStationSession.stop','StationRadioRegistry.terminate','StationRadioRegistry.init']
receipt['agent_proof_neighbors']='RemoteAgentClient throwing fake; lifecycle shell terminates by invoking exact stop; passive FLEX/TCI stubs; not a whole worker proof'
(out/'proof-source-binding.json').write_text(json.dumps(receipt,indent=2))
