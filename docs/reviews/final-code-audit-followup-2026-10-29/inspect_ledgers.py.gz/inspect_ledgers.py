import json,pathlib
ROOT=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
TASK=pathlib.Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1')
changed=json.loads((TASK/'all-remediation-paths.json').read_text())
for label in ['radio','frontend','data']:
    obj=json.loads((TASK/'agents'/label/'coverage.json').read_text())
    print(label,'schema',type(obj).__name__, 'keys',list(obj) if isinstance(obj,dict) else 'list')
    if isinstance(obj,dict):
        for key,value in obj.items():
            if isinstance(value,list):
                print(key,'count',len(value),'first',value[:1])
            elif isinstance(value,dict): print(key,'keys',list(value)[:15])
