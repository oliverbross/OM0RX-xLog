import hashlib,json,pathlib
ROOT=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
TASK=pathlib.Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1')
changed=json.loads((TASK/'all-remediation-paths.json').read_text())
owners={p:set() for p in changed}
records={}
for label in ['radio','frontend','data']:
    obj=json.loads((TASK/'agents'/label/'coverage.json').read_text()); records[label]=obj
    def walk(value):
        if isinstance(value,dict):
            path=value.get('path')
            if path in owners: owners[path].add(label)
            for child in value.values(): walk(child)
        elif isinstance(value,list):
            for child in value: walk(child)
    walk(obj)
root_paths={
 'Package.swift':('Manifest branch/source selection and product/dependency/runtime policy',[[1,178]]),
 '.github/workflows/contest-portability.yml':('Complete workflow, changed source filters, discovery assertions, OS loops and release boundaries',[[1,415]]),
 'Sources/XCWCore/CWComputeWire.swift':('number/integer/boolean/isJSONBoolean/isFoundationBoolean/event plus parser callers',[[1,197]]),
 'Tests/XCWCoreTests/CWComputeWirePrimitiveTests.swift':('All3primitive regression bodies and positive/negative oracles',[[1,64]]),
 'Sources/XLogPrototypeSupport/LiveOpportunitiesMethods.swift':('Changed initializer, retained cluster callback, snapshot, shutdown and cache boundaries',[[1,365]]),
 'Tests/XLogPrototypeTests/LiveOpportunitiesMethodsTests.swift':('Changed default-callback constructibility/terminal test and injected callback controls',[[1,180]]),
 'Tests/XLogPrototypeTests/LiveClusterMethodsTests.swift':('Changed helpers, macOS-only real-broker guards, portable first-admission regression and callers',[[32,116],[252,436],[642,782]]),
 'prototype/src-tauri/src/durable_file.rs':('Complete shared atomic publication/remove implementation and3regressions',[[1,110]]),
 'prototype/src-tauri/src/module_restart_intent.rs':('Complete publication/load/consume/decision/validation plus all tests; UI/main callers',[[1,213]]),
 'prototype/src-tauri/src/operating_module.rs':('Changed publication/commit behavior, owner fencing and regression oracles',[[190,340],[705,845]]),
 'prototype/scripts/relocate-contest-python.py':('Complete source/runtime path/provenance/linkage/CA/selftest and main dispatcher',[[1,372]]),
 'prototype/scripts/test-contest-python-relocation.py':('Complete12boundary test bodies, failure and mockedtool contracts',[[1,220]]),
 'prototype/scripts/accept-contesting-worker-process.mjs':('Complete artifact/source/profile/stream/timeout/restart/cleanup/reporting implementation',[[1,542]]),
 'tools/check_portable_iq_sources.py':('Complete manifest-slice fixture/source identity/test outcome implementation',[[1,75]]),
 'tools/check_reviewed_security_patches.py':('Complete narrowpatch policy/CLI and all callsites',[[1,56]]),
 'python/tests/test_reviewed_security_patches.py':('Complete7policy oracles, old/unknown/prerelease/duplicate edge cases',[[1,57]]),
 'prototype/package.json':('Complete Node/Vitest/build entrypoints, scripts and declared dependency lines',[[1,45]]),
 'prototype/package-lock.json':('Programmatic complete changed-package fields, native Rolldown binding alignment/integrities; no full advisory scan',[]),
 'prototype/src-tauri/Cargo.lock':('Programmatic complete changed versions/dependency edges and four patch floors; conditional platform risk retained',[]),
 'prototype/tests/fixtures/adx317.README.md':('Pinned fixture provenance and stated vocabulary-only scope; independently checked with data/frontend reviewers',[]),
 'prototype/tests/fixtures/adx317.xsd.gz':('Compressed byte identity and independent179-name RECORD vocabulary comparison, not fullscalar schema certification',[])
}
for path in root_paths:
    if path in owners: owners[path].add('root')
rows=[]
for path in changed:
    data=(ROOT/path).read_bytes()
    rows.append({'path':path,'sha256':hashlib.sha256(data).hexdigest(),'reviewers':sorted(owners[path]),
      'coverage':'changed bodies/declarations/oracles and associated callers in reviewer ledgers' if owners[path] else 'UNASSIGNED',
      'note':'No function in lockfiles/manifests/fixtures; policy/source/content assessment applies' if path.endswith(('.lock','.json','.gz','.md','.yml')) else ''})
(TASK/'changed-input-coverage.json').write_text(json.dumps(rows,indent=2)+'\n')
root_rows=[]
for p,(s,r) in root_paths.items():
    line_count=len((ROOT/p).read_text().splitlines()) if not p.endswith('.gz') else None
    checked=[[a,min(b,line_count)] for a,b in r if a<=line_count] if r else []
    root_rows.append({'path':p,'scope':s,'ranges':checked,'lineCount':line_count})
(TASK/'root-coverage.json').write_text(json.dumps(root_rows,indent=2)+'\n')
print('Changed inputs',len(rows),'assigned',sum(bool(r['reviewers']) for r in rows),'unassigned',[r['path'] for r in rows if not r['reviewers']])
