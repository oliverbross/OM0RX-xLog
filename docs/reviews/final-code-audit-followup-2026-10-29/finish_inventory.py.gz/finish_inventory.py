from pathlib import Path
import csv, datetime, hashlib, json, os, subprocess

ROOT = Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
TASK = Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

versions = {}
for command in [['uname','-srm'], ['swift','--version'], ['node','--version'], ['npm','--version'], ['/opt/homebrew/bin/python3.12','--version'], ['rustc','--version'], ['cargo','--version']]:
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=30)
    versions[' '.join(command)] = {'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    assert result.returncode == 0, versions
(TASK/'environment.json').write_text(json.dumps({'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'versions':versions},indent=2)+'\n')

manifest = json.loads((TASK/'source-sha256.json').read_text())
changed = [path for path,digest in manifest.items() if sha(ROOT/path)!=digest]
assert not changed, changed
historical = ['CODE_REVIEW.md','REMEDIATION_TRACKER.md','REGRESSION_TEST_REPORT.md','REVIEW_COVERAGE.md','STABILITY_REPORT.md']
reports = {}
for path in historical:
    before = subprocess.check_output(['git','show','0375a8e1:'+path],cwd=ROOT)
    reports[path] = {'sha256':sha(ROOT/path),'unchanged':before==(ROOT/path).read_bytes()}
assert all(value['unchanged'] for value in reports.values())
(TASK/'preservation-before-publication.json').write_text(json.dumps({'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceInputsChecked':len(manifest),'sourceChanges':changed,'historicalReports':reports},indent=2)+'\n')

paths=set()
def visit(value):
    if isinstance(value,dict):
        p=value.get('path')
        if isinstance(p,str) and (ROOT/p).is_file(): paths.add(p)
        for v in value.values(): visit(v)
    elif isinstance(value,list):
        for v in value: visit(v)
for reviewer in ['radio','frontend','data']:
    visit(json.loads((TASK/'agents'/reviewer/'coverage.json').read_text()))
visit(json.loads((TASK/'root-coverage.json').read_text()))
with (ROOT/'docs/reviews/full-code-review-verification-2026-10-29/REVIEW_INVENTORY.tsv').open() as f:
    inventory=list(csv.DictReader(f,delimiter='\t'))
print('inventory columns',list(inventory[0]))
print('reviewed path union',len(paths))
(TASK/'fresh-reviewed-paths.json').write_text(json.dumps(sorted(paths),indent=2)+'\n')
print(json.dumps(versions,indent=2))
print('preserved source inputs',len(manifest))
