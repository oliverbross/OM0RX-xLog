from pathlib import Path
import json,re,sys
P=Path('/tmp/xlog-phase5-20261029-721e0705')
R=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
sys.path.insert(0,str(P/'agent-reports'))
from collector_common import assert_gates,assert_head,source_snapshot
plan=json.loads((P/'final-validation-plan.json').read_text())
assert_head(plan);assert_gates(plan);source_snapshot(plan)
A=R/'docs/reviews/stability-2026-10-29'
results=json.loads((A/'results.json').read_text())
ci=json.loads((A/'ci/current/latest-status.json').read_text())
receipts={v['id']:v for v in results['finalGates']}
def secs(n):return str(receipts[n]['durationSeconds'])+' s'
table="""| Final current-source gate | Actual result |
| --- | --- |
| Complete frontend | PASS 4,731 Vitest /339 files +2 Node; """+secs('CLOSE-FRONTEND')+""" |
| Complete Python | PASS 556; """+secs('CLOSE-PYTHON')+""" |
| Native Swift | PASS 315 XCTest +Swift Testing summary340; """+secs('CLOSE-NATIVE')+""" |
| Portable Swift | PASS 1,174 XCTest +Swift Testing summary538; """+secs('CLOSE-PORTABLE')+""" |
| Locked Rust default | PASS 919 unit +26 integration functions; """+secs('CLOSE-RUST')+""" |
| Rust contesting feature | PASS 926; """+secs('CLOSE-RUST-FEATURE')+""" |
| Frontend build/static/budgets | PASS405,194/405,200 Logbook bytes; """+secs('CLOSE-FRONTEND-BUILD')+""" |
| Native release / complete Swift concurrency build | PASS; """+secs('CLOSE-NATIVE-BUILD')+' /'+secs('CLOSE-STRICT-BUILD')+""" |
| Locked Rust release / Clippy all targets | PASS with retained warnings; """+secs('CLOSE-RUST-RELEASE')+' /'+secs('CLOSE-CLIPPY')+""" |
| Fresh universal worker / framing / current process | PASS; """+secs('CLOSE-WORKER-BUILD')+' /'+secs('CLOSE-PROTOCOL')+' /'+secs('CLOSE-PROCESS')+""" |
| Idle unchanged CW child wire control | PASS13/13; """+secs('CLOSE-CW-WIRE-IDLE')+""" |
| Reviewed four patch floors / npm audit / Node packaging checks | PASS; npm0advisories; Node10cases |
"""
ci_lines=['### Exact-source CI outcome','','Frozen snapshot: **'+ci['observedUTC']+'**, source **'+ci['sourceHead']+'**. Each row retains its own actual conclusion.','','| Workflow / job | Actual outcome |','| --- | --- |']
for run in ci['runs']:
 ci_lines.append('| ['+run['name']+' '+str(run['id'])+']('+run['url']+') | '+run['status']+' /'+str(run['conclusion'])+' |')
 for job in run['jobs']:
  ci_lines.append('| ['+job['name']+' '+str(job['id'])+']('+job['url']+') | '+job['status']+' /'+str(job['conclusion'])+' |')
ci_lines+=['','The main Swift CI job has a fresh checkout without a build-cache step and passes test/package/resource checks. Contest portability verifies three Swift, three native and one generator/security job. Prototype push gates build a desktop executable; operator-release packaging is workflow_dispatch-only. No hosted package is designated as an installed operator release. Earlier exact failed-job and no-runner histories remain preserved. Any incomplete/failed row above remains a limit regardless of another workflow passing.']
ci_section='\n'.join(ci_lines)
summary='Archived '+str(results['commands'])+' command receipts; '+str(results['databaseChecks'])+' disposable databases pass read-only integrity/foreign-key checks; '+str(len(json.loads((A/'export-verification.json').read_text())))+' raw exports match their receipt byte counts/SHA.'
evidence='### Preservation and permanent evidence\n\n'+summary+' Original node_modules and CW fixtures are restored by inode, and all180original dist files match hashes. All1,829source inputs match the tested snapshot, and process-only inspection finds no remaining task test/worker process. Binary/runtime/database payloads are omitted from Git.\n\n[Evidence index](/Users/oliver/Documents/Projects/OM0RX-xLog/docs/reviews/stability-2026-10-29/README.md), [exact commands](/Users/oliver/Documents/Projects/OM0RX-xLog/docs/reviews/stability-2026-10-29/COMMANDS.md), [results](/Users/oliver/Documents/Projects/OM0RX-xLog/docs/reviews/stability-2026-10-29/results.json) and [SHA256SUMS](/Users/oliver/Documents/Projects/OM0RX-xLog/docs/reviews/stability-2026-10-29/SHA256SUMS) preserve the actual source, UTC timing, exits, raw failures, fixture boundaries and original-byte hashes. The closing independent archive verification must pass before the documentation commit.'
body=(P/'closing-report-template-draft.md').read_text()
for a,b in {'{{FINAL_TABLE}}':table,'{{CI_SECTION}}':ci_section,'{{FRONTEND_DISPOSITION}}':'The final complete unchanged idle suite passes all4,731tests/339files plus2Node tests in487.181s.','{{CW_DISPOSITION}}':'The exact unchanged idle control passes13/13 in14.239s using the already compiled current-source binary, after all other suites finish.','{{EVIDENCE_SECTION}}':evidence}.items():body=body.replace(a,b)
assert '{{' not in body
for a,b in {'/339':' / 339','+2 Node':'+ 2 Node','+Swift Testing summary340':'+ Swift Testing summary 340','+Swift Testing summary538':'+ Swift Testing summary 538','+26 integration':'+ 26 integration','PASS405':'PASS 405','PASS13':'PASS 13','npm0advisories':'npm 0 advisories','Node10cases':'Node 10 cases','all180original':'all 180 original','All1,829source':'All 1,829 source','all4,731tests/339files plus2Node tests in487.181s':'all 4,731 tests / 339 files plus 2 Node tests in 487.181 s','passes13/13 in14.239s':'passes 13/13 in 14.239 s'}.items():body=body.replace(a,b)
s=(R/'STABILITY_REPORT.md').read_text();assert '## Iteration 11 —' not in s;s+='\n'+body
(R/'STABILITY_REPORT.md').write_text(s)
t=(R/'REMEDIATION_TRACKER.md').read_text().replace('# Phase 3 defect remediation','# Defect remediation tracker',1).replace('**Current Phase 4 disposition','**Historical Phase 4 disposition',1)
lead='**Current Phase 5 disposition — 29 October 2026:** All twelve original findings, including CR-008\'s reopened clean build, are **Fixed and Verified** within the recorded source/fixture limits. All safely compatible confirmed Phase 4/5 repairs pass the final32current-source gates. Conditional Linux GLib remains **Blocked**; intermittent SCP input and overloaded timing investigations remain **Not Fixed**. Manual review and native/provider/hardware acceptance remain incomplete. Current source58da5d49 and actual results are in [STABILITY_REPORT.md](/Users/oliver/Documents/Projects/OM0RX-xLog/STABILITY_REPORT.md).\n\n'
lead=lead.replace('final32current-source','final 32 current-source').replace('source58da5d49','source 58da5d49')
t=t.replace('# Defect remediation tracker\n\n','# Defect remediation tracker\n\n'+lead,1)
old='- **Status:** Fixed but Unverified — clean build/integration acceptance reopened in Phase 4. Original manual-time preservation tests continue to pass; no reproduced return of the original time-loss defect.'
new='- **Status:** Fixed and Verified — Phase 5 closes the Phase 4 clean build/integration reopening under REG-P4-001. CLOSE-FRONTEND-BUILD passes405,194/405,200 bytes and CLOSE-FRONTEND passes4,731/339+2Node with the original timestamp/remount behavior intact. See the current Phase5section below.'
assert old in t;t=t.replace(old,new.replace('passes405','passes 405').replace('passes4,731/339+2Node','passes 4,731/339 +2 Node').replace('Phase5section','Phase 5 section'),1)
t+='\n'+(P/'tracker-complete-final-draft.md').read_text()+'\n'+ci_section+'\n\n'+summary+' Original fixtures/source were restored and checked before archive verification. All original historical-data/recovery/compatibility limits remain.\n'
(R/'REMEDIATION_TRACKER.md').write_text(t)
pointers={
 'CODE_REVIEW.md':'**Current Phase 5 update:** The twelve original findings are Fixed and Verified within their recorded limits; CR-008\'s clean-build reopening is closed. Remaining conditional Linux dependency, intermittent-input/resource observations and external acceptance limits are explicit in [STABILITY_REPORT.md](/Users/oliver/Documents/Projects/OM0RX-xLog/STABILITY_REPORT.md) and [REMEDIATION_TRACKER.md](/Users/oliver/Documents/Projects/OM0RX-xLog/REMEDIATION_TRACKER.md). Tested source58da5d49 passes all32final local gates. This does not complete the manual audit.\n\n',
 'REVIEW_COVERAGE.md':'**Current Phase 5 execution coverage:** All32final local gates pass on source58da5d49; current native/portable platform outcomes and open boundaries are in [STABILITY_REPORT.md](/Users/oliver/Documents/Projects/OM0RX-xLog/STABILITY_REPORT.md). CR-008\'s clean-build reopening is closed. The frozen per-file ledger below remains **INCOMPLETE**; no semantic review depth is upgraded because tests pass. Original review evidence is preserved.\n\n',
 'REGRESSION_TEST_REPORT.md':'**Current Phase 5 follow-up:** This report preserves the independent Phase4baseline and failures. Subsequent implementation and exact-source regression results are in [STABILITY_REPORT.md](/Users/oliver/Documents/Projects/OM0RX-xLog/STABILITY_REPORT.md) and [REMEDIATION_TRACKER.md](/Users/oliver/Documents/Projects/OM0RX-xLog/REMEDIATION_TRACKER.md). All32final local gates pass on58da5d49; confirmed compatible repairs are verified. Conditional Linux GLib, intermittent SCP input, overloaded timing and external/native/hardware acceptance remain explicitly limited. The dated Phase4assessment below is historical.\n\n'
}
for name,pointer in pointers.items():
 f=R/name;old=f.read_text();assert '**Current Phase 5' not in old
 if name=='CODE_REVIEW.md':old=old.replace('**Phase 4 update:**','**Historical Phase 4 update:**',1)
 if name=='REVIEW_COVERAGE.md':old=old.replace('**Phase 4 execution coverage:**','**Historical Phase 4 execution coverage:**',1)
 first,rest=old.split('\n\n',1)
 for a,b in {'source58da5d49':'source 58da5d49','all32final':'all 32 final','All32final':'All 32 final','Phase4baseline':'Phase 4 baseline','on58da5d49':'on 58da5d49','Phase4assessment':'Phase 4 assessment'}.items():pointer=pointer.replace(a,b)
 f.write_text(first+'\n\n'+pointer+rest)
readme=(P/'evidence-readme-final-draft.md').read_text().replace('{{ARCHIVE_COUNTS}}',summary)
for a,b in {'source:721e':'source: 721e','remain1.3.60':'remain 1.3.60','Phase4':'Phase 4','inode560040948':'inode 560040948','inode589158794':'inode 589158794','all180originaldist':'all 180 original dist','block-buffer0.10.4':'block-buffer 0.10.4','All13unchanged':'All 13 unchanged','Phase4/5':'Phase 4/5'}.items():readme=readme.replace(a,b)
def gzlink(match):
 label,target=match.groups();path=A/target
 if not target.startswith(('http','/','#')) and not path.exists() and Path(str(path)+'.gz').exists():return '['+label+']('+target+'.gz)'
 return match.group(0)
readme=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',gzlink,readme)
(A/'README.md').write_text(readme)
print(json.dumps({'reportsUpdated':5,'sourceHead':plan['head'],'commandReceipts':results['commands'],'privateDatabaseChecks':results['databaseChecks']}))

