from pathlib import Path
import datetime,gzip,hashlib,json,re,shlex,subprocess
from run_check import ROOT,TASK,STAGE

DEST=ROOT/'docs/reviews/release-readiness-2026-10-29'
sha=lambda data:hashlib.sha256(data).hexdigest()
assert not DEST.exists(),'Do not overwrite an existing evidence archive'
assert not (ROOT/'RELEASE_READINESS.md').exists(),'Inspect/preserve an earlier readiness report before replacement'
report=(TASK/'RELEASE_READINESS.draft.md').read_bytes()
assert b'PLATFORM_RESULT_PENDING' not in report
baseline=json.loads((TASK/'baseline.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==baseline['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
manifest=json.loads((TASK/'source-sha256.json').read_text())
assert all(sha((ROOT/path).read_bytes())==digest for path,digest in manifest.items())
assert all(sha((ROOT/path).read_bytes())==digest for path,digest in baseline['reports'].items())

results=json.loads((TASK/'results.json').read_text())
commands=['# Phase 7 exact command ledger','',
 'Canonical source b892663915cbc0768b26dc5a7bf7ec116869e409; unchanged application f3f6e3dee40af29cb6801ef8ee422c521629e168. See results.json and checks/<ID>.json for argv/cwd/UTC/env/log sizes/hashes. No live radio/provider/production data operation.','',
 '| ID | Exit | Seconds | Command |','| --- | ---: | ---: | --- |']
for row in results:
    command=shlex.join(row['command']).replace('|','\\|')
    commands.append('| '+row['id']+' | '+str(row['exit'])+' | '+str(row['seconds'])+' | `'+command+'` |')
commands.extend(['','cwd and explicit environment are recorded per receipt; test temporaries are per-ID private roots. Inherited XLOG_/XCW_ opt-ins were removed without printing their values. Test Python and denied contest UDP were explicit.',
 '', 'Successful process exit is not always product acceptance: P7-FA013 exit0 asserts the expected reference-event defect; P7-OSV-LOCK completes with recorded advisory matches. FRONTEND-FA014-* and FRONTEND-FA017-STOP exit1 are intended-behavior requirement failures. P7-GENERATOR exit1 is retained missing-CONTEST_SW_ROOT setup; corrected R2 passes42. RUST-FEATURE has no completed receipt, is not in accepted results, and is retained as INCOMPLETE_RUNNER with a completed R2.',
 '', 'The frontend original node_modules/dist were restored by inode/hash after ordinary fresh npm ci, tests/build/audit/probes. Fresh dependencies/output remain only in the named ignored stage. No assertion, timeout, isolation or lint threshold was relaxed.',
 '', 'Native/portable Swift, strict, native release, TSAN, pure IQ and worker use separate initially absent build paths. Rust initially compiles into new target; its later checks reuse only that task target. Worker bootstrap is test-only, with verified application-relative Python/CA/Not1MM runtime. No distributed application candidate, package/install/deploy or native UI run is claimed.',
 '', 'Platform supplemental VALIDATION.md records every job and step of the explicitly dispatched existing test-only contest-portability workflow, exact head and fetched log/annotation hashes. No operator-release/package/prototype dispatch. Remote test success is not packaged GUI/hardware/credential acceptance.',
 '', 'Compilation/source-only proof binaries previously blocked are not retried. Tool service timeouts/expired status and the original orphan feature log are recorded separately from actual accepted command exits. No full OS/native/model/CPython supply-chain or physical-radio qualification follows from policy/advisory checks.',
 '', 'Source/preservation/metrics and report QA scripts are retained as audit artifacts. They read only source, explicit private fixture databases, command logs and public metadata. Decompression does not authorize operating production or external hardware.'])
(TASK/'COMMANDS.md').write_text('\n'.join(commands)+'\n')

DEST.mkdir(parents=True)
entries=[];excluded=[]
plain={'.json','.md'}
compressed={'.py','.mjs','.swift','.tsx','.ts','.diff','.log','.txt','.jsonl','.adi','.cbr','.cab'}
def save(source,relative):
    data=source.read_bytes()
    # Keep structured receipts directly readable; large catalogue/process JSON is byte-preserving gzip.
    encode=source.suffix in compressed or (source.suffix=='.json' and len(data)>1_000_000)
    saved=Path(str(relative)+'.gz') if encode else relative
    stored=gzip.compress(data,mtime=0) if encode else data
    target=DEST/saved;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists(),target
    target.write_bytes(stored)
    entries.append({'originalPath':str(relative),'artifact':str(saved),'originalBytes':len(data),'originalSHA256':sha(data),'artifactBytes':len(stored),'artifactSHA256':sha(stored),'encoding':'gzip' if encode else 'identity'})

for path in sorted(TASK.rglob('*')):
    if path.is_symlink():excluded.append(str(path.relative_to(TASK)));continue
    if not path.is_file():continue
    relative=path.relative_to(TASK)
    if path.name=='RELEASE_READINESS.draft.md' or any(part in ['runtime','runtime-tmp','cache','__pycache__','node_modules'] for part in relative.parts):excluded.append(str(relative));continue
    if path.suffix not in plain|compressed:excluded.append(str(relative));continue
    save(path,relative)
process=STAGE/'process-acceptance/evidence'
for path in sorted(process.rglob('*')):
    if path.is_symlink() or not path.is_file():continue
    if path.suffix not in plain|compressed:continue
    save(path,Path('process')/path.relative_to(process))

index={'schema':1,'sourceHead':baseline['head'],'applicationSource':baseline['applicationSource'],'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':entries,'excludedScratchPaths':excluded,'exclusionPolicy':'No executable binaries, SQLite/sidecars, runtime payloads, dependencies/cache trees, symlinks or duplicate root report. Text/source/log bytes only, gzip fixedmtime0.'}
(DEST/'artifact-index.json').write_text(json.dumps(index,indent=2)+'\n')
readme='''# Phase 7 final validation and release evidence

Canonical main b892663915cbc0768b26dc5a7bf7ec116869e409; application f3f6e3dee40af29cb6801ef8ee422c521629e168, version1.3.60. Assessment: **NO-GO**, one High and seven Medium findings remain. Existing complete mandatory automated suites/clean builds pass, while actual audit counterexamples reproduce and native/hardware/provider/recovery acceptance is incomplete.

Read [RELEASE_READINESS.md](/Users/oliver/Documents/Projects/OM0RX-xLog/RELEASE_READINESS.md) for the current recommendation, severity/status, matrix, warning/skip/security assessment and next steps. No application/test/config/dependency changes, native GUI, production data, account-bound provider, real hardware/RF, package/install/deploy occurred. Explicit dummy daemons use model1/loopback/TXdisabled. Worker bootstrap is a private CLI fixture, not a release candidate.

- COMMANDS.md, results.json, checks/*.json/log.gz: exact argv/cwd/env/UTC/exits/log bytes+SHA. A *-running.json is a historical admission marker, not evidence a process remains active. Only completed receipts are accepted; orphan RUST-FEATURE is explicitly incomplete and superseded by R2.
- agents/frontend/VALIDATION.md and READINESS_QA.md: fresh npm install/full4742+6/build/audit, reproduced timestamp/UI Stop requirements, restored dependencies/dist, independent draft QA.
- agents/rust/VALIDATION.md: full924+31/feature931, explicit dummy tests, Clippy/release warnings, incomplete runner and bounded role/lifecycle evidence.
- agents/data/VALIDATION.md, migration-data-config-compatibility.json and catalogue-dimensions.json:558Python, all97 lifecycle+393family, equivalence127/generator42/corpus94/16/relocation12, actual FA013 and two-DB integrity; complete per-plugin limitations.
- agents/platform/VALIDATION.md and own job/step/log/annotation snapshots: fresh exact-head test-only seven-job platform workflow; skipped platform steps are not passes or packaged/runtime acceptance.
- swift-qualification.json: per-binary top-level XCTest summaries, SwiftTesting summary groups, actual skipped/disabled lines and normalized source warning headers. Native330+summary340/12disabled; portable1191/6XCTestskip+summary541/7disabled; TSAN71+21. Warnings remain.
- process/ and process-summary.json:81 actual Swift-worker/Python exchanges,2workers,21boolean assertions,four exports. Rust host/nativeUI not exercised. The complete process runtime, binaries and SQLite files are excluded.
- osv/results.json, security-triage.json and primary-source-review.json:549locked versions and broad raw matches retained; primary maintainer range check qualifies block-buffer, conditional LinuxGLib remainsblocked. Primary-source review receipt is not a fabricated raw HTTP-body hash.
- baseline.json, source-sha256.json, remediation-scope.json, preservation-validation.json:1838unchanged inputs,79changed remediation inputs/34source-support commits, all6historical reports preserved, original node_modules/CW inodes and180dist hashes, four private process DBs/four exports. Two more private Host DBs are independently checked in agents/data.
- artifact-index.json records every copied file's original/saved length+SHA; gzip is byte-preserving. SHA256SUMS covers all evidence files except itself. verify_evidence.py.gz checks preservation, raw command hashes, archive bytes, source/report links and permitted Git paths.

Evidence counts overlap; no unique grand test total. Existing passes do not erase failed new requirements. Initial generator setup failure, tool timeouts, orphan feature and compile-only/blocked proof limits remain explicit. Historical reports and review evidence are immutable. No full manual code audit, real provider/radio, signing/notarization, installed/native UI, production migration, OS-crash durability or long-soak acceptance is implied.
'''
(DEST/'README.md').write_text(readme)
(ROOT/'RELEASE_READINESS.md').write_bytes(report)
files=[]
for path in sorted(DEST.rglob('*')):
    assert not path.is_symlink(),path
    if path.is_file() and path.name!='SHA256SUMS':files.append((str(path.relative_to(DEST)),sha(path.read_bytes())))
(DEST/'SHA256SUMS').write_text(''.join(digest+'  '+name+'\n' for name,digest in files))
print(json.dumps({'artifacts':len(entries),'evidenceFiles':len(files)+1,'excludedScratchPaths':len(excluded),'reportSHA256':sha(report),'sourceInputsUnchanged':len(manifest)},indent=2))
