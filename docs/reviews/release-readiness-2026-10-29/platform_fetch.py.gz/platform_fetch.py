from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
TASK=Path('/tmp/xlog-phase7-20261029-b8926639')
OUT=TASK/'agents/platform'
job=int(sys.argv[1]);kind=sys.argv[2]
assert kind in ['log','annotations']
known=json.loads((OUT/'jobs-001.json').read_text())['jobs']
entry=next(j for j in known if j['id']==job)
assert entry['head_sha']=='b892663915cbc0768b26dc5a7bf7ec116869e409'
endpoint=f'repos/oliverbross/OM0RX-xLog/actions/jobs/{job}/logs' if kind=='log' else f'repos/oliverbross/OM0RX-xLog/check-runs/{job}/annotations?per_page=100'
command=['gh','api',endpoint]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
stderr=OUT/f'{job}-{kind}-stderr.log'
with stderr.open('wb') as err:
    process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=err)
    whole=bytearray();head=bytearray();tail=bytearray();total=0;digest=hashlib.sha256()
    while True:
        chunk=process.stdout.read(65536)
        if not chunk:break
        total+=len(chunk);digest.update(chunk)
        if len(head)<131072:head.extend(chunk[:131072-len(head)])
        tail.extend(chunk)
        if len(tail)>1048576:del tail[:-1048576]
        if total<=2097152:whole.extend(chunk)
        else:whole.clear()
    code=process.wait()
suffix='.log' if kind=='log' else '.json'
path=OUT/f'{job}-{kind}{suffix}'
saved=bytes(whole) if total<=2097152 else bytes(head)+b'\n[bounded evidence: middle omitted; complete stream hash in fetch receipt]\n'+bytes(tail)
path.write_bytes(saved)
receipt={'jobId':job,'jobName':entry['name'],'head':entry['head_sha'],'kind':kind,'command':command,'startedUTC':start,'seconds':round(time.monotonic()-clock,3),'exit':code,'streamBytes':total,'streamSHA256':digest.hexdigest(),'fullStreamSaved':total<=2097152,'savedFile':str(path),'savedBytes':len(saved),'savedSHA256':hashlib.sha256(saved).hexdigest(),'stderrFile':str(stderr),'stderrBytes':stderr.stat().st_size}
if kind=='annotations' and code==0 and total<=2097152:
    annotations=json.loads(saved)
    receipt['annotationCount']=len(annotations);receipt['paginationRequired']=len(annotations)==100
(OUT/f'{job}-{kind}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
sys.exit(code)
