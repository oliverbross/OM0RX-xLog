from pathlib import Path
import gzip,hashlib,json,re,subprocess

ROOT=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
DEST=ROOT/'docs/reviews/release-readiness-2026-10-29'
sha=lambda data:hashlib.sha256(data).hexdigest()
baseline=json.loads((DEST/'baseline.json').read_text())
source=json.loads((DEST/'source-sha256.json').read_text())
assert len(source)==1838
assert all(sha((ROOT/path).read_bytes())==digest for path,digest in source.items())
assert all(sha((ROOT/path).read_bytes())==digest for path,digest in baseline['reports'].items())
assert (ROOT/'prototype/node_modules').stat().st_ino==baseline['nodeModulesInode']
assert (ROOT/'.build/cw-native').stat().st_ino==baseline['cwNativeInode']
assert {str(p.relative_to(ROOT/'prototype/dist')):sha(p.read_bytes()) for p in (ROOT/'prototype/dist').rglob('*') if p.is_file()}==baseline['distHashes']
index=json.loads((DEST/'artifact-index.json').read_text())
originals={}
for item in index['entries']:
    data=(DEST/item['artifact']).read_bytes();assert sha(data)==item['artifactSHA256']
    value=gzip.decompress(data) if item['encoding']=='gzip' else data
    assert len(value)==item['originalBytes'] and sha(value)==item['originalSHA256'],item['artifact']
    originals[item['originalPath']]=value
checknames=set()
for line in (DEST/'SHA256SUMS').read_text().splitlines():
    digest,path=line.split('  ',1);checknames.add(path);assert sha((DEST/path).read_bytes())==digest,path
assert checknames=={str(p.relative_to(DEST)) for p in DEST.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
receipts=json.loads((DEST/'results.json').read_text())
for row in receipts:
    value=originals['checks/'+row['id']+'.log']
    assert sha(value)==row['logSHA256'] and len(value)==row['logBytes'],row['id']
    assert row['sourceHeadStart']==baseline['head']==row['sourceHeadEnd']
    assert row['sourceDiffSHA256']==sha(b''),row['id']
mandatory=json.loads((DEST/'preservation-validation.json').read_text())['standardCompletedExit0Commands']
lookup={row['id']:row for row in receipts}
assert len(mandatory)==26 and all(lookup[name]['exit']==0 for name in mandatory)
report=(ROOT/'RELEASE_READINESS.md').read_text()
assert '**Recommendation: NO-GO' in report and 'PLATFORM_RESULT_PENDING' not in report
assert re.findall(r'^\| (?:\*\*)?(FA-\d{3})(?:\*\*)? \|',report,re.M)==[f'FA-{n:03}' for n in range(10,18)]
links=[]
for target in re.findall(r'\]\((/[^)]+)\)',report):
    file,line=target,None;match=re.match(r'^(.*?):(\d+)$',file)
    if match:file,line=match.group(1),int(match.group(2))
    path=Path(file);assert path.is_file(),target
    if line:assert 1<=line<=len(path.read_text().splitlines()),target
    links.append(target)
changed=subprocess.check_output(['git','diff','--name-only',baseline['head'],'--'],cwd=ROOT,text=True).splitlines()
assert all(path=='RELEASE_READINESS.md' or path.startswith('docs/reviews/release-readiness-2026-10-29/') for path in changed),changed
print(json.dumps({'sourceInputsUnchanged':len(source),'historicalReportsUnchanged':len(baseline['reports']),'originalDistFilesRestored':len(baseline['distHashes']),'artifactOriginalHashesVerified':len(index['entries']),'evidenceFileChecksumsVerified':len(checknames),'completedReceiptsVerified':len(receipts),'standardExit0CommandsVerified':len(mandatory),'reportLinksVerified':len(links),'reportSHA256':sha(report.encode()),'changedTrackedPaths':len(changed),'gitStatus':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)},indent=2))
