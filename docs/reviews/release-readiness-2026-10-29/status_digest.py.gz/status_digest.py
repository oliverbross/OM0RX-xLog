from pathlib import Path
import json

TASK=Path('/tmp/xlog-phase7-20261029-b8926639')
done=[];running=[]
for path in sorted((TASK/'checks').glob('*.json')):
    if path.name.endswith('-running.json'): continue
    result=json.loads(path.read_text())
    if 'id' in result and 'exit' in result: done.append({'id':result['id'],'exit':result['exit'],'seconds':result.get('seconds')})
for path in sorted((TASK/'checks').glob('*-running.json')):
    result=json.loads(path.read_text())
    if not (path.parent/(result['id']+'.json')).exists():
        log=path.parent/(result['id']+'.log')
        running.append({'id':result['id'],'startedUTC':result['startedUTC'],'logBytes':log.stat().st_size if log.exists() else None,'tail':log.read_text(errors='replace').splitlines()[-3:] if log.exists() else []})
print(json.dumps({'completed':done,'running':running},indent=2))
