from pathlib import Path
import datetime, hashlib, json, re, subprocess
from run_check import ROOT,TASK,STAGE

baseline=json.loads((TASK/'baseline.json').read_text())
sha=lambda value:hashlib.sha256(value).hexdigest()
empty=sha(b'')
receipts=[]
for path in sorted((TASK/'checks').glob('*.json')):
    if path.name.endswith('-running.json'):continue
    value=json.loads(path.read_text())
    if not all(key in value for key in ['id','command','exit','logSHA256']):continue
    log=Path(value['log']);data=log.read_bytes()
    assert len(data)==value['logBytes'] and sha(data)==value['logSHA256'],path
    assert value['sourceHeadStart']==baseline['head']==value['sourceHeadEnd'],path
    assert value['sourceDiffSHA256']==empty,path
    receipts.append(value)
(TASK/'results.json').write_text(json.dumps(receipts,indent=2)+'\n')
swift=[]
for name in ['P7-NATIVE','P7-PORTABLE','P7-STRICT','P7-NATIVE-RELEASE','P7-TSAN','P7-PURE-IQ','P7-CLEAN-WORKER','P7-FRAMING','P7-CURRENT-PROCESS']:
    receipt=next(item for item in receipts if item['id']==name)
    text=Path(receipt['log']).read_text(errors='replace')
    headers=[line for line in text.splitlines() if 'warning:' in line]
    xct=re.findall(r'Executed (\d+) tests?, with (?:([0-9]+) tests? skipped and )?([0-9]+) failures?',text)
    testing=re.findall(r'Test run with .*?passed.*',text)
    skipped=[line for line in text.splitlines() if re.search(r'\b(skipped|disabled)\b',line,re.I)]
    entry={'id':name,'exit':receipt['exit'],'seconds':receipt['seconds'],'xctSummaries':xct,'swiftTestingSummaries':testing,'warningHeaderCount':len(headers),'uniqueWarningHeaders':sorted(set(headers)),'skippedOrDisabledLines':skipped}
    swift.append(entry)
(TASK/'swift-analysis.json').write_text(json.dumps(swift,indent=2)+'\n')

versions={}
for command in [['uname','-srm'],['swift','--version'],['node','--version'],['npm','--version'],['/opt/homebrew/bin/python3.12','--version'],['/opt/homebrew/bin/python3.14','--version'],['rustc','--version'],['cargo','--version'],['cargo','clippy','--version']]:
    result=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=30)
    versions[' '.join(command)]={'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
(TASK/'environment.json').write_text(json.dumps({'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'versions':versions,'scope':'Local macOS arm64 source validation; no installed application or station state inspected'},indent=2)+'\n')

base='530de4c4e4b23281ec60585cc7a2e5ca011476fb'
prefixes=['Sources','Tests','prototype','python','native','tools','scripts','.github','Package.swift','Package.resolved']
removed=subprocess.check_output(['git','diff','--diff-filter=D','--name-only',base,baseline['head'],'--',*prefixes],cwd=ROOT,text=True).splitlines()
changed=json.loads((TASK/'all-remediation-paths.json').read_text())
commits=subprocess.check_output(['git','log','--format=%H %s',base+'..'+baseline['head'],'--',*prefixes],cwd=ROOT,text=True).splitlines()
manifests={}
for path in ['Package.swift','prototype/package.json','prototype/src-tauri/tauri.conf.json']:
    before=subprocess.check_output(['git','show',base+':'+path],cwd=ROOT,text=True)
    after=(ROOT/path).read_text()
    if path=='Package.swift':
        pattern=r'\.(?:executable|library)\(name:\s*"([^"]+)"'
        old=sorted(set(re.findall(pattern,before)));new=sorted(set(re.findall(pattern,after)))
    elif path.endswith('package.json'):
        old={'scripts':json.loads(before)['scripts'],'runtimeDependencyNames':sorted(json.loads(before)['dependencies'])}
        new={'scripts':json.loads(after)['scripts'],'runtimeDependencyNames':sorted(json.loads(after)['dependencies'])}
    else:
        old=json.loads(before);new=json.loads(after)
    manifests[path]={'before':old,'current':new,'equal':old==new}
features={'baseline':base,'auditedHead':baseline['head'],'changedInputs':len(changed),'removedTrackedInputs':removed,'applicationSupportCommits':commits,'manifestContracts':manifests,'boundary':'No production inputs deleted and public products/runtime dependency entrypoints compared; not proof of every unchanged or native/hardware workflow. Safety/validation behavior changes and eight open final-audit defects remain explicit.'}
(TASK/'remediation-scope.json').write_text(json.dumps(features,indent=2)+'\n')

print('Verified receipts',len(receipts),'nonzero',[(item['id'],item['exit']) for item in receipts if item['exit']])
for row in swift:
    print(json.dumps({'id':row['id'],'exit':row['exit'],'seconds':row['seconds'],'xctFinal':row['xctSummaries'][-2:],'swiftTesting':row['swiftTestingSummaries'][-1:],'warnings':row['warningHeaderCount'],'uniqueWarnings':len(row['uniqueWarningHeaders']),'skipDisabledLines':len(row['skippedOrDisabledLines'])}))
print('Scope',len(changed),'changed inputs;',len(commits),'source/support commits; deleted',removed)
print('Manifest equalities',{key:value['equal'] for key,value in manifests.items()})
