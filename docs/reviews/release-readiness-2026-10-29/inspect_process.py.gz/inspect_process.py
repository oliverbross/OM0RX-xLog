import json
from run_check import ROOT,TASK,STAGE

value=json.loads((STAGE/'process-acceptance/evidence/acceptance.json').read_text())
print('TOP KEYS',list(value))
for key in value:
    if key not in ['source','boundary']:
        child=value[key]
        print(key, list(child) if isinstance(child,dict) else type(child).__name__)
for key in ['passed','ok','checks','assertions','contestMutation','workerExit','workers','protocol','runtime']:
    if key in value:print(key,json.dumps(value[key],indent=2)[:7000])
scope=json.loads((TASK/'remediation-scope.json').read_text())
print('PACKAGE CONTRACT',json.dumps(scope['manifestContracts']['prototype/package.json'],indent=2))
print('ENVIRONMENT', (TASK/'environment.json').read_text())
