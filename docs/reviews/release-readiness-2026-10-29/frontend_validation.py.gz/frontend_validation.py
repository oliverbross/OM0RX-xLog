import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
from run_check import ROOT,TASK,STAGE,run_check
out=TASK/'agents/frontend';out.mkdir(parents=True,exist_ok=True)
fresh=STAGE/'frontend-deps/node_modules'
modules=ROOT/'prototype/node_modules';dist=ROOT/'prototype/dist'
oldmodules=STAGE/'original-frontend-node_modules';olddist=STAGE/'original-frontend-dist'
assert modules.is_dir() and not modules.is_symlink() and fresh.is_dir()
assert not oldmodules.exists() and not olddist.exists()
def tree(path):
    return {str(p.relative_to(path)):({'symlink':os.readlink(p)} if p.is_symlink() else {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}) for p in path.rglob('*') if p.is_file() or p.is_symlink()}
def source():
    names=subprocess.check_output(['git','ls-files','-z','--','prototype'],cwd=ROOT).decode().split('\0')
    return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in names if p and (ROOT/p).is_file()}
moduleinode=modules.stat().st_ino
originaldist=tree(dist);originalsource=source()
(out/'source-sha256-before.json').write_text(json.dumps(originalsource,indent=2)+'\n')
(out/'original-dist-sha256.json').write_text(json.dumps(originaldist,indent=2)+'\n')
modules.rename(oldmodules);had_dist=dist.exists()
if had_dist:dist.rename(olddist)
results={}
try:
    fresh.rename(modules)
    results['FRONTEND-FULL-TEST']=run_check('FRONTEND-FULL-TEST',['npm','test'],ROOT/'prototype',timeout=1800)
    results['FRONTEND-BUILD']=run_check('FRONTEND-BUILD',['npm','run','build'],ROOT/'prototype',timeout=900)
    # Only scratch copies and an explicit scratch test root are used for prior counterexamples.
    prior=Path('/tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/frontend')
    scratch=out/'scratch';scratch.mkdir()
    for name in ['reversal.test.tsx','detached-reversal.test.tsx','fldigi-stop.test.tsx']:
        shutil.copyfile(prior/name,scratch/name)
    canonical=str(scratch.resolve())
    config=(prior/'vitest.config.mjs').read_text().replace('/private/tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/frontend',canonical).replace('/tmp/xlog-phase6-fresh-20261029-0375a8e1/agents/frontend',canonical)
    (scratch/'vitest.config.mjs').write_text(config)
    base=['node',str(modules/'vitest/vitest.mjs'),'run','--config',str(scratch/'vitest.config.mjs'),'--configLoader','native','--cache','false','--maxWorkers','1']
    results['FRONTEND-FA014-FORMS']=run_check('FRONTEND-FA014-FORMS',base+['reversal.test.tsx'],ROOT/'prototype',timeout=180)
    results['FRONTEND-FA014-DETACHED']=run_check('FRONTEND-FA014-DETACHED',base+['detached-reversal.test.tsx'],ROOT/'prototype',timeout=180)
    results['FRONTEND-FA017-STOP']=run_check('FRONTEND-FA017-STOP',base+['fldigi-stop.test.tsx','--testNamePattern','fresh fldigi uncertain Stop'],ROOT/'prototype',timeout=180)
finally:
    if modules.exists():modules.rename(fresh)
    oldmodules.rename(modules)
    if dist.exists():dist.rename(STAGE/'frontend-generated-dist')
    if had_dist:olddist.rename(dist)
    aftersource=source();afterdist=tree(dist)
    receipt={'nodeModulesOriginalInode':moduleinode,'nodeModulesRestoredInode':modules.stat().st_ino,'nodeModulesRestoredByInode':moduleinode==modules.stat().st_ino,'originalDistFiles':len(originaldist),'originalDistBytes':sum(x.get('bytes',0) for x in originaldist.values()),'originalDistRestored':afterdist==originaldist,'trackedFrontendSourceFiles':len(originalsource),'trackedFrontendSourceUnchanged':originalsource==aftersource,'freshDependenciesPreserved':str(fresh),'generatedDistPreserved':str(STAGE/'frontend-generated-dist'),'checks':results}
    (out/'source-sha256-after.json').write_text(json.dumps(aftersource,indent=2)+'\n')
    (out/'preservation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2),flush=True)
    assert receipt['nodeModulesRestoredByInode'] and receipt['originalDistRestored'] and receipt['trackedFrontendSourceUnchanged']
sys.exit(0 if results.get('FRONTEND-FULL-TEST')==0 and results.get('FRONTEND-BUILD')==0 else 1)
