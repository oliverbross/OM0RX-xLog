from pathlib import Path
import argparse, datetime, hashlib, json, os, signal, subprocess, sys, time

ROOT=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
TASK=Path('/tmp/xlog-phase7-20261029-b8926639')
STAGE=ROOT/'.build/phase7-validation-20261029-b8926639'

def run_check(name,command,cwd=ROOT,overrides=None,timeout=1800):
    logs=TASK/'checks';logs.mkdir(parents=True,exist_ok=True)
    assert not (logs/(name+'.json')).exists(),name
    env={key:value for key,value in os.environ.items() if not key.startswith(('XLOG_','XCW_'))}
    temporary=TASK/'runtime-tmp'/name;temporary.mkdir(parents=True,exist_ok=True)
    env.update({'TMPDIR':str(temporary.resolve()),'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(ROOT/'python')+':'+str(ROOT/'python/tests'),'XLOG_CONTEST_N1MM_UDP_ALLOWED':'0','XLOG_CONTEST_ALLOW_UDP':'0','XLOG_CONTEST_PYTHON':'/opt/homebrew/bin/python3.12','XLOG_TEST_PYTHON312':'/opt/homebrew/bin/python3.12','XLOG_TEST_PYTHON':'/opt/homebrew/bin/python3.12'})
    env.update(overrides or {})
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    log=logs/(name+'.log');timed_out=False
    (logs/(name+'-running.json')).write_text(json.dumps({'id':name,'command':command,'startedUTC':started,'cwd':str(cwd)},indent=2)+'\n')
    with log.open('wb') as stream:
        child=subprocess.Popen(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        try:code=child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True;os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            code=124
    receipt={'id':name,'command':command,'cwd':str(cwd),'startedUTC':started,'finishedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':round(time.monotonic()-clock,3),'exit':code,'timedOut':timed_out,'sourceHeadStart':head,'sourceHeadEnd':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'sourceDiffSHA256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--','Sources','Tests','prototype','python','tools','scripts','.github','Package.swift'],cwd=ROOT)).hexdigest(),'log':str(log),'logBytes':log.stat().st_size,'logSHA256':hashlib.sha256(log.read_bytes()).hexdigest(),'environmentPolicy':'Inherited XLOG_/XCW_ opt-ins removed without printing values; private temp paths, explicit test Python and denied contest UDP. No production roots/providers/hardware.','explicitEnvironment':overrides or {}}
    (logs/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2),flush=True)
    return code

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('name');parser.add_argument('--cwd',default=str(ROOT));parser.add_argument('--timeout',type=int,default=1800);parser.add_argument('--env',action='append',default=[])
    boundary=sys.argv.index('--');args=parser.parse_args(sys.argv[1:boundary]);command=sys.argv[boundary+1:]
    assert command
    sys.exit(run_check(args.name,command,Path(args.cwd),dict(row.split('=',1) for row in args.env),args.timeout))
