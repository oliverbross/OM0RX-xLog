from pathlib import Path
import datetime,hashlib,json
from run_check import ROOT,TASK

sha=lambda data:hashlib.sha256(data).hexdigest()
baseline=json.loads((TASK/'baseline.json').read_text())
run=json.loads((TASK/'agents/platform/run-final.json').read_text())
assert run['headSha']==baseline['head']
assert run['status']=='completed' and run['conclusion']=='success'
assert len(run['jobs'])==7
assert all(job['status']=='completed' and job['conclusion']=='success' for job in run['jobs'])
qa=json.loads((TASK/'agents/platform/QA.json').read_text())
assert qa['jobs']==7 and qa['successfulJobs']==7 and qa['fullRawLogsSaved']==7 and not qa['skippedStepsCountedAsPass']
data=json.loads((TASK/'agents/data/disposable-db-integrity.json').read_text())
assert data['status']=='PASS' and data['count']==2 and len(data['databases'])==2
assert all(row['integrity']==['ok'] and not row['foreignKeyViolations'] and row['unchanged'] for row in data['databases'])
for row in data['databases']:
    assert sha(Path(row['path']).read_bytes())==row['sha256'],row['path']
root=json.loads((TASK/'preservation-validation.json').read_text())
assert len(root['privateProcessDatabases'])==4 and len(root['verifiedExports'])==4
assert root['sourceInputsUnchanged']==1838 and root['historicalReportsUnchanged']==6
assert len(root['standardCompletedExit0Commands'])==26
assert root['validatedCommandReceipts']==58
assert not root['remainingTaskBuildTestWorkerProcesses']
swift=json.loads((TASK/'swift-qualification.json').read_text())
native=next(row for row in swift if row['id']=='P7-STRICT-NATIVE')
assert native['sourceWarningHeaders']==5 and len(native['uniqueSourceWarnings'])==5 and not native['sourceErrors']
draft=(TASK/'RELEASE_READINESS.draft.md').read_bytes()
assert b'PLATFORM_RESULT_PENDING' not in draft
assert b'26 named standard' in draft and b'five source warnings' in draft
result={'verifiedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':baseline['head'],'reportDraftSHA256':sha(draft),'standardLocalExit0Commands':26,'completedCommandReceipts':58,'platformJobsSucceeded':7,'platformOwnFullLogsRetained':7,'privateDatabasesIntegrityChecked':6,'workerExportsVerified':4,'sourceInputsUnchanged':1838,'historicalReportsUnchanged':6,'nativeStrictWarningHeaders':5,'remainingFindings':{'High':1,'Medium':7},'readiness':'NO-GO','noApplicationChanges':True}
(TASK/'final-qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
