from pathlib import Path
import hashlib,json,re
from run_check import ROOT,TASK

report=(TASK/'RELEASE_READINESS.draft.md').read_text()
assert '**Recommendation: NO-GO' in report
ids=re.findall(r'^\| (?:\*\*)?(FA-\d{3})(?:\*\*)? \|',report,re.M)
assert ids==[f'FA-{n:03}' for n in range(10,18)],ids
assert report.count('PLATFORM_RESULT_PENDING') in (0,1)
links=[];deferred=[]
for target in re.findall(r'\]\((/[^)]+)\)',report):
    file,line=target,None
    match=re.match(r'^(.*?):(\d+)$',file)
    if match:file,line=match.group(1),int(match.group(2))
    if '/docs/reviews/release-readiness-2026-10-29/' in file:deferred.append(target);continue
    path=Path(file);assert path.is_file(),target
    if line:assert 1<=line<=len(path.read_text().splitlines()),target
    links.append(target)
base=json.loads((TASK/'baseline.json').read_text())
assert all(hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest for path,digest in json.loads((TASK/'source-sha256.json').read_text()).items())
assert all(hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest for path,digest in base['reports'].items())
rootdb=json.loads((TASK/'preservation-validation.json').read_text())['privateProcessDatabases']
data=json.loads((TASK/'agents/data/disposable-db-integrity.json').read_text())
print('Data DB evidence type',type(data).__name__)
print('data DB keys', list(data) if isinstance(data,dict) else ['list records',len(data)])
print('Draft QA:8IDs,NO-GO,source1838/history6unchanged; productionlinks',len(links),'evidencelinksdeferred',len(deferred),'rootProcessDBs',len(rootdb))
