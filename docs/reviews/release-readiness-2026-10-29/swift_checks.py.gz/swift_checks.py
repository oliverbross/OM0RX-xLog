import json, sys
from run_check import ROOT,TASK,STAGE,run_check

results=[]
steps=[
 ('P7-NATIVE',['swift','test','--jobs','2','--scratch-path',str(STAGE/'native'),'--no-parallel'],{}),
 ('P7-PORTABLE',['swift','test','--jobs','2','--scratch-path',str(STAGE/'portable'),'--no-parallel'],{'XLOG_PORTABLE_ONLY':'1'}),
 ('P7-STRICT',['swift','build','--scratch-path',str(STAGE/'strict'),'--jobs','2','-Xswiftc','-strict-concurrency=complete','-Xswiftc','-warn-concurrency'],{'XLOG_PORTABLE_ONLY':'1'}),
 ('P7-NATIVE-RELEASE',['swift','build','-c','release','--scratch-path',str(STAGE/'native-release'),'--jobs','2','--product','om0rx-xlog'],{}),
 ('P7-TSAN',['swift','test','--scratch-path',str(STAGE/'tsan'),'--jobs','2','--sanitize','thread','--no-parallel','--filter','StationRadioRegistryTests|NativePowerSelectionTests|NativeDraftPowerCaptureTests|NativeDraftPowerAdmissionTests|AutomaticSyncTests|RestoreAtomicityTests|LiveFlexSessionTests|BackupRestoreAuthorityTests|WavelogDestinationAuthorityTests'],{'XLOG_PORTABLE_ONLY':'1'}),
 ('P7-PURE-IQ',['/opt/homebrew/bin/python3.12','-B','tools/check_portable_iq_sources.py','--repository',str(ROOT),'--output',str(STAGE/'pure-iq')],{}),
 ('P7-CLEAN-WORKER',['node','prototype/scripts/build-contesting-worker-process.mjs','--scratch-path',str(STAGE/'worker-clean'),'--output',str(TASK/'worker-build-manifest.json')],{}),
]
for name,command,env in steps:
    assert not (STAGE/({'P7-NATIVE':'native','P7-PORTABLE':'portable','P7-STRICT':'strict','P7-NATIVE-RELEASE':'native-release','P7-TSAN':'tsan','P7-PURE-IQ':'pure-iq','P7-CLEAN-WORKER':'worker-clean'}[name])).exists(),name
    results.append({'id':name,'exit':run_check(name,command,overrides=env,timeout=1800)})
    (TASK/'swift-results.json').write_text(json.dumps(results,indent=2)+'\n')
if results[-1]['exit']==0:
    manifest=TASK/'worker-build-manifest.json'
    worker=json.loads(manifest.read_text())['worker']['path']
    head=json.loads((TASK/'baseline.json').read_text())['head']
    for name,command in [
      ('P7-FRAMING',['node','Tests/XLogPrototypeTests/worker-process.test.mjs',worker]),
      ('P7-CURRENT-PROCESS',['node','prototype/scripts/accept-contesting-worker-process.mjs','--build-manifest',str(manifest.resolve()),'--output',str(STAGE/'process-acceptance'),'--expected-head',head])]:
        results.append({'id':name,'exit':run_check(name,command,timeout=600)})
        (TASK/'swift-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2));sys.exit(any(row['exit'] for row in results))
