import datetime,hashlib,json,re
from run_check import ROOT,TASK,STAGE

value=json.loads((STAGE/'process-acceptance/evidence/acceptance.json').read_text())
assert value['operationCount']==81
assert value['outcome']=={'ok':True}
assert all(value['assertions'].values())
assert len(value['processes'])==2
process={'operationCount':value['operationCount'],'outcome':value['outcome'],'boundary':value['boundary'],'contestRuntimePythonVersion':value['contestRuntime']['pythonVersion'],'assertions':value['assertions'],'processes':value['processes'],'exportChecks':value['contestMutation']['exportChecks'],'protectedMetadataEvidence':value['protectedProductionMetadata']}
(TASK/'process-summary.json').write_text(json.dumps(process,indent=2)+'\n')
swift=json.loads((TASK/'swift-qualification.json').read_text())
lookup={item['id']:item for item in swift}
assert lookup['P7-NATIVE']['xctestTotal']==330 and lookup['P7-NATIVE']['swiftTestingSummaryTotal']==340
assert len(lookup['P7-NATIVE']['skipLines'])==12
assert lookup['P7-PORTABLE']['xctestTotal']==1191 and lookup['P7-PORTABLE']['xctestSkips']==6
assert lookup['P7-PORTABLE']['swiftTestingSummaryTotal']==541
assert len(lookup['P7-PORTABLE']['skipLines'])==13
assert lookup['P7-TSAN']['xctestTotal']==71 and lookup['P7-TSAN']['swiftTestingSummaryTotal']==21
assert lookup['P7-STRICT']['sourceWarningHeaders']==119 and len(lookup['P7-STRICT']['uniqueSourceWarnings'])==112
assert lookup['P7-STRICT-NATIVE']['sourceWarningHeaders']==5 and len(lookup['P7-STRICT-NATIVE']['uniqueSourceWarnings'])==5
assert all(not item['sourceErrors'] for item in swift)
osv=json.loads((TASK/'osv/results.json').read_text())
assert osv['queriedVersions']==549 and len(osv['matches'])==6 and len(osv['advisoryIDs'])==7
triage={'observedUTC':osv['observedUTC'],'queriedVersions':549,'rawPackageMatches':6,'rawIDs':7,'items':[
 {'package':'block-buffer','version':'0.10.4','status':'Version false positive by current primary maintainer range','range':'>=0.11.0,<0.12.1','source':'https://github.com/RustCrypto/utils/security/advisories/GHSA-qwgh-2vcv-g2f7'},
 {'package':'glib','version':'0.18.5','status':'DEP-P5-003 remains Blocked conditional Linux affected-function risk; application severity/reachability unassigned','patched':'>=0.20.0','source':'https://rustsec.org/advisories/RUSTSEC-2024-0429.html'},
 *[{'package':p,'status':'Upstream maintenance notice; no new application vulnerability demonstrated'} for p in ['proc-macro-error','zbus_names','zvariant','zvariant_derive']]],'scope':'Current locked registry query and primary affected-range review. No cargo-audit bypass, universal SBOM/runtime/OS security claim, incompatible override or exploitation test.'}
(TASK/'security-triage.json').write_text(json.dumps(triage,indent=2)+'\n')
data_result=json.loads((TASK/'agents/data/country-reconcile-result.json').read_text())
assert data_result['replicaUnchanged'] and data_result['errorCode']=='invalid_request'
data_db=json.loads((TASK/'agents/data/disposable-db-integrity.json').read_text()) if (TASK/'agents/data/disposable-db-integrity.json').exists() else None
print('process summary:81exchanges,2workers,21assertions,four exports; native330+summary340/12skip; portable1191/6skip+summary541/7skip; TSAN71+21; strict119headers/112distinct; OSV549/6matches/7rawIDs; FA013reproduced')
print('Data integrity evidence file', data_db is not None)
print('Staged worker Python version',value['contestRuntime']['pythonVersion'])
