from pathlib import Path
import datetime,hashlib,json,sqlite3,subprocess
from run_check import ROOT,TASK,STAGE

baseline=json.loads((TASK/'baseline.json').read_text())
manifest=json.loads((TASK/'source-sha256.json').read_text())
sha=lambda data:hashlib.sha256(data).hexdigest()
assert len(manifest)==1838
assert all(sha((ROOT/path).read_bytes())==digest for path,digest in manifest.items())
assert all(sha((ROOT/path).read_bytes())==digest for path,digest in baseline['reports'].items())
assert (ROOT/'prototype/node_modules').stat().st_ino==baseline['nodeModulesInode']
assert (ROOT/'.build/cw-native').stat().st_ino==baseline['cwNativeInode']
dist={str(p.relative_to(ROOT/'prototype/dist')):sha(p.read_bytes()) for p in (ROOT/'prototype/dist').rglob('*') if p.is_file()}
assert dist==baseline['distHashes']
process=STAGE/'process-acceptance'
databases=[]
for path in sorted(process.rglob('*')):
    if path.is_symlink() or not path.is_file() or path.suffix not in {'.sqlite','.sqlite3','.db'}:continue
    relative=path.relative_to(process)
    if any(part in {'runtime','Contents','Frameworks','MacOS','Resources','contest-engine','python'} for part in relative.parts):continue
    if path.read_bytes()[:16]!=b'SQLite format 3\x00':continue
    before=sha(path.read_bytes())
    connection=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)
    try:
        integrity=connection.execute('PRAGMA integrity_check').fetchall()
        foreign=connection.execute('PRAGMA foreign_key_check').fetchall()
        version=connection.execute('PRAGMA user_version').fetchone()[0]
    finally:connection.close()
    assert integrity==[('ok',)] and not foreign,(path,integrity,foreign)
    assert sha(path.read_bytes())==before,path
    databases.append({'path':str(path),'integrity':'ok','foreignKeyViolations':0,'userVersion':version,'sha256':before,'unchangedByReadOnlyCheck':True})
accept=json.loads((process/'evidence/acceptance.json').read_text())
assert accept['source']['observedHead']==baseline['head']==accept['source']['expectedHead']
exports=[]
for check in accept.get('contestMutation',{}).get('exportChecks',[]):
    matches=[]
    for artifact in (process/'evidence').iterdir():
        if artifact.is_file() and artifact.suffix in {'.adi','.log'}:
            content=artifact.read_bytes()
            if len(content)==check['bytes'] and sha(content)==check['sha256']:matches.append(artifact)
    assert len(matches)==1,(check,matches)
    exports.append({'path':str(matches[0]),'plugin':check['plugin'],'format':check['format'],'bytes':check['bytes'],'sha256':check['sha256']})
assert len(exports)==4,exports
mandatory=['FRONTEND-NPM-CI','FRONTEND-FULL-TEST','FRONTEND-BUILD','FRONTEND-NPM-AUDIT','P7-PYTHON','P7-CATALOGUE','P7-EQUIVALENCE','P7-GENERATOR-R2','P7-CORPUS','P7-RELOCATION','P7-SECURITY-FLOOR','P7-NATIVE','P7-PORTABLE','P7-STRICT','P7-STRICT-NATIVE','P7-NATIVE-RELEASE','P7-TSAN','P7-PURE-IQ','P7-CLEAN-WORKER','P7-FRAMING','P7-CURRENT-PROCESS','RUST-FULL','RUST-FEATURE-R2','RUST-CLIPPY','RUST-RELEASE','P7-OSV-LOCK']
results=json.loads((TASK/'results.json').read_text())
lookup={row['id']:row for row in results}
assert len(mandatory)==26
assert all(lookup[name]['exit']==0 for name in mandatory)
for row in results:
    data=Path(row['log']).read_bytes()
    assert sha(data)==row['logSHA256'] and len(data)==row['logBytes']
processes=subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines()
remaining=[line for line in processes if str(STAGE) in line or any(str(TASK/name) in line for name in ['swift_checks.py','rust_checks.py','frontend_validation.py','query_osv.py'])]
assert not remaining,remaining
receipt={'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':baseline['head'],'sourceInputsUnchanged':len(manifest),'historicalReportsUnchanged':len(baseline['reports']),'originalNodeModulesInode':baseline['nodeModulesInode'],'originalCWNativeInode':baseline['cwNativeInode'],'originalDistFilesMatching':len(dist),'privateProcessDatabases':databases,'verifiedExports':exports,'standardCompletedExit0Commands':mandatory,'validatedCommandReceipts':len(results),'remainingTaskBuildTestWorkerProcesses':remaining,'boundary':'Read-only fixture checks under named phase7 roots only; no production data, GUI, account, credential, externalhardware or RF acceptance. Advisory command completion is not a vulnerability-free verdict.'}
(TASK/'preservation-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in {'privateProcessDatabases','verifiedExports','standardCompletedExit0Commands'}},indent=2))
print('private process databases',len(databases),'verified exports',len(exports),'standard exit0commands',len(mandatory))
