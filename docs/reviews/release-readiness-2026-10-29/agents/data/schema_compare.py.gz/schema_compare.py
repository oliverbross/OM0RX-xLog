from pathlib import Path
import gzip,hashlib,json,re,xml.etree.ElementTree as ET
root=Path('/Users/oliver/Documents/Projects/OM0RX-xLog');out=Path(__file__).parent
source=(root/'prototype/src/live/adifTransfer.ts').read_text()
names=set(re.search(r'const standardADXFields = new Set\(`(.*?)`\.split',source,re.S).group(1).split())
data=gzip.decompress((root/'prototype/tests/fixtures/adx317.xsd.gz').read_bytes())
schema=ET.fromstring(data);ns={'x':'http://www.w3.org/2001/XMLSchema'}
record=next(x for x in schema.findall('.//x:element',ns) if x.attrib.get('name')=='RECORD')
expected={x.attrib['name'] for x in record.findall('.//x:element',ns)}-{'APP','USERDEF'}
result={'sourceCount':len(names),'schemaCount':len(expected),'missing':sorted(expected-names),'extra':sorted(names-expected),'schemaSHA256':hashlib.sha256(data).hexdigest()}
assert names==expected,result
(out/'schema-compare-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
