from pathlib import Path
from collections import Counter, defaultdict
import hashlib, json, sqlite3, sys
root=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
task=Path('/tmp/xlog-phase7-20261029-b8926639')
out=task/'agents/data'
catalog=json.loads((task/'all-contests-readiness.json').read_text())
counts=Counter(check['status'] for row in catalog['plugins'] for check in row['checks'].values())
summary={'source':catalog['source'],'catalogueCount':catalog['catalogueCount'],'familyTestsRun':catalog['familyTestsRun'],'familyTestsPassed':catalog['familyTestsPassed'],'fixtureCache':catalog['fixtureCache'],'checkCounts':dict(counts),'plugins':[]}
for row in catalog['plugins']:
    summary['plugins'].append({'pluginID':row['pluginID'],'checkCounts':dict(Counter(v['status'] for v in row['checks'].values())),'multiplierViewStatus':row.get('multiplierViewStatus'),'analyticsCapabilities':row.get('analyticsCapabilities'),'catalogue':row['catalogue']})
(out/'catalogue-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
receipts=[]
for path in sorted((task/'checks').glob('P7-*.json')):
    if path.name.endswith('-running.json'):continue
    if path.stem in {'P7-NATIVE','P7-PORTABLE','P7-WORKER','P7-STRICT'}:continue
    row=json.loads(path.read_text())
    if row.get('id','').startswith(('P7-PYTHON','P7-CATALOGUE','P7-EQUIVALENCE','P7-GENERATOR','P7-CORPUS','P7-RELOCATION','P7-SECURITY-FLOOR','P7-FA013','P7-DATA-INTEGRITY','P7-ADX-SCHEMA')):
        receipts.append(row)
(out/'command-results.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps({'catalogueCount':summary['catalogueCount'],'familyTestsRun':summary['familyTestsRun'],'familyTestsPassed':summary['familyTestsPassed'],'fixtureCache':summary['fixtureCache'],'checkCounts':summary['checkCounts'],'multiplierViewStatus':dict(Counter(str(row.get('multiplierViewStatus')) for row in catalog['plugins'])),'analyticsKeys':sorted({key for row in catalog['plugins'] for key in row.get('analyticsCapabilities',{})})},indent=2))
if '--integrity' in sys.argv:
    rows=[]
    paths=sorted((out/'runtime').rglob('*.sqlite'))
    assert len(paths)==2,paths
    for path in paths:
        original=path.read_bytes()
        with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as db:
            integrity=[r[0] for r in db.execute('PRAGMA integrity_check')]
            foreign=[list(r) for r in db.execute('PRAGMA foreign_key_check')]
            tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
            versions={'user_version':db.execute('PRAGMA user_version').fetchone()[0],'schema_version':db.execute('PRAGMA schema_version').fetchone()[0]}
        assert integrity==['ok'] and not foreign,(path,integrity,foreign)
        assert path.read_bytes()==original,path
        rows.append({'path':str(path),'integrity':integrity,'foreignKeyViolations':foreign,'unchanged':True,'sha256':hashlib.sha256(original).hexdigest(),'tables':tables,**versions})
    result={'status':'PASS','count':len(rows),'scope':'Fresh disposable actual-Host master/client databases only; read-only SQLite queries; no production data','databases':rows}
    (out/'disposable-db-integrity.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
