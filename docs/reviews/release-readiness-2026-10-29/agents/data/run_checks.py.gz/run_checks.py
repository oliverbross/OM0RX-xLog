from pathlib import Path
import sys
sys.path.insert(0, '/tmp/xlog-phase7-20261029-b8926639')
from run_check import run_check
name = sys.argv[1]
task=Path('/tmp/xlog-phase7-20261029-b8926639')
checks={
 'P7-PYTHON':['/opt/homebrew/bin/python3.12','-B','-m','unittest','discover','-s','python/tests','-v'],
 'P7-CATALOGUE':['/opt/homebrew/bin/python3.12','-B','tools/check_all_contests_readiness.py','--family-tests','--output',str(task/'all-contests-readiness.json')],
 'P7-EQUIVALENCE':['/opt/homebrew/bin/python3.12','-B','tools/check_contest_append_equivalence.py'],
 'P7-GENERATOR':['/opt/homebrew/bin/python3.14','-B','-m','unittest','discover','-s','tools/contest_plugin_generator/tests','-v'],
 'P7-CORPUS':['/opt/homebrew/bin/python3.14','-B','tools/contest_plugin_generator/verify_pinned_corpus.py','--upstream','/Users/oliver/Documents/Projects/contest-sw','--ledger','docs/contesting/contest-acceptance-ledger.json','--inventory','docs/contesting/generated/python-plugin-inventory.json'],
 'P7-RELOCATION':['/opt/homebrew/bin/python3.12','-B','prototype/scripts/test-contest-python-relocation.py','-v'],
 'P7-SECURITY-FLOOR':['/opt/homebrew/bin/python3.12','-B','tools/check_reviewed_security_patches.py'],
 'P7-FA013':['/opt/homebrew/bin/python3.12','-B',str(task/'agents/data/probe_country_reconcile.py')],
}
sys.exit(run_check(name, checks[name]))
