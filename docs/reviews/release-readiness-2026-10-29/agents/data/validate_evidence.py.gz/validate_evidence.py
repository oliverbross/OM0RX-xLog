from pathlib import Path
from collections import Counter
import hashlib,json,re
task=Path('/tmp/xlog-phase7-20261029-b8926639');out=task/'agents/data'
receipts=json.loads((out/'command-results.json').read_text())
assert len(receipts)==11,len(receipts)
assert len({r['id'] for r in receipts})==11
for row in receipts:
    assert row['sourceHeadStart']==row['sourceHeadEnd']=='b892663915cbc0768b26dc5a7bf7ec116869e409',row['id']
    assert row['sourceDiffSHA256']=='e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',row['id']
    log=Path(row['log']).read_bytes()
    assert len(log)==row['logBytes'] and hashlib.sha256(log).hexdigest()==row['logSHA256'],row['id']
    assert row['exit']==(1 if row['id']=='P7-GENERATOR' else 0),row['id']
    assert not row['timedOut'],row['id']
dimensions=json.loads((out/'catalogue-dimensions.json').read_text())
assert len(dimensions)==len({r['pluginID'] for r in dimensions})==97
assert sum(r['countryMultiplierView']=='UNVERIFIED' for r in dimensions)==26
assert sum(r['zoneMultiplierView']=='UNVERIFIED' for r in dimensions)==10
assert sum('UNVERIFIED' in (r['countryMultiplierView'],r['zoneMultiplierView']) for r in dimensions)==27
country=json.loads((out/'country-reconcile-result.json').read_text())
assert country['errorCode']=='invalid_request' and country['replicaUnchanged'] is True
integrity=json.loads((out/'disposable-db-integrity.json').read_text())
assert integrity['count']==2 and all(r['integrity']==['ok'] and r['foreignKeyViolations']==[] and r['unchanged'] for r in integrity['databases'])
schema=json.loads((out/'schema-compare-result.json').read_text())
assert schema['sourceCount']==schema['schemaCount']==179 and not schema['missing'] and not schema['extra']
assert (out/'VALIDATION.md').exists()
result={'status':'PASS','receiptCount':len(receipts),'receiptHashesAndSourcesVerified':True,'retainedSetupFailures':1,'qualifiedRetry':1,'dimensionRows':97,'countryViewsUnverified':26,'zoneViewsUnverified':10,'pluginsWithUnimplementedViews':27,'actualHostCounterexampleReproduced':True,'integrityDBs':2,'schemaNames':179,'compatibilityRows':len(json.loads((out/'migration-data-config-compatibility.json').read_text()))}
(out/'evidence-qa.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
