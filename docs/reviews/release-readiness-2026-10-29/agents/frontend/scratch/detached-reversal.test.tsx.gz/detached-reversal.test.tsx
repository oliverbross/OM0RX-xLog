// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { act,cleanup,fireEvent,render,screen } from '@testing-library/react';
import { DetachedQSOSurface,detachedQSOJournalKey } from '/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/DetachedQSOSurface';
const api=vi.hoisted(()=>({draft:vi.fn(),read:vi.fn(),changes:vi.fn(),protect:vi.fn()}));
vi.mock('/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/operatorDraftTransport',()=>({requestOperatorDraft:api.draft}));
vi.mock('/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/worker',()=>({workerRequest:api.read}));
vi.mock('/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/operatorDraftWindows',()=>({connectOperatorDraftChanges:api.changes,protectOperatorDraftClose:api.protect}));
vi.mock('/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src/live/useSpotEditor',()=>({nativeSpotEditor:()=>false,useSpotEditor:()=>({status:null,error:'',reconcile:vi.fn()})}));
vi.mock('@tauri-apps/api/core',()=>({isTauri:()=>false,invoke:vi.fn()}));
const initial={id:'ffffffff-aaaa-4bbb-8ccc-123456789abc',call:'K1ABC',start:'2026-10-20T10:15:30Z',end:null,band:'20m',mode:'CW',frequencyHz:14_025_000,rstSent:'599',rstReceived:'599',extraFields:{}};
beforeEach(()=>{
 localStorage.clear();vi.resetAllMocks();
 api.changes.mockImplementation(refresh=>{void refresh();return vi.fn();});api.protect.mockReturnValue(vi.fn());
 api.read.mockImplementation(async(method,params)=>({result:method==='lookup_call'?{call:params.call}:method==='logbook_previous'?{qsos:[]}:{cells:[]}}));
});
afterEach(()=>{cleanup();vi.useRealTimers();});
it.each(['rapid','blur-and-wait','remount-control'])('Full reversed UTC display/save agreement after %s, with real session and native semantics emulated',async path=>{
 let current:any={generation:'f1111111-2222-4333-9444-555555555555',revision:0,qso:structuredClone(initial),automaticStart:true};
 const contacts:any[]=[],mutations:any[]=[];
 api.draft.mockImplementation(async(method,params)=>{
  if(method==='logbook_operator_draft')return {draft:structuredClone(current)};
  if(method==='logbook_operator_draft_receipt')return {receipt:null};
  mutations.push(params);const savedQSO=params.action==='save'?structuredClone(current.qso):null;
  if(savedQSO&&current.automaticStart)savedQSO.start=new Date().toISOString();
  if(savedQSO)contacts.push(savedQSO);
  const qso=params.action==='replace'?structuredClone(params.qso):{...initial,id:crypto.randomUUID(),call:''};
  const automaticStart=params.action!=='replace'||current.automaticStart&&Date.parse(qso.start)===Date.parse(current.qso.start)&&(qso.end??null)===(current.qso.end??null);
  current={...current,qso,automaticStart,revision:current.revision+1};
  return {status:'applied',receipt:{mutation:structuredClone(params),draft:structuredClone(current),savedQSO}};
 });
 render(<DetachedQSOSurface/>);await screen.findByDisplayValue('K1ABC');
 vi.useFakeTimers();vi.setSystemTime(new Date('2026-10-28T12:34:56Z'));
 const date=screen.getByLabelText('Start UTC date'),time=screen.getByLabelText('Start UTC time');
 fireEvent.change(date,{target:{value:'2026-10-21'}});fireEvent.change(time,{target:{value:'10:15:30'}});fireEvent.change(date,{target:{value:'2026-10-20'}});
 if(path==='blur-and-wait'){fireEvent.blur(date);fireEvent.focus(screen.getByLabelText('Callsign'));await act(async()=>{await vi.advanceTimersByTimeAsync(1500);});}
 if(path==='remount-control'){fireEvent.click(screen.getByRole('button',{name:'Simple'}));fireEvent.click(screen.getByRole('button',{name:'Full'}));}
 const journal=JSON.parse(localStorage.getItem(detachedQSOJournalKey)!);
 const shown={date:(screen.getByLabelText('Start UTC date') as HTMLInputElement).value,time:(screen.getByLabelText('Start UTC time') as HTMLInputElement).value};
 await act(async()=>{fireEvent.click(screen.getByRole('button',{name:'Log QSO'}));});
 console.log(JSON.stringify({path,shown,baseAutomaticStart:journal.base.automaticStart,local:journal.draft,mutations,contacts}));
 expect(contacts).toHaveLength(1);expect(mutations.map(x=>x.action)).toEqual(['save']);
 expect(contacts[0].start.slice(0,10)).toBe(shown.date);
});
