from pathlib import Path
import json
from run_check import ROOT,TASK,run_check

prior=Path('/tmp/xlog-phase5-followup-20261029-fd774aef/query_osv.py')
source=prior.read_text()
assert 'ssl.create_default_context()' in source
(TASK/'query_osv.py').write_text(source)
result=run_check('P7-OSV-LOCK',['/opt/homebrew/bin/python3.12','-B',str(TASK/'query_osv.py')],timeout=600)
(TASK/'security-result.json').write_text(json.dumps({'id':'P7-OSV-LOCK','exit':result,'scope':'Verified TLS registry-version advisory observation; requires maintainer range, target, feature and caller triage'},indent=2)+'\n')
raise SystemExit(result)
