from pathlib import Path
from collections import Counter
import datetime,hashlib,json,re,subprocess
TASK=Path('/tmp/xlog-phase7-20261029-b8926639');OUT=TASK/'agents/platform'
run=json.loads((OUT/'run-final.json').read_text())
jobs=json.loads((OUT/'jobs-final.json').read_text())['jobs']
admission=json.loads((OUT/'dispatch-admission.json').read_text())
expected=admission['expectedHead']
assert run['headSha']==expected and run['databaseId']==40816487097
assert len(jobs)==7 and {j['name'] for j in jobs}==set(admission['expectedJobs'])
summary=[]
for j in jobs:
    assert j['head_sha']==expected and j['status']=='completed'
    job=j['id'];log_receipt=json.loads((OUT/f'{job}-log-receipt.json').read_text())
    annotation_receipt=json.loads((OUT/f'{job}-annotations-receipt.json').read_text())
    assert log_receipt['exit']==0 and annotation_receipt['exit']==0
    assert not annotation_receipt.get('paginationRequired')
    log=(OUT/f'{job}-log.log').read_text()
    annotations=json.loads((OUT/f'{job}-annotations.json').read_text())
    signal=[line for line in log.splitlines() if re.search(r'test result:|Ran \d+ tests|Test run with \d+ tests|Executed \d+ tests?',line)]
    warnings=[line for line in log.splitlines() if re.search(r'\bwarning:|\berror:|##\[warning\]|##\[error\]',line)]
    row={'jobId':job,'name':j['name'],'headSha':j['head_sha'],'status':j['status'],'conclusion':j['conclusion'],'url':j['html_url'],'startedAt':j['started_at'],'completedAt':j['completed_at'],'steps':j['steps'],'stepConclusions':dict(Counter(s['conclusion'] for s in j['steps'])),'skippedSteps':[s['name'] for s in j['steps'] if s['conclusion']=='skipped'],'testResultSignals':signal,'compilerAndRunnerWarningLines':warnings,'annotations':annotations,'annotationCounts':dict(Counter(a['annotation_level'] for a in annotations)),'logReceipt':log_receipt,'annotationReceipt':annotation_receipt}
    row['rustFilteredResults']=[{'passed':int(m[1]),'failed':int(m[2]),'ignored':int(m[3]),'filtered':int(m[4])} for m in re.finditer(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;',log)]
    summary.append(row)
receipts=[json.loads(p.read_text()) for p in sorted((TASK/'checks').glob('P7-*.json')) if not p.name.endswith('-running.json')]
(OUT/'command-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
(OUT/'job-evidence.json').write_text(json.dumps(summary,indent=2)+'\n')
rust=TASK/'agents/rust/VALIDATION.md'
preserve={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'gitStatusPorcelain':subprocess.check_output(['git','status','--porcelain'],text=True),'rustReportExpectedSHA256':admission['rustReportSHA256'],'rustReportCurrentSHA256':hashlib.sha256(rust.read_bytes()).hexdigest(),'workflowExpectedSHA256':admission['workflowSHA256'],'workflowCurrentSHA256':hashlib.sha256(Path('.github/workflows/contest-portability.yml').read_bytes()).hexdigest()}
preserve['rustReportUnchanged']=preserve['rustReportExpectedSHA256']==preserve['rustReportCurrentSHA256']
preserve['workflowUnchanged']=preserve['workflowExpectedSHA256']==preserve['workflowCurrentSHA256']
(OUT/'preservation.json').write_text(json.dumps(preserve,indent=2)+'\n')
lines=['# Phase 7 platform validation','',f"Run [40816487097]({run['url']}) at exact head {expected}: {run['status']} / {run['conclusion']}.",'','Only contest-portability.yml was dispatched, after inspecting its complete current source and verifying origin/main. Dispatch P7-PORTABILITY-DISPATCH exited 0; exact command, expected head/workflow, source heads and timestamps are preserved in the shared receipt. The workflow has contents:read, portable Swift tests, pinned generator/policy tests and isolated Rust contesting-test checks; native config disables bundling and external binaries. No package/release/deploy/prototype workflow was dispatched.','',
'| Job | ID | Conclusion | Successful steps | Skipped steps | Annotations |','| --- | ---: | --- | ---: | ---: | --- |']
for j in summary:
    lines.append(f"| {j['name']} | {j['jobId']} | {j['conclusion']} | {j['stepConclusions'].get('success',0)} | {j['stepConclusions'].get('skipped',0)} | {j['annotationCounts']} |")
lines+=['','Every job has its own head, conclusion, timing, full step list, test signals, warnings, annotations and raw-log fetch receipt in job-evidence.json. Skipped OS-conditional steps remain SKIPPED and are not counted as passes. No job is accepted using another platform result.','',
'Each native OS job executed 24 export, 7 native-admission, 1 passive-read, 16 module, 3 durable-file, 6 restart-intent and 7 EOF/shutdown cases (64 bounded cases per OS). Generator includes 42 generator and 7 dependency-policy tests. Swift jobs run separate filtered XCTest/Swift Testing invocations. Both frameworks can emit zero-test banners while the other executes cases; those banners and duplicate suite aggregate lines are retained, not summed as acceptance. Discovery steps check expected test availability before execution.','',
'Logs are streamed with a 2 MiB full-retention bound per job; oversized logs retain a 128 KiB head and 1 MiB tail plus a complete-stream hash/count. All seven streams were below the bound and saved in full; each receipt verifies complete byte count and hash. Annotation pages contain fewer than 100 entries; no additional page was required.','',
'Observed annotations and compiler/runner warnings are retained rather than suppressed. Action-runtime deprecation warnings and macOS capacity notices do not change successful test conclusions; they remain maintenance evidence. No dependency security assessment beyond the existing reviewed-floor policy and tests is claimed.','',
'These are current automated compatibility/discovery/fixture results. They do not close FA-010 through FA-017, native operator acceptance, real-provider credentials, production data, physical hardware or RF acceptance. No source/test/config fixes, unrelated fixture reruns, packaging, installation or live station operation was performed.','',
f"Preservation: local HEAD {preserve['head']}; Git status {preserve['gitStatusPorcelain'].strip() or 'clean'}; Rust report unchanged {preserve['rustReportUnchanged']}; workflow unchanged {preserve['workflowUnchanged']}. Exact hashes are in preservation.json. No earlier Rust evidence was rewritten.",'']
(OUT/'VALIDATION.md').write_text('\n'.join(lines))
assert preserve['rustReportUnchanged'] and preserve['workflowUnchanged']
index={}
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name!='artifact-index.json':
        raw=path.read_bytes();index[path.name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(OUT/'artifact-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'run':run['url'],'head':expected,'conclusion':run['conclusion'],'jobs':[{'name':j['name'],'conclusion':j['conclusion'],'annotations':j['annotationCounts'],'logBytes':j['logReceipt']['streamBytes'],'fullLogSaved':j['logReceipt']['fullStreamSaved']} for j in summary],'preservation':preserve},indent=2))
