from pathlib import Path
import datetime, hashlib, json, subprocess

ROOT=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
TASK=Path('/tmp/xlog-phase7-20261029-b8926639')
STAGE=ROOT/'.build/phase7-validation-20261029-b8926639'
sha=lambda value:hashlib.sha256(value).hexdigest()
assert not STAGE.exists(), 'Use a new clean build root; never delete an old one'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='b892663915cbc0768b26dc5a7bf7ec116869e409'
assert subprocess.check_output(['git','rev-parse','origin/main'],cwd=ROOT,text=True).strip()==head
STAGE.mkdir(parents=True)
prior=json.loads((ROOT/'docs/reviews/final-code-audit-followup-2026-10-29/source-sha256.json').read_text())
assert all(sha((ROOT/path).read_bytes())==digest for path,digest in prior.items())
(TASK/'source-sha256.json').write_text(json.dumps(prior,indent=2)+'\n')
reports=['CODE_REVIEW.md','REVIEW_COVERAGE.md','REMEDIATION_TRACKER.md','REGRESSION_TEST_REPORT.md','STABILITY_REPORT.md','FINAL_CODE_AUDIT.md']
baseline={'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'applicationSource':'f3f6e3dee40af29cb6801ef8ee422c521629e168','initialClean':True,'FFMainChecked':True,'sourceInputs':len(prior),'reports':{path:sha((ROOT/path).read_bytes()) for path in reports},'nodeModulesInode':(ROOT/'prototype/node_modules').stat().st_ino,'cwNativeInode':(ROOT/'.build/cw-native').stat().st_ino,'distHashes':{str(path.relative_to(ROOT/'prototype/dist')):sha(path.read_bytes()) for path in (ROOT/'prototype/dist').rglob('*') if path.is_file()},'buildRootInitiallyAbsent':True,'stage':str(STAGE),'scope':'Validation/report only; no source or test edits, production data, GUI launch, live provider, hardware, RF or deployment'}
(TASK/'baseline.json').write_text(json.dumps(baseline,indent=2)+'\n')
for label,base in [('all-remediation','530de4c4e4b23281ec60585cc7a2e5ca011476fb'),('followup','fd774aef41f196e5f3b7da627a1b221af6594ba7')]:
    args=['git','diff',base,head,'--','Sources','Tests','prototype','python','native','tools','scripts','.github','Package.swift','Package.resolved']
    (TASK/(label+'.diff')).write_bytes(subprocess.check_output(args,cwd=ROOT))
    (TASK/(label+'-paths.json')).write_text(json.dumps(subprocess.check_output(args[:2]+['--name-only']+args[2:],cwd=ROOT,text=True).splitlines(),indent=2)+'\n')
print(json.dumps({k:v for k,v in baseline.items() if k not in ['reports','distHashes']},indent=2))
