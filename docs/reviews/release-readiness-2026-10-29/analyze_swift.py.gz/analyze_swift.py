from pathlib import Path
import collections,json,re
from run_check import TASK

ansi=re.compile(r'\x1b\[[0-9;]*m')
osc=re.compile(r'\x1b\][^\x1b]*(?:\x07|\x1b\\)')
results=[]
for name in ['P7-NATIVE','P7-PORTABLE','P7-STRICT','P7-STRICT-NATIVE','P7-NATIVE-RELEASE','P7-TSAN','P7-PURE-IQ','P7-CLEAN-WORKER']:
    lines=osc.sub('',ansi.sub('',(TASK/'checks'/(name+'.log')).read_text(errors='replace'))).splitlines()
    groups=[];summaries=[];diagnostics=[];skips=[];errors=[]
    for index,line in enumerate(lines):
        if "Test Suite 'All tests' passed" in line or "Test Suite 'Selected tests' passed" in line:
            match=re.search(r'Executed (\d+) tests?, with (?:(\d+) tests? skipped and )?(\d+) failures?',lines[index+1])
            assert match,(name,line,lines[index+1])
            groups.append({'tests':int(match[1]),'skipped':int(match[2] or 0),'failures':int(match[3])})
        match=re.search(r'Test run with (\d+) tests? in (\d+) suites? passed',line)
        if match:summaries.append({'tests':int(match[1]),'suites':int(match[2])})
        match=re.match(r'(.+?):(\d+):(\d+): warning: (.*)',line)
        if match:diagnostics.append({'path':match[1],'line':int(match[2]),'column':int(match[3]),'message':match[4]})
        if re.search(r'^(?:➜ Test|Test Case).*\bskipped\b',line):skips.append(line)
        if re.match(r'.+?:\d+:\d+: error:',line):errors.append(line)
    unique=list({(row['path'],row['line'],row['column'],row['message']):row for row in diagnostics}.values())
    row={'id':name,'xctestTopLevelGroups':groups,'xctestTotal':sum(g['tests'] for g in groups),'xctestSkips':sum(g['skipped'] for g in groups),'swiftTestingGroups':summaries,'swiftTestingSummaryTotal':sum(g['tests'] for g in summaries),'sourceWarningHeaders':len(diagnostics),'uniqueSourceWarnings':unique,'skipLines':skips,'sourceErrors':errors}
    results.append(row)
    print(json.dumps({'id':name,'XCTest':row['xctestTotal'],'XCTestSkips':row['xctestSkips'],'SwiftTestingSummary':row['swiftTestingSummaryTotal'],'SwiftTestingGroups':summaries,'sourceWarningHeaders':len(diagnostics),'uniqueSourceWarnings':len(unique),'sourceErrors':len(errors),'skipLines':len(skips)}))
(TASK/'swift-qualification.json').write_text(json.dumps(results,indent=2)+'\n')
for row in results:
    if row['id'] in ['P7-STRICT','P7-STRICT-NATIVE']:
        print('STRICT WARNING MESSAGES',json.dumps(dict(collections.Counter(w['message'] for w in row['uniqueSourceWarnings'])),indent=2))
    if row['id'] in ['P7-NATIVE','P7-PORTABLE']:
        print(row['id'],'SKIPS',json.dumps(row['skipLines'],indent=2))
