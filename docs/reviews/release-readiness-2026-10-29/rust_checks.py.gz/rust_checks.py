from pathlib import Path
import json,sys,time
sys.path.insert(0,'/tmp/xlog-phase7-20261029-b8926639')
from run_check import run_check
task=Path('/tmp/xlog-phase7-20261029-b8926639')
root=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
cwd=root/'prototype/src-tauri'
env={'CARGO_TARGET_DIR':str(root/'.build/phase7-validation-20261029-b8926639/rust')}
dummy=dict(env,XLOG_TEST_RIGCTLD='/opt/homebrew/bin/rigctld',XLOG_TEST_ROTCTLD='/opt/homebrew/bin/rotctld')
run_check('RUST-FEATURE',['cargo','test','--locked','--jobs','2','--bin','xlog-prototype','--features','contesting-test'],cwd,env,3600)
run_check('RUST-HAMLIB-DUMMY',['cargo','test','--locked','--jobs','2','--test','hamlib_dummy','--','--nocapture'],cwd,dummy,900)
run_check('RUST-TWO-SLOT-DUMMY',['cargo','test','--locked','--jobs','2','--bin','xlog-prototype','station_session::tests::opt_in_two_slot_saved_profiles_connect_real_bundled_dummy_receivers_independently','--','--exact','--nocapture'],cwd,dummy,900)
run_check('RUST-CLIPPY',['cargo','clippy','--locked','--jobs','2','--all-targets'],cwd,env,3600)
run_check('RUST-RELEASE',['cargo','build','--locked','--release','--jobs','2'],cwd,env,3600)
