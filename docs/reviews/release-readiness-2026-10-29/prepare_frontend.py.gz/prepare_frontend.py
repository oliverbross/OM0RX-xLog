import hashlib,json,shutil,sys
from pathlib import Path
from run_check import ROOT,TASK,STAGE,run_check
deps=STAGE/'frontend-deps'
assert not deps.exists()
deps.mkdir(parents=True)
for name in ['package.json','package-lock.json']:
    shutil.copyfile(ROOT/'prototype'/name,deps/name)
sys.exit(run_check('FRONTEND-NPM-CI',['npm','ci'],deps,timeout=600))
