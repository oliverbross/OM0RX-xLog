import hashlib,json,re
from run_check import ROOT,TASK,STAGE
out=TASK/'agents/frontend'
ids=['FRONTEND-NPM-CI','FRONTEND-TOOLCHAIN','FRONTEND-FULL-TEST','FRONTEND-BUILD','FRONTEND-NPM-AUDIT','FRONTEND-FA014-FORMS','FRONTEND-FA014-DETACHED','FRONTEND-FA017-STOP']
results=[]
for name in ids:
    receipt=json.loads((TASK/'checks'/(name+'.json')).read_text())
    log=TASK/'checks'/(name+'.log')
    assert hashlib.sha256(log.read_bytes()).hexdigest()==receipt['logSHA256']
    plain=re.sub(r'\x1b\[[0-9;]*m','',log.read_text())
    summaries=[line for line in plain.splitlines() if re.match(r'\s*(?:Test Files|Tests|Duration|ℹ tests|ℹ pass|ℹ fail|ℹ skipped)',line)]
    results.append({'id':name,'exit':receipt['exit'],'seconds':receipt['seconds'],'timedOut':receipt['timedOut'],'summaries':summaries,'logSHA256':receipt['logSHA256'],'sourceHeadStart':receipt['sourceHeadStart'],'sourceHeadEnd':receipt['sourceHeadEnd'],'sourceDiffSHA256':receipt['sourceDiffSHA256']})
    (out/(name+'.plain.log')).write_text(plain)
build=(out/'FRONTEND-BUILD.plain.log').read_text()
windows=[json.loads(line) for line in build.splitlines() if line.startswith('{"window":')]
for item in windows:
    name=item['window'];item['budget']=1600000 if name in ['WorldMap','DXpeditionMap','Monitor'] else 400000 if name=='BandMaps' else 408000 if name=='Settings' else 407000 if name=='QSO' else 405200 if name=='Logbook' else 401000
    item['headroom']=item['budget']-item['bytes']
(out/'results.json').write_text(json.dumps({'checks':results,'bundleWindows':windows,'preservation':json.loads((out/'preservation.json').read_text()),'toolchain':json.loads((TASK/'checks/FRONTEND-TOOLCHAIN.log').read_text()),'audit':json.loads((TASK/'checks/FRONTEND-NPM-AUDIT.log').read_text())},indent=2)+'\n')
print(json.dumps({'checks':results,'bundleWindows':[{k:v for k,v in item.items() if k!='files'} for item in windows],'preservation':json.loads((out/'preservation.json').read_text())},indent=2))
