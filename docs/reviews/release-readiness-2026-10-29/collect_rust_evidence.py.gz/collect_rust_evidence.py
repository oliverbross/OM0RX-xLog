from pathlib import Path
from collections import Counter
import hashlib,json,re,subprocess
ROOT=Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
TASK=Path('/tmp/xlog-phase7-20261029-b8926639')
OUT=TASK/'agents/rust'
OUT.mkdir(parents=True,exist_ok=True)
IDS=['RUST-FULL','RUST-FEATURE-R2','RUST-HAMLIB-DUMMY','RUST-TWO-SLOT-DUMMY','RUST-CLIPPY','RUST-RELEASE']
results=[]
warnings={}
for name in IDS:
    receipt=json.loads((TASK/'checks'/f'{name}.json').read_text())
    raw=(TASK/'checks'/f'{name}.log').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==receipt['logSHA256'],name
    log=raw.decode()
    tests=[]
    for m in re.finditer(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log):
        tests.append(dict(zip(['status','passed','failed','ignored','measured','filtered'],[m[1],*[int(m[i]) for i in range(2,7)]])))
    headers=[line for line in log.splitlines() if line.startswith('warning:')]
    diagnostics=[line for line in headers if not line.startswith('warning: '+chr(96)+'xlog-prototype'+chr(96))]
    warnings[name]={'diagnosticCount':len(diagnostics),'diagnosticHeaders':dict(Counter(diagnostics)),'compilerSummaries':[line for line in headers if line not in diagnostics],'clippyHelpCategories':dict(Counter(re.findall(r'rust-clippy/[^\s]*#([a-z_]+)',log)))}
    results.append({**receipt,'testResults':tests,'warningDiagnosticCount':len(diagnostics)})
(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(OUT/'warnings.json').write_text(json.dumps(warnings,indent=2)+'\n')
baseline=json.loads((TASK/'source-sha256.json').read_text())
mismatches=[]
for path,expected in baseline.items():
    file=ROOT/path
    actual=hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None
    if actual!=expected:mismatches.append({'path':path,'expected':expected,'actual':actual})
preservation={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'gitStatusPorcelain':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),'baselineInputCount':len(baseline),'mismatches':mismatches,'cargoInputs':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['prototype/src-tauri/Cargo.toml','prototype/src-tauri/Cargo.lock']},'helpers':{p:{'resolvedPath':str(Path(p).resolve()),'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in ['/opt/homebrew/bin/rigctld','/opt/homebrew/bin/rotctld']},'targetDirectory':str(ROOT/'.build/phase7-validation-20261029-b8926639/rust'),'originalTargetCachesCleaned':False}
binary=ROOT/'.build/phase7-validation-20261029-b8926639/rust/release/xlog-prototype'
preservation['releaseBinary']={'path':str(binary),'bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'executed':False}
(OUT/'preservation.json').write_text(json.dumps(preservation,indent=2)+'\n')
orphan=TASK/'checks/RUST-FEATURE.log'
orphan_record={'id':'RUST-FEATURE','status':'INCOMPLETE_RUNNER','reason':'Detached CLI driver disappeared before receipt finalization; log displays 931 passing tests but lacks completed receipt. RUST-FEATURE-R2 supersedes it.','log':str(orphan),'logBytes':orphan.stat().st_size,'logSHA256':hashlib.sha256(orphan.read_bytes()).hexdigest(),'runningMarker':json.loads((TASK/'checks/RUST-FEATURE-running.json').read_text())}
(OUT/'orphan-feature.json').write_text(json.dumps(orphan_record,indent=2)+'\n')
rows=[]
for r in results:
    tests='; '.join(f"{x['passed']} passed, {x['failed']} failed, {x['ignored']} ignored, {x['filtered']} filtered" for x in r['testResults']) or 'completed; warnings retained'
    rows.append(f"| {r['id']} | {r['exit']} | {r['seconds']} | {tests} | {' '.join(r['command'])} |")
(OUT/'commands-table.md').write_text('| Check | Exit | Seconds | Result | Exact command |\n| --- | ---: | ---: | --- | --- |\n'+'\n'.join(rows)+'\n')
print(json.dumps({'checks':[(r['id'],r['exit'],r['seconds'],r['testResults']) for r in results],'preservedInputs':len(baseline),'mismatches':len(mismatches),'warnings':{n:r['diagnosticCount'] for n,r in warnings.items()}},indent=2))
assert not mismatches,mismatches


intro="""# Rust and native shell validation

Canonical main b892663915cbc0768b26dc5a7bf7ec116869e409; unchanged application inputs f3f6e3dee40af29cb6801ef8ee422c521629e168, version 1.3.60. No checkout source/test/config/dependency/report edits or Git commits.

All checks use cwd /Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src-tauri and the new CARGO_TARGET_DIR=/Users/oliver/Documents/Projects/OM0RX-xLog/.build/phase7-validation-20261029-b8926639/rust. The first full test compiled dependencies there; later checks reuse that target only. The shared runner strips inherited XLOG_/XCW_ opt-ins, selects explicit test Python/private temp paths and denies contest UDP. Original targets were not cleaned.

"""
body="""
Exact commands, UTC boundaries, source heads, empty diffs, environments and raw-log hashes are in results.json and ../../checks/<ID>.json. Counts overlap across configurations/reruns.

## Discovery and dummy scope

Default harness: 924 unit +31 integration; feature binary: 931. No reported ignored tests. Two default cases silently return without Hamlib opt-in (tests/hamlib_dummy.rs:39-45 and src/station_session.rs:1054-1055). Feature includes the latter and excludes the separate integration target. Target cfg exclusions remain outside this macOS run. Raw pass totals alone therefore do not prove daemon integration.

The explicit 31-case dummy run and selected two-slot unit case exercised model 1 backends on local ephemeral ports/private temp JSON, allow_transmit=false, PTT-on rejection and owned cleanup. They used installed /opt/homebrew/bin/{rigctld,rotctld}, whose hashes are in preservation.json, not staged packaged helpers. This establishes local dummy protocol/session behavior only. No real provider/station, physical hardware, native GUI, audio capture, RF, bundle, installation or packaged-helper acceptance was attempted.

Original RUST-FEATURE displays 931 passing tests but its detached driver disappeared before receipt finalization; cause unproven. It is INCOMPLETE_RUNNER in orphan-feature.json, superseded by completed R2. Earlier foreground driver explicitly hit lean-ctx 120s cap before feature started. Tool failures and unsuccessful runner attempts remain in tooling-notes.json. No application failure was reclassified as flaky; no assertion changed.

## Warnings

warnings.json preserves every emitted header, compiler summary and Clippy category. Full test: 14 dead-code/unused diagnostics (9 integration, 5 binary). Clippy: 10 integration + 32 binary + 46 test warnings, with 26 duplicates (= 62 emitted headers), including style/complexity, needless borrows/clones, guarded unnecessary unwrap and constant assertion. Exit 0 uses existing lint policy, not warnings-as-errors. No suppression or fix applied. Release emitted 5 diagnostics; the dummy integration emitted 14; accepted feature and selected two-slot runs emitted none.

## Safety and remaining findings

coverage.json lists actual passed role/admission/profile/module/shutdown case names. Existing passed tests cover closed surface capabilities/raw-device denial, role/isolation/shutdown guards, operating-module admission, runtime external-I/O denial and seven native feature-admission cases. The seven shutdown fixtures cover EOF drain/synthetic release, watchdog deadline, nonzero child, spot/station failure translation, unsolicited EOF, missing reply and malformed final reply (worker.rs:2562-2672).

- FA-010 remains open: fldigi acquisition routing tests do not inject a settings-write failure before production RX.
- FA-011 remains open: synthetic StationReleaseFailure/exit 74 translation does not exercise swallowed production direct-agent release errors through registry/worker.
- FA-012 remains open: Rust checks do not exercise Swift connect-before-registration/install-during-connect/reconnect schedules.

Fixture passes cannot close those production mechanisms or prove physical release.

## CI and preservation

prototype.yml:163-182 separately runs locked contracts and staged-helper dummy integration; contest-portability.yml:364-416 discovers/runs bounded feature export/admission/passive/module/durable/restart/shutdown cases. This is workflow-source inspection, not current CI or Windows/Linux acceptance. Locked inputs are unchanged; no fresh external security/advisory scan is claimed. Blocked cargo-audit/custom Swift executables were not retried or wrapped.

"""
ending=f"Preservation: {len(baseline)} baseline inputs checked; {len(mismatches)} mismatches; Git status {preservation['gitStatusPorcelain'].strip() or 'clean'}. Every completed receipt begins/ends at b8926639 with empty source diff. Cargo input/helper hashes are in preservation.json. All build trees/evidence retained; no cargo clean, packaging, installation or deletion.\n"
(OUT/'VALIDATION.md').write_text(intro+(OUT/'commands-table.md').read_text()+'\n'+body+ending)
