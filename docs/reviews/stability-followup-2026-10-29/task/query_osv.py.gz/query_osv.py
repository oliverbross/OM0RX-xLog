import concurrent.futures, datetime, json, pathlib, ssl, tomllib, urllib.request
from run_check import ROOT, TASK
output=TASK/'osv'; output.mkdir(exist_ok=True)
packages=[p for p in tomllib.loads((ROOT/'prototype/src-tauri/Cargo.lock').read_text())['package'] if p.get('source','').startswith('registry+')]
queries=[{'package':{'name':p['name'],'ecosystem':'crates.io'},'version':p['version']} for p in packages]
results=[]
context=ssl.create_default_context()
for offset in range(0,len(queries),100):
    body=json.dumps({'queries':queries[offset:offset+100]}).encode()
    request=urllib.request.Request('https://api.osv.dev/v1/querybatch',data=body,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=45,context=context) as response:
        batch=json.load(response)['results']
    assert len(batch)==len(queries[offset:offset+100])
    results.extend(batch)
matches=[{'package':p['name'],'version':p['version'],'vulnerabilities':result.get('vulns',[])}
         for p,result in zip(packages,results) if result.get('vulns')]
ids=sorted({v['id'] for row in matches for v in row['vulnerabilities']})
def detail(identifier):
    with urllib.request.urlopen('https://api.osv.dev/v1/vulns/'+identifier,timeout=45,context=context) as response:
        value=json.load(response)
    (output/(identifier+'.json')).write_text(json.dumps(value,indent=2)+'\n')
    return identifier
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    assert sorted(executor.map(detail,ids))==ids
receipt={'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'queriedVersions':len(packages),
 'endpoint':'https://api.osv.dev/v1/querybatch','tlsVerification':'Default certificate and hostname verification enabled',
 'matches':matches,'advisoryIDs':ids,'boundary':'Version matches require affected-range, feature, target and caller triage; not established application exploits.'}
(output/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
