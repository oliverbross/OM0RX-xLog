import hashlib,json,subprocess
from run_check import ROOT,TASK
final=json.loads((TASK/'final-source.json').read_text())['head']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only',final,head],cwd=ROOT,text=True).splitlines()
allowed={'STABILITY_REPORT.md','REMEDIATION_TRACKER.md','REVIEW_COVERAGE.md'}
assert all(p in allowed or p.startswith('docs/reviews/stability-followup-2026-10-29/') for p in changed),changed
source=json.loads((TASK/'final-source-sha256.json').read_text())
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in source.items())
status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
assert not status,status
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=ROOT,text=True).split()[0]
assert remote==head,(remote,head)
dest=ROOT/'docs/reviews/stability-followup-2026-10-29'
for line in (dest/'SHA256SUMS').read_text().splitlines():
    expected,name=line.split('  ',1)
    assert hashlib.sha256((dest/name).read_bytes()).hexdigest()==expected,name
print(json.dumps({'applicationSource':final,'documentationHead':head,'originMain':remote,'workingTreeClean':True,'unchangedApplicationInputs':len(source),'archiveSHA256SUMS':'all match','changesSinceApplicationSource':'reports/evidence only'},indent=2))
