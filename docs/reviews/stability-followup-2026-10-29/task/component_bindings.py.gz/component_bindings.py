import hashlib,io,json,subprocess,tarfile
from run_check import ROOT,TASK
paths=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
specs=[
 ('Python and tools','e15c6008',('python/','tools/'),['FULL-PYTHON','ALL-CONTESTS','APPEND-EQUIVALENCE','GENERATOR','PYTHON-RELOCATION']),
 ('Rust/native inputs','9a003a2b',('prototype/src-tauri/','native/'),['FULL-RUST','FEATURE-RUST','CLIPPY','RUST-RELEASE']),
 ('Complete frontend/worker fixture inputs','fd2fc49e',('prototype/',),['CLOSE-FRONTEND','CLOSE-FRONTEND-BUILD']),
]
rows=[]
for label,commit,prefixes,checks in specs:
    names=[p for p in paths if p and p.startswith(prefixes)]
    matched=[]
    # One immutable Git archive per component avoids thousands of subprocesses.
    raw=subprocess.check_output(['git','archive',commit,'--',*prefixes],cwd=ROOT)
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:') as archive:
        old={m.name:m for m in archive.getmembers() if m.isfile()}
        assert set(names)==set(old),(label,'tracked input set changed')
        for name in names:
            before=archive.extractfile(old[name]).read()
            now=(ROOT/name).read_bytes()
            assert before==now,(label,name)
            matched.append({'path':name,'sha256':hashlib.sha256(now).hexdigest()})
    rows.append({'component':label,'comparedSource':subprocess.check_output(['git','rev-parse',commit],cwd=ROOT,text=True).strip(),'finalSource':current,'unchangedFiles':matched,'applicableChecks':checks,
      'boundary':'Component identity proof only; complete final Swift suites and new worker process acceptance exercise the changed shared Swift inputs. This does not claim all checks ran on the final Git HEAD.'})
(TASK/'component-bindings.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'component':r['component'],'unchangedFiles':len(r['unchangedFiles']),'source':r['comparedSource'],'final':current} for r in rows],indent=2))
