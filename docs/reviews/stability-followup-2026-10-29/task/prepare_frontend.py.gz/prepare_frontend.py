import json, pathlib, shutil, sys
from run_check import ROOT, TASK, run_check
deps=ROOT/'.build/phase5-followup-20261029/frontend-deps'
assert not deps.exists()
deps.mkdir(parents=True)
for name in ['package.json','package-lock.json']:
    shutil.copyfile(ROOT/'prototype'/name,deps/name)
sys.exit(run_check('CLEAN-NPM-CI',['npm','ci'],deps,timeout=600))
