import datetime, hashlib, json, pathlib, subprocess
from run_check import ROOT, TASK
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='9a003a2b34e7cc107a8a6fab5ed9d1da6e6b68c7'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
inputs=[n for n in names if n and (n.startswith(('Sources/','Tests/','prototype/','python/','native/','tools/','scripts/','.github/')) or n in ('AGENTS.md','Package.swift','Package.resolved'))]
manifest={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in inputs}
(TASK/'final-source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
changes=subprocess.check_output(['git','diff','--name-only','fd774aef41f196e5f3b7da627a1b221af6594ba7','HEAD'],cwd=ROOT,text=True).splitlines()
receipt={'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'clean':True,'inputs':len(manifest),'changedInputs':changes,'releaseCandidateCreated':False}
(TASK/'final-source.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
