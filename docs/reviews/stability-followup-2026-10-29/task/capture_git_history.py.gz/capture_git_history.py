import datetime,hashlib,json,subprocess
from run_check import ROOT,TASK
base='fd774aef41f196e5f3b7da627a1b221af6594ba7'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
commits=subprocess.check_output(['git','rev-list','--reverse',base+'..'+head],cwd=ROOT,text=True).splitlines()
rows=[]
for commit in commits:
    title=subprocess.check_output(['git','show','-s','--format=%s',commit],cwd=ROOT,text=True).strip()
    paths=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',commit],cwd=ROOT,text=True).splitlines()
    rows.append({'commit':commit,'title':title,'paths':paths})
diff=subprocess.check_output(['git','diff','--binary',base,head,'--','Sources','Tests','prototype','python','tools','scripts','.github','Package.swift'],cwd=ROOT)
(TASK/'complete-repair.diff').write_bytes(diff)
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=ROOT,text=True).strip()
assert remote.split()[0]==head
(TASK/'source-commits.json').write_text(json.dumps({'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'head':head,'originMain':remote.split()[0],'commits':rows,'sourceDiffSHA256':hashlib.sha256(diff).hexdigest(),'workingCompiledInputsClean':not bool(subprocess.check_output(['git','status','--porcelain','--','Sources','Tests','prototype','python','tools','scripts','.github','Package.swift'],cwd=ROOT,text=True).strip())},indent=2)+'\n')
print(json.dumps({'commits':len(rows),'head':head,'originMain':remote.split()[0],'sourceDiffBytes':len(diff)},indent=2))
