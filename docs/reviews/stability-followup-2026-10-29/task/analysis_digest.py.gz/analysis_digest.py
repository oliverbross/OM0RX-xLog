import json,re
from run_check import TASK
for name in ['CLOSE-NATIVE','CLOSE-PORTABLE','FULL-PYTHON','FULL-RUST','FEATURE-RUST','CLIPPY','STRICT-SWIFT','CLOSE-STRICT','TSAN-REPAIRS','CLOSE-TSAN-AUTHORITY','CLOSE-PURE-IQ']:
    p=TASK/'checks'/f'{name}.log'
    if not p.exists(): continue
    s=p.read_text(errors='replace')
    lines=s.splitlines()
    print('\n'+name)
    # Suite totals and test opt-in boundaries, without repeating every test.
    print('\n'.join(line for line in lines if re.search(r'Executed \d+ tests?, with \d+ test.* skipped|Test run with .* passed|Ran \d+ tests|test result:|warning: .*generated',line))[-5000:])
    warnings=[line for line in lines if 'warning:' in line]
    print('warning lines:',len(warnings),'unique:',list(dict.fromkeys(warnings))[:8])
p=TASK/'all-contests-readiness.json'
if p.exists():
    d=json.loads(p.read_text()); print('catalogue top fields',list(d)); print({k:v for k,v in d.items() if isinstance(v,(str,int,float,bool))})
    from collections import Counter
    counts=Counter()
    def count(v):
        if isinstance(v,dict):
            for k,c in v.items():
                if k=='status' and isinstance(c,str): counts[c]+=1
                else: count(c)
        elif isinstance(v,list):
            for c in v: count(c)
    count(d)
    print('catalogue status leaf counts',dict(counts))
    print('first plugin shape',list(d['plugins'][0]) if isinstance(d.get('plugins'),list) else type(d.get('plugins')).__name__)
