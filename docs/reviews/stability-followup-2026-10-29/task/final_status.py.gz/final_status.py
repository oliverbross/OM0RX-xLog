import datetime,json,re
from run_check import TASK
print(datetime.datetime.now(datetime.timezone.utc).isoformat())
for name in ['FINAL-NATIVE','FINAL-PORTABLE','FINAL-STRICT','FINAL-NATIVE-RELEASE','FINAL-TSAN-AUTHORITY','FINAL-CLEAN-WORKER','FINAL-FRAMING','FINAL-CURRENT-PROCESS']:
    receipt=TASK/'checks'/f'{name}.json'
    log=TASK/'checks'/f'{name}.log'
    if receipt.exists():
        r=json.loads(receipt.read_text()); print(name, 'exit',r['exit'],'seconds',r['seconds'])
        if name in {'FINAL-NATIVE','FINAL-PORTABLE','FINAL-TSAN-AUTHORITY'}:
            lines=log.read_text(errors='replace').splitlines()
            total=[]
            for i,line in enumerate(lines):
                if "Test Suite 'All tests' passed" in line and i+1<len(lines): total.append(lines[i+1])
            print('XCTest bundle totals',total)
            print('SwiftTesting summaries',[l for l in lines if 'Test run with ' in l and 'passed' in l])
    elif log.exists(): print(name,'RUNNING; log bytes',log.stat().st_size)
    else: print(name,'QUEUED')
