import json, sys, time
from run_check import ROOT, TASK, run_check
deadline=time.monotonic()+2400
while not (TASK/'remaining-results.json').exists():
    if time.monotonic()>deadline: raise RuntimeError('Prior isolated compiler sequence did not finish; do not start competing cache users')
    time.sleep(5)
stage=ROOT/'.build/phase5-followup-20261029'
results=[]
steps=[
 ('CLOSE-NATIVE',['swift','test','--jobs','2','--scratch-path',str(stage/'native'),'--no-parallel'],{}),
 ('CLOSE-PORTABLE',['swift','test','--jobs','2','--scratch-path',str(stage/'portable'),'--no-parallel'],{'XLOG_PORTABLE_ONLY':'1'}),
 ('CLOSE-STRICT',['swift','build','--scratch-path',str(stage/'strict'),'--jobs','2','-Xswiftc','-strict-concurrency=complete','-Xswiftc','-warn-concurrency'],{'XLOG_PORTABLE_ONLY':'1'}),
 ('CLOSE-NATIVE-RELEASE',['swift','build','-c','release','--scratch-path',str(stage/'native-release'),'--jobs','2','--product','om0rx-xlog'],{}),
]
for name,command,env in steps:
    results.append({'id':name,'exit':run_check(name,command,overrides=env,timeout=1800)})
for name,mode in [('CLOSE-FRONTEND','test'),('CLOSE-FRONTEND-BUILD','build')]:
    results.append({'id':name,'exit':run_check(name+'-WRAPPER',['/opt/homebrew/bin/python3.12','-B',str(TASK/'frontend_check.py'),name,mode],timeout=1900)})
manifest=TASK/'worker-final-build-manifest.json'
results.append({'id':'CLOSE-CLEAN-WORKER','exit':run_check('CLOSE-CLEAN-WORKER',[
 'node','prototype/scripts/build-contesting-worker-process.mjs','--scratch-path',str(stage/'worker-final-clean'),'--output',str(manifest)],timeout=1800)})
if manifest.exists():
    worker=json.loads(manifest.read_text())['worker']['path']
    for name,command in [
     ('CLOSE-FRAMING',['node','Tests/XLogPrototypeTests/worker-process.test.mjs',worker]),
     ('CLOSE-CURRENT-PROCESS',['node','prototype/scripts/accept-contesting-worker-process.mjs','--build-manifest',str(manifest.resolve()),'--output',str(stage/'process-acceptance-final'),'--expected-head','fd2fc49e79d691a02323a635f0db157ca5b22e29'])]:
        results.append({'id':name,'exit':run_check(name,command,timeout=300)})
else:
    results.append({'id':'CLOSE-FRAMING/CLOSE-CURRENT-PROCESS','blocked':'No successful final-source worker manifest'})
results.append({'id':'CLOSE-TSAN-AUTHORITY','exit':run_check('CLOSE-TSAN-AUTHORITY',[
 'swift','test','--scratch-path',str(stage/'tsan'),'--jobs','2','--sanitize','thread','--no-parallel',
 '--filter','WavelogDestinationAuthorityTests|BackupRestoreAuthorityTests'],overrides={'XLOG_PORTABLE_ONLY':'1'},timeout=900)})
results.append({'id':'CLOSE-PURE-IQ','exit':run_check('CLOSE-PURE-IQ',[
 '/opt/homebrew/bin/python3.12','-B','tools/check_portable_iq_sources.py','--repository',str(ROOT),'--output',str(stage/'pure-iq-final')],timeout=600)})
(TASK/'closing-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
sys.exit(any(row.get('exit',1) for row in results))
