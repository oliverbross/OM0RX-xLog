import hashlib, json, os, pathlib, sys
from run_check import ROOT, TASK, run_check
name, mode=sys.argv[1:]
assert mode in ('test','build')
stage=ROOT/'.build/phase5-followup-20261029'
fresh=stage/'frontend-deps/node_modules'
modules=ROOT/'prototype/node_modules'; dist=ROOT/'prototype/dist'
oldmodules=stage/('original-node_modules-'+name); olddist=stage/('original-dist-'+name)
assert modules.is_dir() and not modules.is_symlink() and fresh.is_dir()
assert not oldmodules.exists() and not olddist.exists()
moduleinode=modules.stat().st_ino
originaldist={str(p.relative_to(dist)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dist.rglob('*') if p.is_file()}
modules.rename(oldmodules)
had_dist=dist.exists()
if had_dist: dist.rename(olddist)
code=1
try:
    fresh.rename(modules)
    code=run_check(name,['npm','test'] if mode=='test' else ['npm','run','build'],ROOT/'prototype',timeout=1800)
finally:
    if modules.exists(): modules.rename(fresh)
    oldmodules.rename(modules)
    if dist.exists(): dist.rename(stage/('built-dist-'+name))
    if had_dist: olddist.rename(dist)
    assert modules.stat().st_ino==moduleinode
    assert {str(p.relative_to(dist)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dist.rglob('*') if p.is_file()}==originaldist
    (TASK/'checks'/(name+'-preservation.json')).write_text(json.dumps({'nodeModulesRestoredByInode':moduleinode,'originalDistFilesAndHashesRestored':len(originaldist),'freshDependenciesPreserved':str(fresh),'exit':code},indent=2)+'\n')
sys.exit(code)
