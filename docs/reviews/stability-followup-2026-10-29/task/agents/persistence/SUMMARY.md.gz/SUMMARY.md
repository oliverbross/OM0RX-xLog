# FA-002 repair handoff

Base inspected: fd774aef41f196e5f3b7da627a1b221af6594ba7. Root owns fetch/Git/report/full-suite work. Edits limited to python/contest_host/host.py and python/tests/test_remediation_import_replica.py; no source commits or production/device/provider operations.

Replica rebuild now rehydrates its scoring country lookup from all current durable contact identities before recomputation, using the existing country validator. This covers untouched earlier-page rows and persists with the enclosing mutation transaction. Authority/new-entry reference behavior, immutable identities, audit history and existing operation receipts are not rewritten. No changes run during incomplete staged-history returns; existing replica fences and rollback still apply.

The import fixture now uses the native station-only initial reference and per-import country enrichment. New regression proves two separately synchronized enriched imports, actual independent WPX oracle (6 points x 2 prefixes = 12), untouched first-row equality, exact operation replay, reopening both Hosts twice, a real subsequent correction, and old audit/receipt/identity preservation. A second new negative test supplies an incomplete country in a valid replica change; it reaches rebuild validation after tentative writes, verifies every replica table/reference/receipt/cursor rolls back byte-for-byte, then proves the genuine page succeeds.

Evidence commands (cwd canonical checkout; Python runner disables UDP opt-ins and places all fixtures in this scratch runtime):

1. `/opt/homebrew/bin/python3.12 -B /tmp/xlog-phase5-followup-20261029-fd774aef/agents/persistence/run_focused.py test_remediation_import_replica.ImportedReplicaTests.test_separate_enriched_import_pages_preserve_prior_scores_and_history` — baseline-regression.log: expected FAIL before production change; first contact master Points3 versus replica0 after second page.
2. `/opt/homebrew/bin/python3.12 -B /tmp/xlog-phase5-followup-20261029-fd774aef/agents/persistence/run_focused.py` — focused-tests.log: 33 PASS (import/replica/floor, multi-operator, replica authority, WAE, recorder). Ran after production repair.
3. `/opt/homebrew/bin/python3.12 -B /tmp/xlog-phase5-followup-20261029-fd774aef/agents/persistence/run_focused.py test_remediation_import_replica` — final-import-tests.log: all8 PASS after adding the incomplete-country rollback control. No production change since command2; do not mislabel command2 as34 tests.
4. `git diff --check -- python/contest_host/host.py python/tests/test_remediation_import_replica.py` — PASS.

Existing replicas already carrying corrupted persisted scores or a mismatched authority before-image are not silently repaired or forced past their cursor. This change prevents the reproduced loss of scoring context and can hydrate sparse retained references when a valid subsequent page reaches rebuild. A store already failing its before-image fence still needs preserved, reviewed recovery/rebaseline. No hardware/LAN/audio or sponsor acceptance claimed.
