# Exact seven-repair-batch CI conclusion

Source: `9a003a2b34e7cc107a8a6fab5ed9d1da6e6b68c7`.
Observed through 2026-10-29 00:43 UTC. This source is superseded for convergence by the known FA-008 follow-up; these outcomes apply only to this exact repair batch.

| Workflow | Run | Conclusion | Own jobs |
| --- | --- | --- | --- |
| CI | 40793254038 | SUCCESS | test-and-package 123183383782 success |
| Contest portability | 40793254247 | SUCCESS, completed 00:37:49 UTC | All seven generator, Rust native and Swift platform jobs success |
| Cross-platform prototype | 40793254361 | FAILURE, completed 00:41:21 UTC | prototype (macos-14) 123183386366 failed Frontend tests and build; Linux/Windows acceptance jobs skipped |

Prototype own-log evidence:
- macos-14-arm64 image 20260831.0302.1; macOS 14.8.9; Node 22.23.2; npm 10.9.8; Vitest 5.0.3.
- Command `npm test && npm run build`, where test is `npm run test:node && vitest run --maxWorkers=1`.
- Node tests: 6 passed, 0 failed.
- Vitest: 4741 passed, 1 failed of 4742; 338 passed, 1 failed of 339 files; duration 615.29s.
- Exact failing test: `tests/detached-logbook.test.tsx > uses the shared editor with its own journal and no radio authority`, line 41:28. Assertion expected `api.changes.size` 2, received 1 after `render(<DetachedLogbookSurface />); await openEditor();`.
- Failing test duration 463ms. Process exit code 1. This is an assertion failure, with no job/test timeout recorded.
- Build after the test command and subsequent Swift/worker/runtime/package steps did not execute. Uploaded development artifact is not evidence of their execution.

Static lead only, not established cause: `openEditor()` waits for the rendered Update QSO button; second listener is registered by QSOEditorCore passive useEffect at lines 232-238, reached through lazy/Suspense. Immediate listener count may race effect commitment. No local reproduction or test change was performed by this agent. Other three detached-logbook tests passed in the failing CI file.

Evidence:
- Full own job logs: `ci-final-job-123183386366-logs.json`
- Exact run identity/conclusion: `ci-final-prototype-conclusion.json`
- Own annotations: `ci-final-123183386366-annotations.json`
- Completed job/step states: `ci-final-prototype-jobs-completed.json`
- CI and portability own logs and annotations: `ci-final-job-<jobID>-logs.json`, matching annotation snapshots.
- Portability own job IDs: 123183567088 generator; 123183567196 native Ubuntu; 123183567033 native Windows; 123183567154 native macOS; 123183567107 Swift Ubuntu; 123183567018 Swift Windows; 123183567130 Swift macOS.

Only other annotations were Node20 actions forced onto Node24 deprecation warnings and macOS runner capacity notices. Prototype includes the assertion and process-exit annotations above. Read-only observation only; no CI cancellations, reruns, dispatches or other mutations. All outcomes captured; polling is stopped pending root's next source hash.
