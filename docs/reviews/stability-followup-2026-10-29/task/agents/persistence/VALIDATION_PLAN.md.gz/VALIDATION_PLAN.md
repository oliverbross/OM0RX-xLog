# Current mandatory regression plan (read-only inventory; not executed here)

Canonical cwd: `/Users/oliver/Documents/Projects/OM0RX-xLog`. Sources inspected: `.github/workflows/{ci,prototype,contest-portability}.yml`, `prototype/package.json`, `Package.swift`, the Python qualification/generator scripts and relevant opt-in test guards. Root owns execution, caches, full-suite results and reports. Capture exact command, interpreter/toolchain, final source hashes, exit code and uncompressed raw output per gate; a cached `--skip-build` result does not replace a final fresh compilation.

Use a root-owned scratch directory, for example `/tmp/xlog-phase5-followup-20261029-fd774aef/root-validation`, with separate native Swift, portable Swift and Cargo target paths. Do not overlap Swift/Cargo builds in a shared cache. Existing node dependencies may be used for a first pass; the separate clean-lock gate needs its own permitted cache/network decision.

## Safety/environment preflight

- Keep ambient `XLOG_CONTEST_N1MM_UDP_ALLOWED=0` and `XLOG_CONTEST_ALLOW_UDP=0`. Python N1MM tests deliberately set the first to1 inside fixtures, but install a Recorder/Datagram fake before emission (`python/tests/test_n1mm_output.py:18–80`); do not globally rewrite these tests or claim the test output was physical UDP.
- **Unset**, rather than set to0, every inherited `XLOG_FTP_*` / `XLOG_FTPS_*` live endpoint or credential variable. `FTPBackupLiveServerTests` uses endpoint *presence* to opt into real transport. Do not print their values.
- Leave `XLOG_SCP_LIVE_TEST`, `XLOG_PROPAGATION_LIVE_PROBE`, `XLOG_DXMAP_LIVE_AUDIT_FILE`, `XLOG_TEST_NATIVE_VAULT`, `XLOG_RUN_CONTEST_OPERATOR_BROWSER_ACCEPTANCE` and its outer guard unset. They enable provider, credential-vault or actual browser/worker acceptance beyond the ordinary suite. Leave `XLOG_GENERATED_PERF`, `XLOG_MERGE_CONTENTION_BENCHMARK`, `XLOG_BOUNDED_MERGE_BENCHMARK`, `XLOG_REMOTE_MERGE_BENCHMARK` unset for the mandatory baseline; synthetic performance runs are separate qualifications.
- Set `XLOG_CONTEST_PYTHON=/opt/homebrew/bin/python3.12`, `XLOG_TEST_PYTHON312=/opt/homebrew/bin/python3.12`, and for Rust `XLOG_TEST_PYTHON=/opt/homebrew/bin/python3.12`. `PythonContestLaneTests` specifically reads XLOG_TEST_PYTHON312; a missing supported runtime may otherwise skip decisive cases.
- Ordinary Swift/Rust suites include disposable loopback/fake-server tests. These are distinct from external-provider/hardware operation. Record expected live opt-in skips; do not report them as provider acceptance.
- Keep all fixture/output paths private and disposable. Python full tests and tools launch child interpreters; preserve `PYTHONPATH=python:python/tests` in their environment. Set TMPDIR to an existing root-owned scratch temporary directory if all generated fixtures must stay under the evidence root.

## Python full suite and complete catalogue

These use the production host's **Python3.12** lane. From canonical cwd, exact ordinary entrypoints:

```sh
PYTHONPATH=python:python/tests XLOG_CONTEST_N1MM_UDP_ALLOWED=0 XLOG_CONTEST_ALLOW_UDP=0 /opt/homebrew/bin/python3.12 -B -m unittest discover -s python/tests -v
/opt/homebrew/bin/python3.12 -B tools/check_reviewed_security_patches.py
XLOG_CONTEST_N1MM_UDP_ALLOWED=0 XLOG_CONTEST_ALLOW_UDP=0 /opt/homebrew/bin/python3.12 -B tools/check_all_contests_readiness.py --family-tests --output /tmp/xlog-phase5-followup-20261029-fd774aef/root-validation/all-contests-readiness.json
PYTHONPATH=python:python/tests XLOG_CONTEST_N1MM_UDP_ALLOWED=0 XLOG_CONTEST_ALLOW_UDP=0 /opt/homebrew/bin/python3.12 -B tools/check_contest_append_equivalence.py
/opt/homebrew/bin/python3.12 -B prototype/scripts/test-contest-python-relocation.py
```

The complete catalogue gate must omit both `--plugin` and `--fixture-cache`: it dynamically derives `PLUGIN_REGISTRY` and requires exact lifecycle/expected-score/export fixture key coverage for **all** registered definitions, returning failure on FAIL/UNVERIFIED. `--family-tests` reruns family assertions and writes the ignored `.build/all-contests-fixture-inputs.json` as well as the requested scratch report (`check_all_contests_readiness.py:387–398`). The append tool separately compares actual append versus complete rebuild and rejects uncovered optimized plugins. These are bounded fixture/rule oracles, not fresh sponsor certification. Do not run `render_all_contests_readiness.py` unless root intends to modify generated documentation.

If lean-ctx falsely rejects unittest's discovery `-p` option as inline interpreter code, do not retry the blocked form or modify allowlists. The commands above avoid `-p`; a normal scratch script using unittest.TestLoader remains the supported fallback.

## Generator / pinned-corpus gate: Python3.14, not3.12

CI requires Python3.14 (`extract_plugins.REQUIRED_PYTHON == (3,14)`) and the exact external source pin. Read-only verification in this inventory confirmed the existing checkout `/Users/oliver/Documents/Projects/contest-sw` at `7c8b499225a73f7f8f792246881bd7aefc05452f`; no checkout/fetch/update is needed or authorized by this plan. Reverify its HEAD before the gate and preserve unrelated work.

```sh
CONTEST_SW_ROOT=/Users/oliver/Documents/Projects/contest-sw /opt/homebrew/bin/python3.14 -B tools/contest_plugin_generator/verify_pinned_corpus.py --upstream /Users/oliver/Documents/Projects/contest-sw --ledger docs/contesting/contest-acceptance-ledger.json --inventory docs/contesting/generated/python-plugin-inventory.json
CONTEST_SW_ROOT=/Users/oliver/Documents/Projects/contest-sw /opt/homebrew/bin/python3.14 -B -m unittest discover -s tools/contest_plugin_generator/tests -v
```

Missing CONTEST_SW_ROOT is deliberately a decisive failure for pinned converter/extractor tests, not an acceptable skip. Tests also create throwaway Git repositories inside temporary fixtures; they do not commit canonical source. Do not regenerate checked-in definitions to make comparisons pass.

## Swift, frontend and Rust gates

CI runs both the original Mac manifest (`swift test`) and the portable manifest (`XLOG_PORTABLE_ONLY=1`, complete suite, serial test scheduling). Use fresh separate scratch paths after source settles:

```sh
XLOG_CONTEST_PYTHON=/opt/homebrew/bin/python3.12 XLOG_TEST_PYTHON312=/opt/homebrew/bin/python3.12 swift test --jobs 2 --scratch-path /tmp/xlog-phase5-followup-20261029-fd774aef/root-validation/native-swift --no-parallel
XLOG_PORTABLE_ONLY=1 XLOG_CONTEST_PYTHON=/opt/homebrew/bin/python3.12 XLOG_TEST_PYTHON312=/opt/homebrew/bin/python3.12 swift test --jobs 2 --scratch-path /tmp/xlog-phase5-followup-20261029-fd774aef/root-validation/portable-swift --no-parallel
/opt/homebrew/bin/python3.12 -B tools/check_portable_iq_sources.py --repository /Users/oliver/Documents/Projects/OM0RX-xLog --output /tmp/xlog-phase5-followup-20261029-fd774aef/root-validation/portable-iq
```

Ensure XLOG_PORTABLE_ONLY is **unset** for the first command; inherited1 would silently select the wrong manifest. Original Mac XLogCoreTests and portable XLogPrototypeTests contain paired authority tests. A separate strict-concurrency build/check remains useful because a normal successful Swift build is not the `-strict-concurrency=complete` qualification. CI's pure IQ helper compiles its manifest-selected seven-source slice and retained tests without live radio owners.

From `/Users/oliver/Documents/Projects/OM0RX-xLog/prototype`:

```sh
XLOG_CONTEST_PYTHON=/opt/homebrew/bin/python3.12 npm test
npm run build
```

`npm test` is exactly `npm run test:node && vitest run --maxWorkers=1`; `npm run build` is exactly `tsc --noEmit && vite build && node scripts/check-window-bundles.mjs`. The window bundle budget check is mandatory. CI precedes these with `npm ci`; that mutates dependencies and can download registry content, so execute only under root's clean-lock/network scope, not silently as part of an offline test. It is not equivalent to simply rerunning installed dependencies.

From `/Users/oliver/Documents/Projects/OM0RX-xLog/prototype/src-tauri`:

```sh
XLOG_TEST_PYTHON=/opt/homebrew/bin/python3.12 cargo test --locked --jobs 2 --target-dir /tmp/xlog-phase5-followup-20261029-fd774aef/root-validation/cargo
```

The contest-specific CI lane also sets TAURI_CONFIG to `{"productName":"OM0RX-xLog Contesting Test","identifier":"com.oliverbross.xlog.contesting-test","bundle":{"active":false,"externalBin":[]}}` and runs `cargo test --locked --jobs 2 --target-dir <isolated-target> --bin xlog-prototype --features contesting-test` against these filters, first with `-- --list` and explicit discovery assertions, then executing: `contest_export::tests::`, `contesting_test_native_admission_tests::` (expected7), `worker::tests::passive_reads_use_bounded_timeout_without_widening_mutation_policy` (expected1), `operating_module::tests::`, `durable_file::tests::` (expected3), `module_restart_intent::tests::`, `worker::tests::shutdown_`. Follow the live workflow assertions; do not weaken expected counts to get green. Offline Cargo may need already-cached dependencies; do not silently remove --locked or fetch another stack to pass.

CI additionally builds/stages the Swift worker and runs `node Tests/XLogPrototypeTests/worker-process.test.mjs prototype/src-tauri/target/release/xlog-prototype-worker`. That is separate **isolated process acceptance**, not merely a unit suite. Root must inspect its current isolation/provenance flags before executing and report it separately. Bundled Hamlib dummy tests require exact test helper binaries via XLOG_TEST_RIGCTLD/XLOG_TEST_ROTCTLD and the dummy protocol route; staging scripts can fetch/build dependencies and are outside this offline inventory. Missing helpers should be reported, not replaced by installed production radio daemons.

Do not package/sign/install an application as part of this plan: CI packaging commands create application candidates and require a new visible version plus source/build provenance. The source version remains1.3.60 while fixes are in progress. Windows/Linux runtime, credential vault, real browser/native UI, physical radio/audio/RF, current provider rules, long soaks and live transport checks remain separate acceptance boundaries.
