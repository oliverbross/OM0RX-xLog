# Read-only CI status before final radio commits

Snapshot from GitHub on main at observed local HEAD9dc6772e01d4f2fd484b597e9401325566d1da60. This is not final-source CI acceptance. No workflow cancelled, rerun, edited or dispatched; no comments/messages/PR changes.

The connector's fetch_commit_workflow_runs wrapper explicitly filters pull-request-triggered runs; pushed-main discovery therefore used read-only `gh run list --repo oliverbross/OM0RX-xLog --branch main --limit 15 --json databaseId,workflowName,headSha,status,conclusion,createdAt,updatedAt,url`. Job inspection used the GitHub connector's fetch_workflow_run_jobs.

| Source | Workflow/run | Observed status |
| --- | --- | --- |
|9dc6772|CI40792311618|In progress; test-and-package job123180245485 in Test; packaging/resource steps pending|
|9dc6772|Cross-platform prototype40792311619|Queued; Mac job123180245628|
|a00365e|CI40792199597|In progress|
|a00365e|Cross-platform prototype40792199621|In progress|
|095f8fa|CI40791353182|Success|
|095f8fa|Contest portability40791353153|Generator, all three native Rust jobs, Mac and Linux Swift jobs success; Windows Swift job123177068161 still in discovery|
|e15c600|CI40790170947|Success|
|e15c600|Cross-platform prototype40790170914|In progress|

Workflow limits from current source: Cross-platform prototype main job40minutes; platform runtime-only Linux20minutes/Windows15minutes; Contest portability Swift jobs20minutes, generator10minutes, native jobs45minutes. Portability cancels older runs for the same workflow/ref via cancel-in-progress:true. Prototype and classicCI have no such cancellation setting; classicCI has no explicit job timeout. Earlier successful jobs must not be attributed to later source heads.

Raw list saved as ci-initial-runs.json. A later optional source-search/status batch stalled in tool orchestration and was terminated without a result; no CI execution was terminated. Its attempted snapshot is not claimed as evidence. Await root's exact final-source hash before decisive run inspection.
