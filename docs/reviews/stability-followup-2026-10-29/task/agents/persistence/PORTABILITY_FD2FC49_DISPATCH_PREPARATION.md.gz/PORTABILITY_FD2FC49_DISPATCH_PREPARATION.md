# Exact-source portability dispatch preparation (not executed)

Source requested: fd2fc49e79d691a02323a635f0db157ca5b22e29.
At 2026-10-29 00:58 UTC, exact-source run discovery showed only CI40797271025 and prototype40797271076, both queued.

`.github/workflows/contest-portability.yml` has a bare `workflow_dispatch:` trigger, with no inputs. Seven files changed since9a; none matches its push paths, explaining no new push-triggered portability run.

Root-only read-only precheck:
```sh
gh api repos/oliverbross/OM0RX-xLog/git/ref/heads/main --jq .object.sha
```
Expected exact output: fd2fc49e79d691a02323a635f0db157ca5b22e29.

Root-only proposed dispatch:
```sh
gh workflow run contest-portability.yml --repo oliverbross/OM0RX-xLog --ref main
```
REST equivalent: POST /repos/oliverbross/OM0RX-xLog/actions/workflows/contest-portability.yml/dispatches with JSON `{"ref":"main"}`, no inputs.

After root dispatch, verify run's headSha equals the requested source; a moving main can otherwise invalidate attribution:
```sh
gh run list --repo oliverbross/OM0RX-xLog --workflow contest-portability.yml --commit fd2fc49e79d691a02323a635f0db157ca5b22e29 --limit 10 --json databaseId,event,headSha,status,conclusion,createdAt,url
```

Workflow jobs: three-platform Swift filtered portability tests; contest generator tests and pinned-corpus/security checks; three-platform Rust native contesting tests. It has no application release/publication dispatch inputs and no packaging/deploy job. It installs/downloads build dependencies and reads pinned contest corpus on CI runners.

Concurrency group is contest-portability-workflow-ref and cancel-in-progress=true; root should consider any active same-ref run before dispatch. No child dispatch, cancellation, rerun, or CI mutation performed.
