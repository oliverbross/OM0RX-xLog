import os,sys,tempfile,unittest
from pathlib import Path
root=Path('/tmp/xlog-phase5-followup-20261029-fd774aef/agents/persistence/runtime');root.mkdir(exist_ok=True)
tempfile.tempdir=str(root.resolve())
os.environ['XLOG_CONTEST_N1MM_UDP_ALLOWED']='0';os.environ['XLOG_CONTEST_ALLOW_UDP']='0'
sys.dont_write_bytecode=True
sys.path[:0]=['/Users/oliver/Documents/Projects/OM0RX-xLog/python','/Users/oliver/Documents/Projects/OM0RX-xLog/python/tests']
names=sys.argv[1:] or ['test_remediation_import_replica','test_multi_operator_host','test_review_replica_authority','test_remediation_wae','test_recorder']
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
sys.exit(not result.wasSuccessful())
