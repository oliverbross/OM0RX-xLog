from pathlib import Path
import difflib
import hashlib
import json

base = Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out = Path('/tmp/xlog-phase5-followup-20261029-fd774aef/agents/frontend/fa009')
rel = 'prototype/tests/detached-logbook.test.tsx'
old = (base / rel).read_text()
new = old.replace('  await screen.findByRole("button", { name: "Update QSO" });\n}',
    '  await screen.findByRole("button", { name: "Update QSO" });\n'
    '  // Rendering can precede the shared editor\'s passive subscription effect.\n'
    '  await waitFor(() => expect(api.changes.size).toBe(2));\n}')
new = new.replace('  expect(api.changes.size).toBe(1); // Editor cleanup retains the outer listener.',
    '  await waitFor(() => expect(api.changes.size).toBe(1)); // Editor cleanup retains the outer listener.')
assert new != old
assert new.count('await waitFor(() => expect(api.changes.size).toBe(2));') == 1
assert new.count('await waitFor(() => expect(api.changes.size).toBe(1));') == 1
for tree, value in [('before', old), ('after', new)]:
    path = out / tree / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value)
(out / 'FA009.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
    fromfile='a/' + rel, tofile='b/' + rel)))
(out / 'source-sha256.json').write_text(json.dumps({
    'before': hashlib.sha256(old.encode()).hexdigest(),
    'after': hashlib.sha256(new.encode()).hexdigest()}, indent=2) + '\n')
print(out)
