from pathlib import Path
import shutil
import difflib
import hashlib
import json

base = Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out = Path('/tmp/xlog-phase5-followup-20261029-fd774aef/agents/frontend/fa008')
files = ['Sources/XLogCore/Settings.swift', 'Sources/XLogCore/BackupManager.swift',
         'Sources/XLogApp/AppModel.swift', 'Sources/XLogPrototypeSupport/LiveLogbookMethods.swift']
for tree in ['before', 'after']:
    for rel in files:
        target = out / tree / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(base / rel, target)

def replace(rel, old, new):
    path = out / 'after' / rel
    source = path.read_text()
    assert source.count(old) == 1, (rel, old, source.count(old))
    path.write_text(source.replace(old, new))

settings = 'Sources/XLogCore/Settings.swift'
replace(settings, '/// Integration-only settings state.', '''/// Remote IDs are meaningful only within their exact saved Wavelog destination.
public enum WavelogDestinationError: Error, LocalizedError {
    case linkedContacts
    case databaseUnavailable
    case unsavedDestination

    public var errorDescription: String? {
        switch self {
        case .linkedContacts:
            return "This logbook contains Wavelog-linked contacts. Create a new workspace or use a reviewed migration before changing the destination."
        case .databaseUnavailable:
            return "Open the logbook before changing its Wavelog destination."
        case .unsavedDestination:
            return "Save or undo the pending Wavelog destination change before synchronizing or creating a backup."
        }
    }
}

extension XLogSettings {
    public func hasSameWavelogDestination(as other: XLogSettings) -> Bool {
        wavelogURL == other.wavelogURL && wavelogStationID == other.wavelogStationID
    }
}

/// Integration-only settings state.''')
replace(settings, '''    public func save(_ value: XLogSettings) {
        if let data = try? JSONEncoder().encode(value) { defaults.set(data, forKey: key) }
    }
''', '''    public func save(_ value: XLogSettings) {
        if let data = try? JSONEncoder().encode(value) { defaults.set(data, forKey: key) }
    }

    /// Check before persisting either settings or secrets. Tombstones retain
    /// remote authority and are included by linkedRemoteCount().
    public func validateDestinationChange(to value: XLogSettings, database: LogbookDatabase?) throws {
        guard !load().hasSameWavelogDestination(as: value) else { return }
        guard let database else { throw WavelogDestinationError.databaseUnavailable }
        guard try database.linkedRemoteCount() == 0 else { throw WavelogDestinationError.linkedContacts }
    }

    public func save(_ value: XLogSettings, protecting database: LogbookDatabase?) throws {
        try validateDestinationChange(to: value, database: database)
        let data = try JSONEncoder().encode(value)
        defaults.set(data, forKey: key)
    }

    /// Pending form values must not relabel the current logbook's authority.
    public func validateCurrentDestination(_ value: XLogSettings) throws {
        guard load().hasSameWavelogDestination(as: value) else {
            throw WavelogDestinationError.unsavedDestination
        }
    }

    public func wavelogConfiguration(for value: XLogSettings, token: String) throws -> WavelogConfiguration {
        try validateCurrentDestination(value)
        guard let url = URL(string: value.wavelogURL) else { throw WavelogClientError.invalidURL }
        return try WavelogConfiguration(baseURL: url, token: token, stationID: value.wavelogStationID)
    }
''')
replace('Sources/XLogCore/BackupManager.swift', '''        if !restoreSettings,
           settings.wavelogURL != current.wavelogURL || settings.wavelogStationID != current.wavelogStationID {''', '''        if !restoreSettings, !settings.hasSameWavelogDestination(as: current) {''')
replace('Sources/XLogPrototypeSupport/LiveLogbookMethods.swift', '''                let destinationChanged = previous.settings.wavelogURL != safe.wavelogURL
                    || previous.settings.wavelogStationID != safe.wavelogStationID''', '''                let destinationChanged = !previous.settings.hasSameWavelogDestination(as: safe)''')
model = 'Sources/XLogApp/AppModel.swift'
replace(model, '''    func saveSettings() {
        settingsStore.save(settings)
        do {
            try secrets.save''', '''    func saveSettings() {
        guard !isWorking else {
            banner = AppBanner(message: "Wait for current work to finish before saving settings.", kind: .warning)
            return
        }
        do {
            try settingsStore.save(settings, protecting: database)
            try secrets.save''')
replace(model, '''        guard let database, let baseURL = URL(string: settings.wavelogURL), settings.wavelogStationID > 0, !wavelogToken.isEmpty else {
            syncStatus = "Configure Wavelog"
            return
        }
        isWorking = true; syncStatus = "Syncing…"''', '''        guard let database else { syncStatus = "Open a logbook"; return }
        let config: WavelogConfiguration
        do {
            config = try settingsStore.wavelogConfiguration(for: settings, token: wavelogToken)
        } catch {
            syncStatus = "Configure Wavelog"
            banner = AppBanner(message: error.localizedDescription, kind: .error)
            return
        }
        isWorking = true; syncStatus = "Syncing…"''')
replace(model, '''            let config = try WavelogConfiguration(baseURL: baseURL, token: wavelogToken, stationID: settings.wavelogStationID)
            let report''', '''            let report''')
replace(model, '''updater.refreshWavelogCatalog(baseURL: baseURL, token: wavelogToken)''', '''updater.refreshWavelogCatalog(baseURL: config.baseURL, token: config.token)''')
replace(model, '''        let settings = settings
        let preferences = currentBackupPreferences()''', '''        do {
            try settingsStore.validateCurrentDestination(settings)
        } catch {
            banner = AppBanner(message: error.localizedDescription, kind: .error)
            return
        }
        let settings = settings
        let preferences = currentBackupPreferences()''')
replace(model, '''        let liveURL = database.url
        let currentSettings = settings''', '''        do {
            try settingsStore.validateCurrentDestination(settings)
        } catch {
            banner = AppBanner(message: error.localizedDescription, kind: .error)
            return
        }
        let liveURL = database.url
        let currentSettings = settings''')
test = out / 'WavelogDestinationAuthorityTests.swift'
if test.exists():
    for rel in ['Tests/XLogCoreTests/WavelogDestinationAuthorityTests.swift',
                'Tests/XLogPrototypeTests/WavelogDestinationAuthorityTests.swift']:
        target = out / 'after' / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(test, target)

    # This requirement test uses only pre-fix APIs, so its failing row-preservation
    # assertion can be run before applying the production patch.
    text = test.read_text()
    fixture = text[:text.index('final class WavelogDestinationAuthorityTests:')]
    case_start = text.index('    func testUnguardedConfigurationCounterexample')
    case_end = text.index('    private func original()', case_start)
    case = text[case_start:case_end]
    case = case.replace('testUnguardedConfigurationCounterexampleCanTombstoneAnotherDestinationsLinkedRow',
                        'testChangingLiveStationBeforeSaveMustPreserveLinkedHistory')
    case = case.replace('            XCTAssertEqual(report.deleted, 1)\n            XCTAssertNotNil(try database.lookup(localID: local.id)?.deletedAt)',
                        '            print("FA008 PRE-FIX: deleted=\\(report.deleted), requests=\\(DestinationHistoryProtocol.requests.count)")\n'
                        '            XCTAssertEqual(report.deleted, 0, "Unsaved station edit must not reconcile another destination")\n'
                        '            XCTAssertNil(try database.lookup(localID: local.id)?.deletedAt, "Original clean linked row must remain live")')
    helper_start = text.index('    private func original()')
    helper_end = text.index('    private func withFixture(')
    async_start = text.index('    private func withAsyncFixture(')
    prefix = fixture + 'final class FA008PreFixCounterexampleTests: XCTestCase {\n' + case
    prefix += text[helper_start:helper_end] + text[async_start:]
    (out / 'FA008PreFixCounterexampleTests.swift').write_text(prefix)

parts = []
for path in sorted((out / 'after').rglob('*.swift')):
    rel = path.relative_to(out / 'after').as_posix()
    old = out / 'before' / rel
    parts.extend(difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],
                                   path.read_text().splitlines(True),
                                   fromfile='a/' + rel if old.exists() else '/dev/null', tofile='b/' + rel))
(out / 'FA008.patch').write_text(''.join(parts))
proof_sources = [p for tree in ['before', 'after'] for p in sorted((out / tree).rglob('*.swift'))]
proof_sources += [out / 'FA008PreFixCounterexampleTests.swift']
(out / 'source-sha256.json').write_text(json.dumps({str(p.relative_to(out)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in proof_sources}, indent=2) + '\n')
print(out)
