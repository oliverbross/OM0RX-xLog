# FA008 prepared patch

Prepared against canonical `9a003a2b34e7cc107a8a6fab5ed9d1da6e6b68c7`. Canonical files have not been modified by this preparation. No tests, compilers, GUI, network, provider, or secret operations were run.

`FA008.patch` passes `git apply --check`. `before/` and `after/` contain source copies; `source-sha256.json` records their hashes. `prepare_fa008.py` in the parent directory regenerates copies and the patch from canonical inputs; do not rerun after applying the patch.

## Root cause and scope

Retained SettingsView edits the published AppModel settings directly. Header/menu and an already-running timer can synchronize those unsaved destination coordinates. Save also persisted destination changes without checking linked identities. A valid snapshot from B then supplies deletion authority over A's clean linked rows. This remains an ordinary-settings issue distinct from backup restore.

The patch adds exact URL/station comparison shared with existing backup and modern save policy. The retained store's guarded save checks the actual SQLite linked count, including tombstones, and rejects a changed destination without an available database. AppModel calls that guarded save before any secret persistence and refuses settings saves during active work.

The factory rejects unsaved destinations before creating a sync configuration. Its captured URL/station/token feed both SyncEngine and the later catalog refresh. Verified backup and restore recovery capture reject pending destination differences before selecting settings for the database package. Rejections do not reset or discard the settings draft.

Modern save and backup restore retain their existing policy and error mapping; only their duplicate comparison is replaced. There is no schema or migration change.

## Validation prepared, not executed

`FA008PreFixCounterexampleTests.swift` uses only existing APIs. Install it as a temporary test file after the source-freeze window ends, run its single test, and preserve the expected row-preservation failure before applying production changes. It uses the real SyncEngine and SQLite with a URLProtocol that intercepts every request. A valid distinct B history causes the original A row to be tombstoned. It prints the deletion and request counts. Remove the temporary failing requirement test before applying the patch.

The patch adds eight paired native/portable tests in WavelogDestinationAuthorityTests:

- Live linked rows and tombstones reject either destination coordinate without persisting or changing the draft.
- Missing/closed databases reject destination changes.
- An unlinked database permits a saved destination change.
- Other pending fields can be saved without a database; captured configuration/token remains immutable.
- Exact destination comparison also guards settings captured for backups.
- Unsaved destination changes produce zero transport requests and preserve local rows/settings.
- A saved-destination control executes the real sync path through intercepted transport.
- A deliberate raw-configuration bypass retains the real-engine counterexample, demonstrating why the caller factory is required.

Tests exercise Core policy and the AppModel call pattern, not SwiftUI rendering, Keychain, production data, or a provider. AppModel call placement needs source review and a later appropriate compile. No acceptance result is claimed until execution.
