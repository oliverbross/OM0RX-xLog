import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
import XCTest
#if os(macOS)
@testable import XLogCore
#else
@testable import XLogPortableCore
#endif

/// Every request, including accidental writes, is intercepted; no provider is contacted.
private final class DestinationHistoryProtocol: URLProtocol {
    private static let lock = NSLock()
    private static var recorded: [URLRequest] = []
    static func reset() { lock.withLock { recorded = [] } }
    static var requests: [URLRequest] { lock.withLock { recorded } }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.lock.withLock { Self.recorded.append(request) }
        guard request.httpMethod == "GET", let url = request.url else {
            client?.urlProtocol(self, didFailWithError: URLError(.unsupportedURL)); return
        }
        let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
        let station = items.first { $0.name == "station_id" }?.value
        let other = url.host == "destination-b.invalid" || station == "2"
        let id = other ? 84 : 42
        let call = other ? "K2OTHER" : "K1ORIGINAL"
        let body: Data
        if items.contains(where: { $0.name == "format" && $0.value == "adif" }) {
            let record = ADIFRecord(fields: ["CALL": call, "QSO_DATE": "20231114",
                "TIME_ON": "221320", "BAND": "20m", "MODE": "CW"])
            body = try! JSONEncoder().encode(WavelogADIFPage(
                data: WavelogADIFData(exported: 1, lastFetchedID: id, adif: record.adifDocument),
                meta: WavelogListMeta(page: 1, perPage: 1000, count: 1, total: 1, totalPages: 1, hasMore: false)))
        } else {
            body = """
            {"data":[{"id":\(id),"station_id":\(other ? 2 : 1),"call":"\(call)","band":"20m","mode":"CW","qso_date":"2023-11-14 22:13:20"}],"meta":{"page":1,"per_page":1000,"count":1,"total":1,"total_pages":1,"has_more":false}}
            """.data(using: .utf8)!
        }
        let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: nil,
                                       headerFields: ["Content-Type": "application/json"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: body)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

final class FA008PreFixCounterexampleTests: XCTestCase {
    func testChangingLiveStationBeforeSaveMustPreserveLinkedHistory() async throws {
        try await withAsyncFixture { _, database, saved, session in
            let local = self.original()
            try database.save(local, markDirty: false)
            let pending = self.changed(saved, url: false)
            DestinationHistoryProtocol.reset()
            let config = try WavelogConfiguration(baseURL: URL(string: pending.wavelogURL)!,
                                                  token: "wl2_fixture", stationID: pending.wavelogStationID)
            let report = try await SyncEngine(database: database, configuration: config, session: session).synchronize()
            print("FA008 PRE-FIX: deleted=\(report.deleted), requests=\(DestinationHistoryProtocol.requests.count)")
            XCTAssertEqual(report.deleted, 0, "Unsaved station edit must not reconcile another destination")
            XCTAssertNil(try database.lookup(localID: local.id)?.deletedAt, "Original clean linked row must remain live")
            XCTAssertTrue(try database.fetchAll().contains { $0.wavelogID == 84 })
            XCTAssertGreaterThanOrEqual(DestinationHistoryProtocol.requests.count, 3)
            XCTAssertTrue(DestinationHistoryProtocol.requests.allSatisfy { $0.httpMethod == "GET" })
        }
    }

    private func original() -> QSO {
        QSO(wavelogID: 42, call: "K1ORIGINAL", start: Date(timeIntervalSince1970: 1_700_000_000),
            band: "20m", mode: "CW", isDirty: false)
    }
    private func changed(_ saved: XLogSettings, url: Bool) -> XLogSettings {
        var pending = saved
        if url { pending.wavelogURL = "https://destination-b.invalid" }
        else { pending.wavelogStationID = 2 }
        pending.operatorCall = "VK8PENDING"
        return pending
    }
    private func withAsyncFixture(_ body: (SettingsStore, LogbookDatabase, XLogSettings, URLSession) async throws -> Void) async throws {
        let id = "xlog-destination-authority-\(UUID())"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: id))
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(id)
        defer { defaults.removePersistentDomain(forName: id); try? FileManager.default.removeItem(at: root) }
        let database = try LogbookDatabase(url: root.appendingPathComponent("live.sqlite"))
        defer { database.close() }
        var saved = XLogSettings.defaults
        saved.wavelogURL = "https://destination-a.invalid"
        saved.wavelogStationID = 1
        let store = SettingsStore(defaults: defaults)
        store.save(saved)
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [DestinationHistoryProtocol.self]
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        try await body(store, database, saved, session)
    }
}
