from pathlib import Path
import difflib
import hashlib
import json

base = Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out = Path('/tmp/xlog-phase5-followup-20261029-fd774aef/agents/frontend/fa008-grid')
files = ['Sources/XLogCore/Settings.swift', 'Sources/XLogApp/AppModel.swift',
         'Tests/XLogCoreTests/WavelogDestinationAuthorityTests.swift',
         'Tests/XLogPrototypeTests/WavelogDestinationAuthorityTests.swift']
for tree in ['before', 'after']:
    for rel in files:
        path = out / tree / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text((base / rel).read_text())

def replace(rel, old, new):
    path = out / 'after' / rel
    text = path.read_text()
    assert text.count(old) == 1, (rel, old, text.count(old))
    path.write_text(text.replace(old, new))

replace('Sources/XLogCore/Settings.swift', '''    /// Check before persisting either settings or secrets. Tombstones retain
''', '''    /// Telemetry fills only this saved field, never authorizing pending form edits.
    public func autofillGridSquare(_ gridSquare: String) {
        guard !gridSquare.isEmpty else { return }
        var saved = load()
        guard saved.gridSquare.isEmpty else { return }
        saved.gridSquare = gridSquare
        save(saved)
    }

    /// Check before persisting either settings or secrets. Tombstones retain
''')
replace('Sources/XLogApp/AppModel.swift', '''                    settings.gridSquare = homeGrid.uppercased()
                    settingsStore.save(settings)''', '''                    settings.gridSquare = homeGrid.uppercased()
                    settingsStore.autofillGridSquare(settings.gridSquare)''')

test = '''    func testAutomaticGridFillPersistsOnlySavedFieldAndKeepsPendingDestinationUntrusted() async throws {
        try await withAsyncFixture { store, database, saved, session in
            XCTAssertTrue(saved.gridSquare.isEmpty)
            let local = self.original()
            try database.save(local, markDirty: false)
            var pending = self.changed(saved, url: true)
            pending.wavelogStationID = 2
            pending.defaultPower = "25"
            // This is the display-only grid mutation made by pollRadio.
            pending.gridSquare = "PH57"
            let expectedPending = pending
            DestinationHistoryProtocol.reset()

            store.autofillGridSquare(pending.gridSquare)
            var expectedSaved = saved
            expectedSaved.gridSquare = "PH57"
            XCTAssertEqual(store.load(), expectedSaved)
            XCTAssertEqual(pending, expectedPending)
            XCTAssertEqual(pending.operatorCall, "VK8PENDING")
            XCTAssertEqual(pending.defaultPower, "25")
            do {
                let config = try store.wavelogConfiguration(for: pending, token: "wl2_fixture")
                _ = try await SyncEngine(database: database, configuration: config, session: session).synchronize()
                XCTFail("Telemetry must not authorize the pending destination")
            } catch WavelogDestinationError.unsavedDestination { }
            XCTAssertTrue(DestinationHistoryProtocol.requests.isEmpty)
            XCTAssertNil(try database.lookup(localID: local.id)?.deletedAt)

            // An already-saved grid survives subsequent telemetry unchanged.
            store.autofillGridSquare("FN31")
            XCTAssertEqual(store.load(), expectedSaved)
            XCTAssertEqual(pending, expectedPending)
        }
    }

'''
for rel in files[2:]:
    replace(rel, '    private func original() -> QSO {', test + '    private func original() -> QSO {')

parts = []
for rel in files:
    old = (out / 'before' / rel).read_text()
    new = (out / 'after' / rel).read_text()
    parts.extend(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                   fromfile='a/' + rel, tofile='b/' + rel))
(out / 'FA008-grid.patch').write_text(''.join(parts))
(out / 'source-sha256.json').write_text(json.dumps({str(p.relative_to(out)): hashlib.sha256(p.read_bytes()).hexdigest()
    for tree in ['before', 'after'] for p in sorted((out / tree).rglob('*.swift'))}, indent=2) + '\n')
(out / 'old-writer-proof.json').write_text(json.dumps({
    'source': 'Sources/XLogApp/AppModel.swift:1387-1391',
    'trigger': 'Live pending settings have destinationB, grid empty; confirmed radio telemetry has valid homeGrid.',
    'oldAssignment': 'settings.gridSquare = homeGrid.uppercased()',
    'oldWriter': 'settingsStore.save(settings)',
    'bypass': 'Legacy save persists pending destinationB; the guarded factory compares against this newly savedB and accepts it.',
    'downstreamProof': '../fa008/validation-receipt.json retains real SyncEngine raw-configuration evidence: distinctB snapshot caused deleted1 after3GETs.',
    'scope': 'Source/proof preservation only; no additional diagnostic test, compiler, or provider operation executed.'
}, indent=2) + '\n')
print(out)
