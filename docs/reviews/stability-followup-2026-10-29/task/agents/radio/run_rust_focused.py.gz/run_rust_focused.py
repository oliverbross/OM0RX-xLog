import datetime, json, pathlib, subprocess, sys
root=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out=pathlib.Path('/tmp/xlog-phase5-followup-20261029-fd774aef/agents/radio')
filters=['radio_slots::tests::','station_selection::tests::','worker::tests::shutdown_']
tag=sys.argv[1] if len(sys.argv)>1 else 'rust-focused'
results=[]
for i,selected in enumerate(filters,1):
    cmd=['cargo','test','--locked','--jobs','2','--bin','xlog-prototype','--features','contesting-test',selected]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/(tag+'-'+str(i)+'.log')).open('wb') as stream:
        result=subprocess.run(cmd,cwd=root/'prototype/src-tauri',stdout=stream,stderr=subprocess.STDOUT)
    receipt={'command':cmd,'cwd':str(root/'prototype/src-tauri'),'startedAt':start,
        'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode}
    results.append(receipt)
    (out/(tag+'-receipts.json')).write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(receipt),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
