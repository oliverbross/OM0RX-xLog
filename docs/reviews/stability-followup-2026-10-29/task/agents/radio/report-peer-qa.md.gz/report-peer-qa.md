# Read-only follow-up report peer QA

Reviewed 2026-10-29 during the parent's final verification run. No canonical edits, Git operations, compilers, tests, transports or GUI operations were performed for this review.

## Result

No additional confirmed blocker or omitted radio safety boundary found in the FA-004/005 report text. Two documentation corrections/clarifications were sent to root:

1. REMEDIATION_TRACKER.md:405 incorrectly lists `prototype/src-tauri/src/main.rs` for FA-006. The actual permission repair and regression are in `prototype/src-tauri/src/worker.rs` (current allowlist line113, retained editor control line1609, dedicated role regression line1913). The frontend test path is correct.
2. The focused Swift invocation passed83 total tests, including55 radio tests and28 core controls. Calling all83 “radio” or attributing them solely to FA-004/005 overstates that subset. Exact breakdown: LiveFlex31, Registry6, power selection5/capture7/admission6 =55; AutomaticSync19, BackupRestoreAuthority6, RestoreAtomicity3 =28. Rust68 is accurate: routing8 + selection53 + shutdown7. The71/74 cases share an existing shutdown function; no eighth discovered shutdown test was added.

## Radio claim checks

- Tracker384-400 and Stability187-188,194 match the repaired scope: explicit monotonic active authority is separate from per-slot metadata; native routing fences capture before persistence; ordinary/bootstrap metadata is stamped with native authority; direct backend reacquisition shares the routing transition admission guard.
- Current `radio_slots.rs:164-249` retains TX vetoes, checks changing/current route before reacquisition, releases routing locks before IPC, restores/publishes a newer authority after rejected fencing or persistence failure, and supports idempotent publication retry.
- Current `NativeDraftPowerGate.swift:61-109,134-171` preserves inactive metadata/source isolation, same-generation conflict/stale rejection, explicit nil fence, source/readiness/session/freshness/contact-mode/frequency checks and epoch-bound capture.
- Current `LiveFlexSession.swift:115-125,189-192` permits only disconnect on a terminal retained owner; terminate returns uncertainty instead of discarding failure. `LiveStationMethods.swift:57-64` returns the set of unconfirmed FLEX slots. `LiveWorker.swift:24-44,390-434,450-454` propagates74/nonrestartable and narrowly recognizes release-only terminal requests.
- Current `StationRadioRegistryTests.swift:107-169` exercises actual injected fake-owner release uncertainty, retained slot identity, acquisition denial, failed then successful release-only retry through worker response, final transport retirement and test-profile external-I/O denial. The fixture does not connect to the literal host present in its request.
- Tracker400 correctly states the important production limit: `Sources/XLogPrototypeWorker/main.swift:143-167` reaches shutdown after EOF, invokes shutdownOutcome once, and exits74 if unresolved. No post-EOF retry channel exists. The fake-owner in-process retry test does not prove a native post-EOF recovery path.
- `worker.rs:762-769` supplies the specific74 uncertainty diagnostic. The focused native74 test uses an EOF-driven script exit fixture (`2174-2175`), not a real FLEX transport or physical RF observation. The tracker distinguishes injected owners and retains physical/operator verification limits; keep that distinction when summarizing end-to-end process tests.
- Tracker391 correctly retains startup capture installation ordering and same-target TCI readiness as unverified concerns, not repaired confirmed defects. No claim of physical RF-off, reconnect/replay recovery, installed GUI switching or provider/hardware acceptance is present.

## Evidence and closure boundary

Checked original scratch receipts and raw focused logs, without rerunning them:

- `swift-focused-r2-receipt.json`: XLOG_PORTABLE_ONLY=1, dedicated scratch, jobs2, eight named suite filters, exit0; `swift-focused-r2.log`:62 XCTest +21 Swift Testing.
- `rust-focused-r2-receipts.json` and `rust-focused-r2-{1,2,3}.log`: exact locked feature test commands, exits0;8/53/7 pass.

Interim text remains deliberately pending: Stability190 still says fresh process pending; Stability202 describes scratch preparation at frozen9a; Tracker420-426 retains FA-008 closing caller repair pending. These need an explicit closing update/superseding iteration once the parent's final receipts are available. They are not evidence of a failed final run. The archive README likewise says assembly is in progress. This peer QA does not independently verify the parent's currently running full-suite/TSAN/release/process or hosted CI claims.

Additional prior independent FA-008 source-only grid-patch QA remains recorded in `fa008/grid-patch-qa.md`; its saved-snapshot field-only strategy closes the concrete automatic-writer bypass while preserving pending destination/operator/power fields. No new test/compile was performed in this report review.
