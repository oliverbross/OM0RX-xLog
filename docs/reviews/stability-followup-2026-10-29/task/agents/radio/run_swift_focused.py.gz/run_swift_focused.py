import datetime, json, os, pathlib, subprocess, sys
root=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out=pathlib.Path('/tmp/xlog-phase5-followup-20261029-fd774aef/agents/radio')
cmd=['swift','test','--scratch-path',str(out/'swift-focused'),'--jobs','2','--filter',
     'NativePowerSelectionTests|NativeDraftPowerCaptureTests|NativeDraftPowerAdmissionTests|StationRadioRegistryTests|LiveFlexSessionTests|BackupRestoreAuthorityTests|AutomaticSyncTests|RestoreAtomicityTests']
env=os.environ.copy();env['XLOG_PORTABLE_ONLY']='1'
tag=sys.argv[1] if len(sys.argv)>1 else 'swift-focused'
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/(tag+'.log')).open('wb') as stream:
    result=subprocess.run(cmd,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
receipt={'command':cmd,'cwd':str(root),'environmentOverrides':{'XLOG_PORTABLE_ONLY':'1'},'startedAt':start,
         'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode}
(out/(tag+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
raise SystemExit(result.returncode)
