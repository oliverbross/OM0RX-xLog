import datetime, hashlib, json, pathlib, re, subprocess
root=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out=pathlib.Path('/tmp/xlog-phase5-followup-20261029-fd774aef/agents/radio')
baseline=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
exclusive={
 'FA-004':['Sources/XLogPrototypeSupport/NativeDraftPowerGate.swift',
           'Tests/XLogPrototypeTests/NativePowerSelectionTests.swift',
           'Tests/XLogPrototypeTests/NativeDraftPowerCaptureTests.swift',
           'Tests/XLogPrototypeTests/NativeDraftPowerAdmissionTests.swift',
           'prototype/src-tauri/src/radio_slots.rs','prototype/src-tauri/src/station_selection.rs','prototype/src-tauri/src/main.rs'],
 'FA-005':['Sources/XLogPrototypeSupport/LiveFlexSession.swift','Sources/XLogPrototypeSupport/LiveStationMethods.swift']}
shared=['Sources/XLogPrototypeSupport/LiveWorker.swift','Tests/XLogPrototypeTests/StationRadioRegistryTests.swift','prototype/src-tauri/src/worker.rs']
files=exclusive['FA-004']+exclusive['FA-005']+shared
diff=subprocess.check_output(['git','diff','--no-ext-diff','--unified=0',baseline,'--']+files,cwd=root).decode()
worker=(root/'Sources/XLogPrototypeSupport/LiveWorker.swift').read_text().splitlines()
power_start=next(i for i,line in enumerate(worker,1) if '} else if method == "station_power_selection"' in line)
power_end=next(i for i,line in enumerate(worker,1) if i>power_start and '} else if method == "cluster_history"' in line)
patches={key:[] for key in exclusive}; ledger=[]
for section in re.split(r'(?=^diff --git )',diff,flags=re.M):
    if not section: continue
    path=section.splitlines()[0].split(' b/',1)[1]
    first=section.find('\n@@ ')
    if first<0: continue
    header=section[:first+1]
    hunks=re.split(r'(?=^@@ )',section[first+1:],flags=re.M)
    selected={key:[] for key in patches}
    for hunk in hunks:
        if not hunk: continue
        owner=next((key for key,values in exclusive.items() if path in values),None)
        if path.endswith('/LiveWorker.swift'):
            new_start=int(re.search(r'\+(\d+)',hunk.splitlines()[0]).group(1))
            owner='FA-004' if power_start<=new_start<power_end else 'FA-005'
        elif path.endswith('/StationRadioRegistryTests.swift'):
            owner='FA-004' if 'gate.activate' in hunk else 'FA-005'
        elif path.endswith('/worker.rs'):
            owner='FA-005' if 'StationReleaseFailure' in hunk or 'Some(74)' in hunk else None
        ledger.append({'file':path,'hunk':hunk.splitlines()[0],'owner':owner or 'Other agent / excluded'})
        if owner: selected[owner].append(hunk)
    for owner,hunks in selected.items():
        if hunks: patches[owner].append(header+''.join(hunks))
for owner,sections in patches.items(): (out/(owner+'.patch')).write_text(''.join(sections))
receipt={
 'baseline':baseline,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),
 'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'exclusiveFiles':exclusive,'sharedHunks':ledger,
 'sourceSHA256':{path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in files},
 'patchSHA256':{owner:hashlib.sha256((out/(owner+'.patch')).read_bytes()).hexdigest() for owner in patches},
 'limits':['Patch snapshots only; no staging, commits or pushes by this agent.',
           'Shared-file hunks use zero context; git apply requires --unidiff-zero when applying these snapshots.',
           'worker.rs permission/duplicate-role hunks belong to frontend and are excluded.',
           'Raw first compile failure retained; corrected focused Swift R2 exits 0.',
           'No GUI, live transport/provider/credentials/hardware operations.',
           'FA005 release-only retry requires existing live owner plus open in-process request channel; production EOF exits74 after one retirement attempt, with no post-EOF native retry channel.']}
(out/'ownership.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'hunks':{owner:sum(x['owner']==owner for x in ledger) for owner in patches},'excludedHunks':sum(x['owner']=='Other agent / excluded' for x in ledger)}))
