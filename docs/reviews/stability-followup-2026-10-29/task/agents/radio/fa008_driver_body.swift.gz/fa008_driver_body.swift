@main struct FA008Driver {
    static func main() async throws {
        var results: [[String: Any]] = []
        for change in ["saved_destination", "pending_station", "pending_url"] {
            let identity = "fa008-offline-\(UUID())"
            guard let defaults = UserDefaults(suiteName: identity) else { fatalError("Private fixture defaults unavailable") }
            let root = URL(fileURLWithPath: "/tmp/xlog-phase5-followup-20261029-fd774aef/agents/radio/fa008").appendingPathComponent(identity)
            defer { defaults.removePersistentDomain(forName: identity); try? FileManager.default.removeItem(at: root) }
            let database = try LogbookDatabase(url: root.appendingPathComponent("live.sqlite"))
            defer { database.close() }
            var saved = XLogSettings.defaults
            saved.wavelogURL = "https://destination-a.invalid"; saved.wavelogStationID = 1
            let store = SettingsStore(defaults: defaults); store.save(saved)
            let original = QSO(wavelogID: 42, call: "K1ORIGINAL", start: Date(timeIntervalSince1970: 1_700_000_000),
                               band: "20m", mode: "CW", isDirty: false)
            try database.save(original, markDirty: false)
            var pending = saved
            if change == "pending_station" { pending.wavelogStationID = 2 }
            if change == "pending_url" { pending.wavelogURL = "https://destination-b.invalid" }
            pending.operatorCall = "VK8PENDING"
            let config = URLSessionConfiguration.ephemeral
            config.protocolClasses = [DestinationHistoryProtocol.self]
            config.urlCredentialStorage = nil
            config.httpCookieStorage = nil
            let session = URLSession(configuration: config)
            defer { session.invalidateAndCancel() }
            DestinationHistoryProtocol.reset()
            let destination = try WavelogConfiguration(baseURL: URL(string: pending.wavelogURL)!,
                token: "wl2_fixture", stationID: pending.wavelogStationID)
            let report = try await SyncEngine(database: database, configuration: destination, session: session).synchronize()
            let retained = try database.lookup(localID: original.id)
            let rows = try database.fetchAll()
            let requests = DestinationHistoryProtocol.requests
            let preserved = report.deleted == 0 && retained?.deletedAt == nil
            let savedAfter = store.load()
            let row: [String: Any] = ["case": change, "expectedPreserved": true,
                "preservationRequirementPassed": preserved, "deleted": report.deleted,
                "originalAID42StillLive": retained != nil && retained?.deletedAt == nil,
                "originalAID42Tombstoned": retained?.deletedAt != nil,
                "validBID84Imported": rows.contains { $0.wavelogID == 84 },
                "actualInterceptedRequestCount": requests.count,
                "allRequestsGET": requests.allSatisfy { $0.httpMethod == "GET" },
                "allHostsSyntheticInvalid": requests.allSatisfy { $0.url?.host?.hasSuffix(".invalid") == true },
                "savedDestinationUnchanged": savedAfter.wavelogURL == saved.wavelogURL && savedAfter.wavelogStationID == saved.wavelogStationID]
            results.append(row)
            print(String(data: try JSONSerialization.data(withJSONObject: row, options: [.sortedKeys]), encoding: .utf8)!)
        }
        let controlsPass = results[0]["preservationRequirementPassed"] as? Bool == true
        let failures = results.dropFirst().filter { $0["preservationRequirementPassed"] as? Bool == false }.count
        print("FA008 controlsPass=\(controlsPass) expectedPreservationFailures=\(failures)")
        exit(controlsPass && failures == 2 ? 1 : 2)
    }
}
