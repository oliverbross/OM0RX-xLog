import datetime, hashlib, json, pathlib, subprocess
root=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
out=pathlib.Path('/tmp/xlog-phase5-followup-20261029-fd774aef/agents/radio/fa008')
out.mkdir(exist_ok=True)
fixture=pathlib.Path('/tmp/xlog-phase5-followup-20261029-fd774aef/agents/frontend/fa008/FA008PreFixCounterexampleTests.swift')
text=fixture.read_text()
prefix=text[:text.index('final class FA008PreFixCounterexampleTests:')].replace('import XCTest\n','')
assert 'override class func canInit(with request: URLRequest) -> Bool { true }' in prefix
assert 'guard request.httpMethod == "GET"' in prefix
assert 'config.protocolClasses = [DestinationHistoryProtocol.self]' in text
driver=out/'FA008Driver.swift'
body=out.parent/'fa008_driver_body.swift'
driver.write_text(prefix+'\n'+body.read_text())
build=root/'.build/phase5-followup-20261029/native/out'
products=build/'Products/Debug'
maps=build/'Intermediates.noindex/GeneratedModuleMaps'
for bundle in products.glob('*.bundle'):
    destination=out/bundle.name
    if not destination.exists(): destination.symlink_to(bundle)
command=['swiftc','-parse-as-library','-I',str(products),'-Xcc','-fmodule-map-file='+str(maps/'CCurlBackup.modulemap'),
    str(driver),str(products/'XLogCore.o'),str(products/'CCurlBackup.o'),'-lcurl','-lsqlite3','-lz','-o',str(out/'fa008-proof')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'compile.log').open('wb') as stream: compiled=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
receipt={'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),
    'startedAt':start,'command':command,'compileExitCode':compiled.returncode,
    'fixtureSHA256':hashlib.sha256(fixture.read_bytes()).hexdigest(),
    'protocolBoundary':'Copied verbatim protocol body; only XCTest import/test class replaced with standalone requirement driver. canInit intercepts every request; non-GET fails locally.',
    'moduleBuildBoundary':'Existing 9a native build objects, read-only; no package build and no shared scratch mutation.',
    'sourceSHA256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'Sources/XLogCore/SyncEngine.swift',root/'Sources/XLogCore/WavelogClient.swift',root/'Sources/XLogCore/LogbookDatabase.swift',root/'Sources/XLogCore/Settings.swift']},
    'linkedObjectSHA256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [products/'XLogCore.o',products/'CCurlBackup.o']},
    'moduleSHA256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (products/'XLogCore.swiftmodule').rglob('*') if p.is_file()},
    'driverSHA256':hashlib.sha256(driver.read_bytes()).hexdigest()}
print((out/'compile.log').read_text())
if compiled.returncode == 0:
    with (out/'run.log').open('wb') as stream: run=subprocess.run([str(out/'fa008-proof')],cwd=out,stdout=stream,stderr=subprocess.STDOUT,timeout=30)
    receipt['runCommand']=[str(out/'fa008-proof')];receipt['runExitCode']=run.returncode
    receipt['expectedCounterexampleExitCode']=1
    print((out/'run.log').read_text())
receipt['endedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'compileExitCode':compiled.returncode,'runExitCode':receipt.get('runExitCode'),'evidence':str(out)}))
