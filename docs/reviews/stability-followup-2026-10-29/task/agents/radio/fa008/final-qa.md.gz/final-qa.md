# FA008 final read-only QA at fd2fc49e79d691a02323a635f0db157ca5b22e29

One concrete remaining caller bypass prevents full closure.

`AppModel.pollRadio` (1349-1391), scheduled at 1668-1670, persists the complete editable `settings` value through unguarded `settingsStore.save(settings)` at 1391 when an observed valid rotor home grid fills an empty grid field. It does not use the guarded Save path or validate the pending destination.

Trigger: saved destination A, linked A contact ID42, empty grid; user edits the published destination to station B or URL B without saving; a successful ordinary station snapshot reports a valid rotor home grid. The automatic grid branch now persists the pending B destination. The new synchronization configuration factory accepts it because saved and pending destinations now match. The already captured actual 9a engine counterexample establishes the downstream result: valid distinct B history, three intercepted GETs, A42 tombstoned and B84 imported. Backup/recovery destination validation can likewise be satisfied by this incorrectly relabelled saved setting.

This is a source-proven caller bypass; no live station poll, new compiler, test, provider request or GUI was executed during this QA. The eight paired policy tests exercise guarded Save/factory and the deliberate raw-engine control, but omit automatic grid persistence. Persisting only the observed grid delta onto the saved settings would retain pending form fields without granting them destination authority; add a focused helper/caller regression for this trigger.

Other reviewed FA008 wiring is consistent with the intended boundary: guarded Save precedes secret persistence; linkedRemoteCount includes tombstones; missing/closed databases reject destination changes; synchronization and catalog refresh share the captured validated configuration; backup/recovery capture validates before freezing settings. The deliberate raw SyncEngine bypass remains a characterization, not a positive preservation result.
