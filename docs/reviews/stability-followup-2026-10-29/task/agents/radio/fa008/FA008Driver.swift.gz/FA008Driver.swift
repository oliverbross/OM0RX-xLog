import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
#if os(macOS)
@testable import XLogCore
#else
@testable import XLogPortableCore
#endif

/// Every request, including accidental writes, is intercepted; no provider is contacted.
private final class DestinationHistoryProtocol: URLProtocol {
    private static let lock = NSLock()
    private static var recorded: [URLRequest] = []
    static func reset() { lock.withLock { recorded = [] } }
    static var requests: [URLRequest] { lock.withLock { recorded } }
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.lock.withLock { Self.recorded.append(request) }
        guard request.httpMethod == "GET", let url = request.url else {
            client?.urlProtocol(self, didFailWithError: URLError(.unsupportedURL)); return
        }
        let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
        let station = items.first { $0.name == "station_id" }?.value
        let other = url.host == "destination-b.invalid" || station == "2"
        let id = other ? 84 : 42
        let call = other ? "K2OTHER" : "K1ORIGINAL"
        let body: Data
        if items.contains(where: { $0.name == "format" && $0.value == "adif" }) {
            let record = ADIFRecord(fields: ["CALL": call, "QSO_DATE": "20231114",
                "TIME_ON": "221320", "BAND": "20m", "MODE": "CW"])
            body = try! JSONEncoder().encode(WavelogADIFPage(
                data: WavelogADIFData(exported: 1, lastFetchedID: id, adif: record.adifDocument),
                meta: WavelogListMeta(page: 1, perPage: 1000, count: 1, total: 1, totalPages: 1, hasMore: false)))
        } else {
            body = """
            {"data":[{"id":\(id),"station_id":\(other ? 2 : 1),"call":"\(call)","band":"20m","mode":"CW","qso_date":"2023-11-14 22:13:20"}],"meta":{"page":1,"per_page":1000,"count":1,"total":1,"total_pages":1,"has_more":false}}
            """.data(using: .utf8)!
        }
        let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: nil,
                                       headerFields: ["Content-Type": "application/json"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: body)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}


@main struct FA008Driver {
    static func main() async throws {
        var results: [[String: Any]] = []
        for change in ["saved_destination", "pending_station", "pending_url"] {
            let identity = "fa008-offline-\(UUID())"
            guard let defaults = UserDefaults(suiteName: identity) else { fatalError("Private fixture defaults unavailable") }
            let root = URL(fileURLWithPath: "/tmp/xlog-phase5-followup-20261029-fd774aef/agents/radio/fa008").appendingPathComponent(identity)
            defer { defaults.removePersistentDomain(forName: identity); try? FileManager.default.removeItem(at: root) }
            let database = try LogbookDatabase(url: root.appendingPathComponent("live.sqlite"))
            defer { database.close() }
            var saved = XLogSettings.defaults
            saved.wavelogURL = "https://destination-a.invalid"; saved.wavelogStationID = 1
            let store = SettingsStore(defaults: defaults); store.save(saved)
            let original = QSO(wavelogID: 42, call: "K1ORIGINAL", start: Date(timeIntervalSince1970: 1_700_000_000),
                               band: "20m", mode: "CW", isDirty: false)
            try database.save(original, markDirty: false)
            var pending = saved
            if change == "pending_station" { pending.wavelogStationID = 2 }
            if change == "pending_url" { pending.wavelogURL = "https://destination-b.invalid" }
            pending.operatorCall = "VK8PENDING"
            let config = URLSessionConfiguration.ephemeral
            config.protocolClasses = [DestinationHistoryProtocol.self]
            config.urlCredentialStorage = nil
            config.httpCookieStorage = nil
            let session = URLSession(configuration: config)
            defer { session.invalidateAndCancel() }
            DestinationHistoryProtocol.reset()
            let destination = try WavelogConfiguration(baseURL: URL(string: pending.wavelogURL)!,
                token: "wl2_fixture", stationID: pending.wavelogStationID)
            let report = try await SyncEngine(database: database, configuration: destination, session: session).synchronize()
            let retained = try database.lookup(localID: original.id)
            let rows = try database.fetchAll()
            let requests = DestinationHistoryProtocol.requests
            let preserved = report.deleted == 0 && retained?.deletedAt == nil
            let savedAfter = store.load()
            let row: [String: Any] = ["case": change, "expectedPreserved": true,
                "preservationRequirementPassed": preserved, "deleted": report.deleted,
                "originalAID42StillLive": retained != nil && retained?.deletedAt == nil,
                "originalAID42Tombstoned": retained?.deletedAt != nil,
                "validBID84Imported": rows.contains { $0.wavelogID == 84 },
                "actualInterceptedRequestCount": requests.count,
                "allRequestsGET": requests.allSatisfy { $0.httpMethod == "GET" },
                "allHostsSyntheticInvalid": requests.allSatisfy { $0.url?.host?.hasSuffix(".invalid") == true },
                "savedDestinationUnchanged": savedAfter.wavelogURL == saved.wavelogURL && savedAfter.wavelogStationID == saved.wavelogStationID]
            results.append(row)
            print(String(data: try JSONSerialization.data(withJSONObject: row, options: [.sortedKeys]), encoding: .utf8)!)
        }
        let controlsPass = results[0]["preservationRequirementPassed"] as? Bool == true
        let failures = results.dropFirst().filter { $0["preservationRequirementPassed"] as? Bool == false }.count
        print("FA008 controlsPass=\(controlsPass) expectedPreservationFailures=\(failures)")
        exit(controlsPass && failures == 2 ? 1 : 2)
    }
}
