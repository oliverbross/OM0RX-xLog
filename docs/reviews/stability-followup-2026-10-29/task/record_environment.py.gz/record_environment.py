import datetime, json, subprocess
from run_check import ROOT, TASK
commands=[['uname','-mrs'],['swift','--version'],['node','--version'],['npm','--version'],
          ['/opt/homebrew/bin/python3.12','--version'],['/opt/homebrew/bin/python3.14','--version'],['rustc','--version'],['cargo','--version']]
rows=[]
for command in commands:
    completed=subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    rows.append({'command':command,'exit':completed.returncode,'output':completed.stdout})
(TASK/'environment.json').write_text(json.dumps({'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'versions':rows,
 'boundary':'Read-only tool versions; no sw_vers, credential values, production bundle inspection or hardware enumeration.'},indent=2)+'\n')
print(json.dumps(rows,indent=2))
