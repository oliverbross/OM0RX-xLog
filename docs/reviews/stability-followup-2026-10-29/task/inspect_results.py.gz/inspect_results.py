import json, pathlib, re
from run_check import TASK
rows=[]
for path in sorted((TASK/'checks').glob('*.json')):
    d=json.loads(path.read_text())
    if 'command' not in d: continue
    log=path.with_suffix('.log').read_text(errors='replace')
    clean=re.sub(r'\x1b\[[0-9;]*m','',log)
    summaries=[line for line in clean.splitlines() if re.search(r'Ran \d+ tests|Test Files|^\s*Tests\s+|Test run with|^test result:|^# tests |^# pass |^# fail |^ℹ tests |PASS|FAIL|UNVERIFIED',line)]
    rows.append({'id':d['id'],'exit':d['exit'],'seconds':d['seconds'],'summary':summaries[-8:]})
print(json.dumps(rows,indent=2))
