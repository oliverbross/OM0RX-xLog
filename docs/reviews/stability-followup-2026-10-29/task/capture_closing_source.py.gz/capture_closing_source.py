import datetime, hashlib, json, subprocess
from run_check import ROOT, TASK
for name in ['final-source.json','final-source-sha256.json']:
    source=TASK/name; target=TASK/name.replace('final-source','batch-seven-source')
    assert source.exists() and not target.exists(); source.rename(target)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='fd2fc49e79d691a02323a635f0db157ca5b22e29'
compiled=subprocess.check_output(['git','status','--porcelain','--','Sources','Tests','prototype','python','tools','scripts','.github','Package.swift'],cwd=ROOT,text=True).strip()
assert not compiled, compiled
names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
inputs=[n for n in names if n and (n.startswith(('Sources/','Tests/','prototype/','python/','native/','tools/','scripts/','.github/')) or n in ('AGENTS.md','Package.swift','Package.resolved'))]
manifest={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in inputs}
(TASK/'final-source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
changes=subprocess.check_output(['git','diff','--name-only','fd774aef41f196e5f3b7da627a1b221af6594ba7','HEAD'],cwd=ROOT,text=True).splitlines()
receipt={'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'compiledInputsClean':True,'overallStatus':'Only unfinished task reports/evidence are uncommitted','inputs':len(manifest),'changedInputs':changes,'releaseCandidateCreated':False}
(TASK/'final-source.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
