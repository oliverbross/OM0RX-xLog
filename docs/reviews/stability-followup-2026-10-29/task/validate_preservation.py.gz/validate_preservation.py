import datetime, hashlib, json, pathlib, sqlite3, subprocess
from run_check import ROOT,TASK
sha=lambda b:hashlib.sha256(b).hexdigest()
baseline=json.loads((TASK/'baseline.json').read_text())
source=json.loads((TASK/'final-source-sha256.json').read_text())
assert all(sha((ROOT/name).read_bytes())==value for name,value in source.items())
assert (ROOT/'prototype/node_modules').stat().st_ino==baseline['nodeModulesInode']
assert (ROOT/'.build/cw-native').stat().st_ino==baseline['cwInode']
dist={str(p.relative_to(ROOT/'prototype/dist')):sha(p.read_bytes()) for p in (ROOT/'prototype/dist').rglob('*') if p.is_file()}
assert dist==baseline['distHashes']
dbrows=[]
stage=ROOT/'.build/phase5-followup-20261029'
roots=[p for p in stage.glob('process-acceptance*') if p.is_dir() and not p.is_symlink()]
for base in roots:
    for path in base.rglob('*'):
        if path.is_symlink() or not path.is_file(): continue
        if path.suffix not in {'.sqlite','.sqlite3','.db'}: continue
        rel=path.relative_to(base)
        if any(p in {'runtime','Contents','Frameworks','MacOS','Resources','contest-engine','python'} for p in rel.parts): continue
        if path.read_bytes()[:16]!=b'SQLite format 3\x00': continue
        with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as db:
            integrity=db.execute('PRAGMA integrity_check').fetchall()
            foreign=db.execute('PRAGMA foreign_key_check').fetchall()
        assert integrity==[('ok',)] and not foreign,(path,integrity,foreign)
        dbrows.append({'path':str(path),'integrityCheck':'ok','foreignKeyViolations':0})
exports=[]
def inspect(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and 'sha256' in value:
            path=pathlib.Path(value['path'])
            if path.is_absolute() and any(path.is_relative_to(p) for p in roots) and path.suffix.lower() in {'.adi','.adif','.cbr','.cab'}:
                data=path.read_bytes(); assert sha(data)==value['sha256'],path
                expected=value.get('bytes',value.get('size',value.get('byteCount')))
                if expected is not None: assert len(data)==expected,path
                exports.append({'path':str(path),'bytes':len(data),'sha256':sha(data)})
        for child in value.values(): inspect(child)
    elif isinstance(value,list):
        for child in value: inspect(child)
for base in roots:
    evidence=base/'evidence/acceptance.json'
    if evidence.exists():
        accepted=json.loads(evidence.read_text())
        inspect(accepted)
        for check in accepted.get('contestMutation',{}).get('exportChecks',[]):
            matches=[]
            for artifact in (base/'evidence').iterdir():
                if artifact.is_file() and artifact.suffix in {'.adi','.log'}:
                    data=artifact.read_bytes()
                    if len(data)==check['bytes'] and sha(data)==check['sha256']: matches.append(artifact)
            assert len(matches)==1,(base,check,matches)
            exports.append({'path':str(matches[0]),'bytes':check['bytes'],'sha256':check['sha256'],'plugin':check['plugin'],'format':check['format']})
receipt={'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'sourceInputsMatchingFinalSnapshot':len(source),'originalNodeModulesInode':baseline['nodeModulesInode'],
 'originalCWDirectoryInode':baseline['cwInode'],'originalDistFilesMatching':len(dist),
 'privateDatabases':dbrows,'verifiedExports':exports,
 'boundary':'Read-only SQLite integrity/foreign-key checks on explicit task process roots only; no production data/settings/credentials, binary install, GUI, provider or hardware operation.'}
processes=subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines()
remaining=[p for p in processes if str(stage) in p]
receipt['remainingTaskBuildTestWorkerProcesses']=remaining
assert not remaining, remaining
(TASK/'preservation-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({**{k:v for k,v in receipt.items() if k not in {'privateDatabases','verifiedExports'}},'privateDatabaseCount':len(dbrows),'verifiedExportCount':len(exports)},indent=2))
