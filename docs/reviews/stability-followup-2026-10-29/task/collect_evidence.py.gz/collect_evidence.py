"""Archive only bounded textual test evidence; never dependency/build/database payloads."""
import datetime, gzip, hashlib, json, pathlib, sqlite3, subprocess
from run_check import ROOT, TASK
DEST=ROOT/'docs/reviews/stability-followup-2026-10-29'
DEST.mkdir(parents=True,exist_ok=True)
digest=lambda b:hashlib.sha256(b).hexdigest()
allowed={'.json','.jsonl','.log','.txt','.md','.tsv','.csv','.patch','.diff','.py','.swift','.mjs','.ts','.tsx','.rs','.sh','.adi','.adif','.cbr','.cab','.xml','.yml','.yaml'}
excluded_parts={'swift-focused','runtime-tmp','__pycache__','node_modules','target','.git','runtime','Contents','build','assets'}
selected=[]
for path in TASK.rglob('*'):
    rel=path.relative_to(TASK)
    if path.is_symlink() or not path.is_file(): continue
    if any(p in excluded_parts for p in rel.parts): continue
    if path.suffix not in allowed: continue
    if len(rel.parts)>1 and rel.parts[0] not in {'checks','osv','agents'}: continue
    if rel.parts[0]=='agents' and len(rel.parts)>5: continue
    selected.append((path,pathlib.Path('task')/rel))
stage=ROOT/'.build/phase5-followup-20261029'
process_roots=[p for p in stage.glob('process-acceptance*') if p.is_dir() and not p.is_symlink()]
for base in process_roots:
    for path in base.rglob('*'):
        if path.is_symlink() or not path.is_file(): continue
        rel=path.relative_to(base)
        if any(p in {'runtime','Contents','Frameworks','MacOS','Resources','contest-engine','python'} for p in rel.parts): continue
        if path.suffix in allowed and not any(p in {'node_modules','__pycache__'} for p in rel.parts):
            selected.append((path,pathlib.Path('process')/base.name/rel))
index=[]
for original,relative in sorted(selected,key=lambda v:str(v[1])):
    data=original.read_bytes()
    # Byte-preserving compression keeps all unabridged failure/build/test logs.
    zipped=gzip.compress(data,mtime=0)
    target=DEST/(str(relative)+'.gz'); target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(zipped)
    index.append({'original':str(original),'archive':str(target.relative_to(DEST)),
                  'originalBytes':len(data),'originalSHA256':digest(data),
                  'archiveBytes':len(zipped),'archiveSHA256':digest(zipped)})
(DEST/'artifact-index.json').write_text(json.dumps(index,indent=2)+'\n')
receipts=[]
for path in sorted((TASK/'checks').glob('*.json')):
    row=json.loads(path.read_text())
    if not {'id','command','exit','logSHA256'}.issubset(row): continue
    log=pathlib.Path(row['log'])
    assert log.exists() and digest(log.read_bytes())==row['logSHA256']
    receipts.append(row)
(DEST/'results.json').write_text(json.dumps(receipts,indent=2)+'\n')
lines=['# Exact validation commands','', 'Arguments, cwd, UTC timestamps, exit codes and original log hashes are preserved in results.json and each compressed receipt. Counts overlap across reruns/configurations.','', '| ID | Exit | Seconds | Source start → end | Command |','| --- | ---: | ---: | --- | --- |']
import shlex
for r in receipts:
    cmd=shlex.join(r['command']).replace('|','\\|')
    lines.append(f"| {r['id']} | {r['exit']} | {r['seconds']} | {r['sourceHeadStart'][:8]} → {r['sourceHeadEnd'][:8]} | `{cmd}` |")
(DEST/'COMMANDS.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'archives':len(index),'commandReceipts':len(receipts),'originalBytes':sum(r['originalBytes'] for r in index),'compressedBytes':sum(r['archiveBytes'] for r in index)},indent=2))
