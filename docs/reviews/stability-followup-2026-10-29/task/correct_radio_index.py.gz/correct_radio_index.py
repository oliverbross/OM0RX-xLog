import difflib, pathlib, subprocess
root=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
task=pathlib.Path('/tmp/xlog-phase5-followup-20261029-fd774aef')
path='Sources/XLogPrototypeSupport/LiveWorker.swift'
git=lambda *args: subprocess.check_output(['git',*args],cwd=root,text=True)
(task/'FA004-initial-staging.diff').write_text(git('diff','--cached'))
base=git('show','HEAD:'+path); current=(root/path).read_text(); index=git('show',':'+path)
start='            } else if method == "station_power_selection" {'
end='            } else if method == "cluster_history"'
before=base.index(start); after=base.index(end,before)
now=current.index(start); until=current.index(end,now)
desired=base[:before]+current[now:until]+base[after:]
patch=''.join(difflib.unified_diff(index.splitlines(True),desired.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
destination=task/'FA004-correct-shared-index.patch'; destination.write_text(patch)
subprocess.run(['git','apply','--cached',str(destination)],cwd=root,check=True)
assert git('show',':'+path)==desired
subprocess.run(['git','add','--','Sources/XLogPrototypeSupport/NativeDraftPowerGate.swift',
 'Tests/XLogPrototypeTests/NativeDraftPowerAdmissionTests.swift','Tests/XLogPrototypeTests/NativeDraftPowerCaptureTests.swift',
 'Tests/XLogPrototypeTests/NativePowerSelectionTests.swift','prototype/src-tauri/src/main.rs',
 'prototype/src-tauri/src/radio_slots.rs','prototype/src-tauri/src/station_selection.rs'],cwd=root,check=True)
print('Corrected cached shared function to exact tested current body; working files unchanged. Initial zero-context staging artifact preserved.')
