import datetime, hashlib, json, pathlib, subprocess
root = pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
task = pathlib.Path('/tmp/xlog-phase5-followup-20261029-fd774aef')
sha = lambda data: hashlib.sha256(data).hexdigest()
names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
inputs = [n for n in names if n and (n.startswith(('Sources/','Tests/','prototype/','python/','native/','tools/','scripts/','.github/')) or n in ('Package.swift','Package.resolved','AGENTS.md'))]
previous = json.loads((root/'docs/reviews/stability-2026-10-29/receipts/baseline.json').read_text())
manifest = json.loads((root/'docs/reviews/final-code-audit-2026-10-29/baseline-source-sha256.json').read_text())
assert set(manifest) == set(inputs)
since_audit = subprocess.check_output(['git','diff','--name-only','0ce97a12bb06f1fb7c501c3f1286ae9bb1aca450','HEAD'],cwd=root,text=True).splitlines()
assert all(n=='FINAL_CODE_AUDIT.md' or n.startswith('docs/reviews/final-code-audit-2026-10-29/') for n in since_audit)
(task/'baseline-source-sha256.json').write_text(json.dumps(manifest, indent=2)+'\n')
state = {'observedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'initialClean': True, 'note': 'Clean status and FF pull verified before agents started edits. Input baseline reused from hash-verified Phase6 source; Git proves fd774aef changes only audit docs from that source. Avoids racing independent agent edits.',
 'inputs':len(manifest),'nodeModulesInode':(root/'prototype/node_modules').stat().st_ino,
 'cwInode':(root/'.build/cw-native').stat().st_ino,
 'distHashes':{str(p.relative_to(root/'prototype/dist')):sha(p.read_bytes()) for p in (root/'prototype/dist').rglob('*') if p.is_file()}}
assert state['nodeModulesInode'] == previous['nodeModulesInode']
assert state['distHashes'] == previous['distHashes']
(task/'baseline.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps({k:v for k,v in state.items() if k!='distHashes'},indent=2))
