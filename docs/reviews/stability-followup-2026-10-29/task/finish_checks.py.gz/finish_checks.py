import json, subprocess, sys
from run_check import ROOT, TASK, run_check
assert (TASK/'closing-results.json').exists(), 'Finish the prior source-bound sequence first'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head != 'fd2fc49e79d691a02323a635f0db157ca5b22e29', 'Grid-only repair must be committed'
assert not subprocess.check_output(['git','status','--porcelain','--','Sources','Tests','prototype','python','tools','scripts','.github','Package.swift'],cwd=ROOT,text=True).strip()
if not (TASK/'intermediate-fd2-source.json').exists():
    for name in ['final-source.json','final-source-sha256.json']:
        before=TASK/name
        after=TASK/name.replace('final-source','intermediate-fd2-source')
        assert before.exists() and not after.exists()
        before.rename(after)
else:
    assert json.loads((TASK/'final-source.json').read_text())['head']==head
orphan=TASK/'checks/FINAL-NATIVE.log'
if orphan.exists() and not (TASK/'checks/FINAL-NATIVE.json').exists():
    import hashlib
    archived=TASK/'checks/FINAL-NATIVE-ORPHAN.log'
    assert not archived.exists()
    orphan.rename(archived)
    (TASK/'orchestration-incomplete.json').write_text(json.dumps({'job':'shell_2ce87980a3dbb47a','outerTimeoutMs':1000,'observed':'No runner/native child remains; output reaches suite summaries but no exit receipt exists; background service reports missing/expired job. Exact termination cause unproved.','log':str(archived),'logSHA256':hashlib.sha256(archived.read_bytes()).hexdigest(),'acceptedAsPass':False,'correctiveAction':'Preserve output and repeat with long-lived background runner and actual exit receipts.'},indent=2)+'\n')
import hashlib, datetime
names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
inputs=[n for n in names if n and (n.startswith(('Sources/','Tests/','prototype/','python/','native/','tools/','scripts/','.github/')) or n in ('AGENTS.md','Package.swift','Package.resolved'))]
manifest={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in inputs}
(TASK/'final-source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
(TASK/'final-source.json').write_text(json.dumps({'head':head,'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compiledInputsClean':True,'inputs':len(manifest),'releaseCandidateCreated':False},indent=2)+'\n')
stage=ROOT/'.build/phase5-followup-20261029'
results=[]
steps=[
 ('FINAL-NATIVE',['swift','test','--jobs','2','--scratch-path',str(stage/'native'),'--no-parallel'],{}),
 ('FINAL-PORTABLE',['swift','test','--jobs','2','--scratch-path',str(stage/'portable'),'--no-parallel'],{'XLOG_PORTABLE_ONLY':'1'}),
 ('FINAL-STRICT',['swift','build','--scratch-path',str(stage/'strict'),'--jobs','2','-Xswiftc','-strict-concurrency=complete','-Xswiftc','-warn-concurrency'],{'XLOG_PORTABLE_ONLY':'1'}),
 ('FINAL-NATIVE-RELEASE',['swift','build','-c','release','--scratch-path',str(stage/'native-release'),'--jobs','2','--product','om0rx-xlog'],{}),
 ('FINAL-TSAN-AUTHORITY',['swift','test','--scratch-path',str(stage/'tsan'),'--jobs','2','--sanitize','thread','--no-parallel','--filter','WavelogDestinationAuthorityTests|BackupRestoreAuthorityTests'],{'XLOG_PORTABLE_ONLY':'1'}),
]
for name,command,env in steps:
    code=run_check(name,command,overrides=env,timeout=1800)
    results.append({'id':name,'exit':code})
    if code: break
if not any(r['exit'] for r in results):
    build_manifest=TASK/'worker-grid-final-build-manifest.json'
    assert not (stage/'worker-grid-final-clean').exists()
    code=run_check('FINAL-CLEAN-WORKER',['node','prototype/scripts/build-contesting-worker-process.mjs','--scratch-path',str(stage/'worker-grid-final-clean'),'--output',str(build_manifest)],timeout=1800)
    results.append({'id':'FINAL-CLEAN-WORKER','exit':code})
    if code==0:
        worker=json.loads(build_manifest.read_text())['worker']['path']
        for name,command in [
          ('FINAL-FRAMING',['node','Tests/XLogPrototypeTests/worker-process.test.mjs',worker]),
          ('FINAL-CURRENT-PROCESS',['node','prototype/scripts/accept-contesting-worker-process.mjs','--build-manifest',str(build_manifest.resolve()),'--output',str(stage/'process-acceptance-grid-final'),'--expected-head',head])]:
            results.append({'id':name,'exit':run_check(name,command,timeout=300)})
(TASK/'finish-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
sys.exit(any(r['exit'] for r in results))
