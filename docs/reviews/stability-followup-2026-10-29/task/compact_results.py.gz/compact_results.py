import json, re
from run_check import TASK
for path in sorted((TASK/'checks').glob('*.json')):
    d=json.loads(path.read_text())
    if 'command' not in d: continue
    print(f"{d['id']}: exit={d['exit']} {d['seconds']}s head={d['sourceHeadStart'][:8]}->{d['sourceHeadEnd'][:8]}")
    if d['id'] in ['FULL-NATIVE-SWIFT','FULL-PORTABLE-SWIFT','CLOSE-NATIVE','CLOSE-PORTABLE','CLOSE-FRONTEND','FULL-FRONTEND','FULL-RUST','FEATURE-RUST','TSAN-REPAIRS','CLOSE-TSAN-AUTHORITY']:
        text=re.sub(r'\x1b\[[0-9;]*m','',path.with_suffix('.log').read_text(errors='replace'))
        totals=[int(n) for n in re.findall(r"Test Suite 'All tests' passed[^\n]*\n\s*Executed (\d+) tests",text)]
        summaries=re.findall(r'Test run with (\d+) tests in (\d+) suites passed',text)
        if totals: print('  XCTest total:',sum(totals),'bundle totals:',totals)
        if summaries: print('  SwiftTesting summary total:',sum(int(n) for n,_ in summaries),'per bundle:',summaries)
        for line in text.splitlines():
            if re.match(r'^test result:|^\s*Test Files\s+|^\s*Tests\s+|^ℹ tests ',line): print(' ',line)
