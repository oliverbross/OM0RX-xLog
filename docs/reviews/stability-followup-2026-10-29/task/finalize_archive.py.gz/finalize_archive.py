import gzip,hashlib,json,pathlib,subprocess
from run_check import ROOT,TASK
dest=ROOT/'docs/reviews/stability-followup-2026-10-29'
sha=lambda b:hashlib.sha256(b).hexdigest()
index=json.loads((dest/'artifact-index.json').read_text())
assert {str(p.relative_to(dest)) for p in dest.rglob('*.gz')}=={r['archive'] for r in index},'Unindexed or missing compressed evidence'
for r in index:
    stored=(dest/r['archive']).read_bytes()
    assert sha(stored)==r['archiveSHA256']
    original=gzip.decompress(stored)
    assert len(original)==r['originalBytes'] and sha(original)==r['originalSHA256']
    source=pathlib.Path(r['original'])
    assert source.exists() and source.read_bytes()==original, source
source=json.loads((TASK/'final-source-sha256.json').read_text())
assert all(sha((ROOT/n).read_bytes())==h for n,h in source.items())
receipts=json.loads((dest/'results.json').read_text())
mandatory=['FINAL-NATIVE','FINAL-PORTABLE','FINAL-STRICT','FINAL-NATIVE-RELEASE','FINAL-TSAN-AUTHORITY','FINAL-CLEAN-WORKER','FINAL-FRAMING','FINAL-CURRENT-PROCESS',
 'CLOSE-FRONTEND','CLOSE-FRONTEND-BUILD','FULL-PYTHON','FULL-RUST','FEATURE-RUST','CLIPPY','RUST-RELEASE','ALL-CONTESTS','APPEND-EQUIVALENCE','GENERATOR','PYTHON-RELOCATION','PATCH-FLOORS','PINNED-CORPUS','NPM-AUDIT','OSV-LOCK','CLOSE-PURE-IQ']
by_id={r['id']:r for r in receipts}
assert all(name in by_id and by_id[name]['exit']==0 for name in mandatory)
final=json.loads((TASK/'final-source.json').read_text())
for name in mandatory[:8]:
    assert by_id[name]['sourceHeadStart']==final['head']==by_id[name]['sourceHeadEnd'],name
    assert by_id[name]['sourceDiffSHA256']==sha(b''),name
preservation=json.loads((TASK/'preservation-validation.json').read_text())
assert preservation['sourceInputsMatchingFinalSnapshot']==len(source)
assert preservation['originalDistFilesMatching']==180
assert len(preservation['verifiedExports'])>=12
assert len(preservation['privateDatabases'])>=9
review_path=ROOT/'REMEDIATION_TRACKER.md'
tracker=review_path.read_text()
findings={f'FA-{i:03d}':next(line for line in tracker.splitlines() if line.startswith(f'### FA-{i:03d} —')) for i in range(1,10)}
assert all('Fixed and Verified' in value for value in findings.values()),findings
for historic in ['CODE_REVIEW.md','REGRESSION_TEST_REPORT.md','FINAL_CODE_AUDIT.md']:
    assert subprocess.check_output(['git','show','fd774aef:'+historic],cwd=ROOT)==(ROOT/historic).read_bytes(),historic
assert subprocess.run(['git','diff','--check'],cwd=ROOT).returncode==0
result={'sourceHead':final['head'],'originalByteArchivesVerified':len(index),'sourceInputsVerified':len(source),'commandReceipts':len(receipts),'mandatoryGatesPassed':len(mandatory),'findingStatuses':findings,'privateDatabasesVerified':len(preservation['privateDatabases']),'exportArtifactsVerified':len(preservation['verifiedExports']),'originalDistFilesVerified':180,'historicalReportsUnchanged':True,'operatorReleaseCreated':False,'boundary':'Passing named executable gates and preserved byte identities; external/hardware/provider/manual coverage limits remain in STABILITY_REPORT.md.'}
(dest/'archive-verification.json').write_text(json.dumps(result,indent=2)+'\n')
files=[p for p in dest.rglob('*') if p.is_file() and p.name!='SHA256SUMS']
manifest=''.join(sha(p.read_bytes())+'  '+str(p.relative_to(dest))+'\n' for p in sorted(files))
(dest/'SHA256SUMS').write_text(manifest)
for line in (dest/'SHA256SUMS').read_text().splitlines():
    value,relative=line.split('  ',1); assert sha((dest/relative).read_bytes())==value
print(json.dumps(result,indent=2))
