import json
from run_check import ROOT,TASK
for name in ['closing-results.json','finish-results.json']:
    p=TASK/name
    print(name, json.loads(p.read_text()) if p.exists() else 'RUNNING / no completion receipt')
for name in ['CLOSE-CLEAN-WORKER','CLOSE-FRAMING','CLOSE-CURRENT-PROCESS','CLOSE-TSAN-AUTHORITY','CLOSE-PURE-IQ']:
    p=TASK/'checks'/f'{name}.json'
    if p.exists():
        r=json.loads(p.read_text()); print(name, r['exit'],r['seconds'])
p=ROOT/'.build/phase5-followup-20261029/process-acceptance-r3/evidence/acceptance.json'
d=json.loads(p.read_text())
print('Acceptance top keys:', list(d))
print('Export checks:', d.get('contestMutation',{}).get('exportChecks'))
def search(v,trail=''):
    if isinstance(v,dict):
        if ('export' in trail.lower()) and any(k in v for k in ['path','artifactPath','byteCount','bytes','sha256']):
            print('Export metadata', trail,{k:v[k] for k in v if k in ['path','artifactPath','byteCount','bytes','size','sha256','format','kind']})
        else:
            for k,c in v.items(): search(c,trail+'.'+k)
    elif isinstance(v,list):
        for i,c in enumerate(v): search(c,trail+f'[{i}]')
search(d)
