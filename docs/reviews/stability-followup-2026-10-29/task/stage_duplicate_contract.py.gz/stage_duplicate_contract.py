import difflib, pathlib, re, subprocess
root=pathlib.Path('/Users/oliver/Documents/Projects/OM0RX-xLog')
task=pathlib.Path('/tmp/xlog-phase5-followup-20261029-fd774aef')
path='prototype/src/live/DetachedQSOSurface.test.tsx'
base=subprocess.check_output(['git','show','HEAD:'+path],cwd=root,text=True)
current=(root/path).read_text()
start=current.index('it.each(["Simple", "Full"])("shows the detached %s duplicate advisory')
end=current.index('\nit.each(',start+1)
block=current[start:end]+'\n'
anchor='it.each(["Simple", "Full"])("preserves acknowledged manual UTC'
assert anchor in base and block not in base
index_text=base.replace(anchor,block+anchor,1)
patch=''.join(difflib.unified_diff(base.splitlines(True),index_text.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
worker=subprocess.check_output(['git','diff','--','prototype/src-tauri/src/worker.rs'],cwd=root,text=True)
parts=re.split(r'(?=^@@ )',worker,flags=re.M)
assert len(parts)>=4
selected=[part for part in parts[1:] if 'logbook_duplicate' in part or 'duplicate_history_query' in part]
assert len(selected)==3
patch+=parts[0]+''.join(selected)
destination=task/'FA006-index.patch'; destination.write_text(patch)
subprocess.run(['git','apply','--cached',str(destination)],cwd=root,check=True)
print('Staged only native duplicate permissions and their detached/native regression tests; time changes remain unstaged.')
