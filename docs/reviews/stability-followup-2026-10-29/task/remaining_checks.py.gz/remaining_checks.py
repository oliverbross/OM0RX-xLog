import json, pathlib, sys, time
from run_check import ROOT, TASK, run_check
front=TASK/'checks/FULL-FRONTEND.json'
deadline=time.monotonic()+1800
while not front.exists():
    if time.monotonic()>deadline: raise RuntimeError('Frontend completion receipt unavailable; no competing compiler started')
    time.sleep(5)
if json.loads(front.read_text())['exit']:
    raise RuntimeError('Investigate frontend failure before starting the closing compiler sequence')
stage=ROOT/'.build/phase5-followup-20261029'
worker_manifest=TASK/'worker-build-manifest.json'
steps=[
 ('FULL-PORTABLE-SWIFT',['swift','test','--jobs','2','--scratch-path',str(stage/'portable'),'--no-parallel'],ROOT,{'XLOG_PORTABLE_ONLY':'1'},1800),
 ('NATIVE-RELEASE',['swift','build','-c','release','--scratch-path',str(stage/'native-release'),'--jobs','2','--product','om0rx-xlog'],ROOT,{},1800),
 ('STRICT-SWIFT',['swift','build','--scratch-path',str(stage/'strict'),'--jobs','2','-Xswiftc','-strict-concurrency=complete','-Xswiftc','-warn-concurrency'],ROOT,{'XLOG_PORTABLE_ONLY':'1'},1800),
 ('CLEAN-WORKER',['node','prototype/scripts/build-contesting-worker-process.mjs','--scratch-path',str(stage/'worker-clean'),'--output',str(worker_manifest)],ROOT,{},1800),
]
results=[]
for name,command,cwd,env,timeout in steps:
    code=run_check(name,command,cwd,env,timeout)
    results.append({'id':name,'exit':code})
if worker_manifest.exists():
    worker=json.loads(worker_manifest.read_text())['worker']['path']
    for name,command in [
        ('WORKER-FRAMING',['node','Tests/XLogPrototypeTests/worker-process.test.mjs',worker]),
        ('CURRENT-PROCESS',['node','prototype/scripts/accept-contesting-worker-process.mjs','--build-manifest',str(worker_manifest),'--output',str(TASK/'process-acceptance'),'--expected-head','9a003a2b34e7cc107a8a6fab5ed9d1da6e6b68c7'])]:
        results.append({'id':name,'exit':run_check(name,command,timeout=300)})
else:
    results.append({'id':'WORKER-FRAMING/CURRENT-PROCESS','blocked':'No successful fresh worker manifest'})
cargo=ROOT/'prototype/src-tauri'
current_assets=str(stage/'built-dist-TARGET-FRONTEND-BUILD-R2')
prod_config=json.dumps({'build':{'frontendDist':current_assets}})
test_config=json.dumps({'productName':'OM0RX-xLog Contesting Test','identifier':'com.oliverbross.xlog.contesting-test','bundle':{'active':False,'externalBin':[]},'build':{'frontendDist':current_assets}})
for name,command,env,timeout in [
 ('FULL-RUST',['cargo','test','--locked','--jobs','2'],{'TAURI_CONFIG':prod_config},1800),
 ('FEATURE-RUST',['cargo','test','--locked','--jobs','2','--bin','xlog-prototype','--features','contesting-test'],{'TAURI_CONFIG':test_config},1800),
 ('CLIPPY',['cargo','clippy','--locked','--jobs','2','--all-targets'],{'TAURI_CONFIG':prod_config},1800),
 ('RUST-RELEASE',['cargo','build','--locked','--release','--jobs','2'],{'TAURI_CONFIG':prod_config},1800),
]:
    results.append({'id':name,'exit':run_check(name,command,cargo,env,timeout)})
results.append({'id':'TSAN-REPAIRS','exit':run_check('TSAN-REPAIRS',[
    'swift','test','--scratch-path',str(stage/'tsan'),'--jobs','2','--sanitize','thread','--no-parallel',
    '--filter','StationRadioRegistryTests|NativePowerSelectionTests|NativeDraftPowerCaptureTests|NativeDraftPowerAdmissionTests|AutomaticSyncTests|RestoreAtomicityTests|LiveFlexSessionTests|BackupRestoreAuthorityTests'],
    overrides={'XLOG_PORTABLE_ONLY':'1'},timeout=1800)})
(TASK/'remaining-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
sys.exit(any(row.get('exit',1) for row in results))
