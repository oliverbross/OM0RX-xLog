import sys
from run_check import ROOT, TASK, run_check
checks=[
 ('PATCH-FLOORS',['/opt/homebrew/bin/python3.12','-B','tools/check_reviewed_security_patches.py'],{}),
 ('PYTHON-RELOCATION',['/opt/homebrew/bin/python3.12','-B','prototype/scripts/test-contest-python-relocation.py'],{}),
 ('ALL-CONTESTS',['/opt/homebrew/bin/python3.12','-B','tools/check_all_contests_readiness.py','--family-tests','--output',str(TASK/'all-contests-readiness.json')],{}),
 ('APPEND-EQUIVALENCE',['/opt/homebrew/bin/python3.12','-B','tools/check_contest_append_equivalence.py'],{}),
 ('PINNED-CORPUS',['/opt/homebrew/bin/python3.14','-B','tools/contest_plugin_generator/verify_pinned_corpus.py','--upstream','/Users/oliver/Documents/Projects/contest-sw','--ledger','docs/contesting/contest-acceptance-ledger.json','--inventory','docs/contesting/generated/python-plugin-inventory.json'],{'CONTEST_SW_ROOT':'/Users/oliver/Documents/Projects/contest-sw'}),
 ('GENERATOR',['/opt/homebrew/bin/python3.14','-B','-m','unittest','discover','-s','tools/contest_plugin_generator/tests','-v'],{'CONTEST_SW_ROOT':'/Users/oliver/Documents/Projects/contest-sw'}),
]
results=[]
for name,command,env in checks:
    results.append({'id':name,'exit':run_check(name,command,overrides=env,timeout=900)})
print(results)
sys.exit(any(row['exit'] for row in results))
