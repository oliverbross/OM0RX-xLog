# OM0RX 20 m receive-only IQ capture receipt

Status: development/calibration input only; not launch qualification.

## Observed configuration

- Radio: FLEX-8400 at `192.168.0.199`, serial `2525-1213-8402-7415`
- Station setting: `OM0RX-WIN10`; connected identity displayed `FLEX-8400 / Flex-8400 / OM0RX`
- Source: operator-released existing panadapter assigned to `DAX IQ 1`
- DAX IQ 1 state: `Ready`
- Centre: `14,018,686 Hz`, observed before both captures
- Actual endpoint format: stereo IEEE float32, `48,000 Hz`, channel 1 I and channel 2 Q
- SigMF format: `cf32_le`, interleaved little-endian float32 I,Q
- DAX TX evidence: displayed `DAX TX Off` before capture; no PTT operation was performed
- Other RX/TX evidence: unknown
- Discontinuities: unknown; the WASAPI helper exposes samples but no transport sequence numbers
- Annotation: unannotated; no operator transcript was supplied

## Five-second preflight

- UTC: `2026-10-31T06:05:58.1962692Z` to `2026-10-31T06:06:03.2966580Z`
- Actual frames: `228,000`; duration: `4.750000 s`
- I: min `-0.75`, max `0.31347656`, RMS `0.0125536908711`, exact rail hits `0`
- Q: min `-0.27978516`, max `0.38183594`, RMS `0.0124897558917`, exact rail hits `0`
- Non-finite frames: `0`; frames outside ±1: `0`
- WAV SHA-256: `FF8D728EB1386B20A4710A00F66CA7F584CD325A949312A6F1FFB7A93B169BCE`
- SigMF data SHA-256: `5F7512E9BB1DF4F1C5FF4F8BA6309BA431AF348EE17152C415651B82169F1784`
- WAV payload and SigMF data: byte-identical (`1,824,000` bytes)

The clean preflight allowed the longer capture.

## Bounded longer capture

- UTC: `2026-10-31T06:06:27.0910560Z` to `2026-10-31T06:07:12.1827616Z`
- Capture wall time: approximately `45.092 s`, below the `60 s` bound
- Actual frames: `2,146,800`; duration: `44.725000 s`
- I: min `-0.92041016`, max `0.6269531`, RMS `0.0170983057913`, exact rail hits `0`
- Q: min `-0.7495117`, max `0.99999994`, RMS `0.0170858918609`, exact rail hits `1` (one positive full-scale value)
- Non-finite frames: `0`; frames outside ±1: `0`
- WAV SHA-256: `5D752C52EAB977EF5A583A2997A287F6B85AA8022710B1CA6A050323E8FFDF4E`
- SigMF data SHA-256: `9210E1A9AF29872B480363ADFBFE3B9096700D0A803F622C734BCD2CD278B419`
- WAV payload and SigMF data: byte-identical (`17,174,400` bytes)

The single long-capture rail hit is preserved unchanged. No normalization, attenuation, clamping or resampling was applied.

## Capture/conversion source

- `work/iq-capture/Program.cs`
- SHA-256: `16CE006C28CC7AE5754AB6F9F4FA9259BAC04784FD0E88DAB7CCB90FE3F36949`

No tuning, panadapter creation/reassignment, stream stealing, gain/antenna/power/network change, saved-setting change, transmit or PTT action was performed by this task.
